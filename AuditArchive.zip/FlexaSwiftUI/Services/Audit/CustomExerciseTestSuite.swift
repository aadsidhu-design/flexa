import Foundation
import simd

/// Comprehensive test suite for custom exercise system validation
/// Tests various movement patterns, edge cases, and error scenarios
class CustomExerciseTestSuite {
    
    // MARK: - Test Data Generation
    
    /// Generate test exercises for various movement patterns
    static func generateTestExercises() -> [CustomExercise] {
        return [
            // Pendulum exercises
            CustomExercise(
                name: "Arm Pendulum",
                userDescription: "Swing arm forward and backward like a pendulum",
                trackingMode: .handheld,
                jointToTrack: nil,
                repParameters: CustomExercise.RepParameters(
                    movementType: .pendulum,
                    minimumROMThreshold: 45.0,
                    minimumDistanceThreshold: 30.0,
                    directionality: .bidirectional,
                    repCooldown: 1.5
                )
            ),
            
            // Circular exercises
            CustomExercise(
                name: "Shoulder Circles",
                userDescription: "Draw circles with your arm",
                trackingMode: .handheld,
                jointToTrack: nil,
                repParameters: CustomExercise.RepParameters(
                    movementType: .circular,
                    minimumROMThreshold: 90.0,
                    minimumDistanceThreshold: 25.0,
                    directionality: .cyclical,
                    repCooldown: 2.0
                )
            ),
            
            // Vertical exercises
            CustomExercise(
                name: "Arm Raises",
                userDescription: "Raise arm up and down",
                trackingMode: .camera,
                jointToTrack: .armpit,
                repParameters: CustomExercise.RepParameters(
                    movementType: .vertical,
                    minimumROMThreshold: 60.0,
                    minimumDistanceThreshold: nil,
                    directionality: .bidirectional,
                    repCooldown: 1.0
                )
            ),
            
            // Horizontal exercises
            CustomExercise(
                name: "Side Raises",
                userDescription: "Raise arm to the side",
                trackingMode: .camera,
                jointToTrack: .armpit,
                repParameters: CustomExercise.RepParameters(
                    movementType: .horizontal,
                    minimumROMThreshold: 75.0,
                    minimumDistanceThreshold: nil,
                    directionality: .unidirectional,
                    repCooldown: 1.2
                )
            ),
            
            // Elbow exercises
            CustomExercise(
                name: "Elbow Flexion",
                userDescription: "Bend and straighten elbow",
                trackingMode: .camera,
                jointToTrack: .elbow,
                repParameters: CustomExercise.RepParameters(
                    movementType: .straightening,
                    minimumROMThreshold: 90.0,
                    minimumDistanceThreshold: nil,
                    directionality: .bidirectional,
                    repCooldown: 0.8
                )
            ),
            
            // Mixed movement exercises
            CustomExercise(
                name: "Complex Pattern",
                userDescription: "Trace a figure-8 pattern",
                trackingMode: .handheld,
                jointToTrack: nil,
                repParameters: CustomExercise.RepParameters(
                    movementType: .mixed,
                    minimumROMThreshold: 120.0,
                    minimumDistanceThreshold: 40.0,
                    directionality: .cyclical,
                    repCooldown: 3.0
                )
            )
        ]
    }
    
    /// Generate edge case test exercises
    static func generateEdgeCaseExercises() -> [CustomExercise] {
        return [
            // Minimal thresholds
            CustomExercise(
                name: "Minimal Movement",
                userDescription: "Very small movements",
                trackingMode: .handheld,
                jointToTrack: nil,
                repParameters: CustomExercise.RepParameters(
                    movementType: .vertical,
                    minimumROMThreshold: 5.0,
                    minimumDistanceThreshold: 2.0,
                    directionality: .bidirectional,
                    repCooldown: 0.1
                )
            ),
            
            // Maximum thresholds
            CustomExercise(
                name: "Maximum Movement",
                userDescription: "Very large movements",
                trackingMode: .handheld,
                jointToTrack: nil,
                repParameters: CustomExercise.RepParameters(
                    movementType: .circular,
                    minimumROMThreshold: 180.0,
                    minimumDistanceThreshold: 100.0,
                    directionality: .cyclical,
                    repCooldown: 5.0
                )
            ),
            
            // Fast movements
            CustomExercise(
                name: "Fast Movements",
                userDescription: "Quick repetitive movements",
                trackingMode: .camera,
                jointToTrack: .armpit,
                repParameters: CustomExercise.RepParameters(
                    movementType: .vertical,
                    minimumROMThreshold: 30.0,
                    minimumDistanceThreshold: nil,
                    directionality: .bidirectional,
                    repCooldown: 0.2
                )
            ),
            
            // Slow movements
            CustomExercise(
                name: "Slow Movements",
                userDescription: "Very slow controlled movements",
                trackingMode: .handheld,
                jointToTrack: nil,
                repParameters: CustomExercise.RepParameters(
                    movementType: .pendulum,
                    minimumROMThreshold: 45.0,
                    minimumDistanceThreshold: 30.0,
                    directionality: .bidirectional,
                    repCooldown: 10.0
                )
            )
        ]
    }
    
    /// Generate invalid test exercises for error handling tests
    static func generateInvalidExercises() -> [CustomExercise] {
        return [
            // Empty name
            CustomExercise(
                name: "",
                userDescription: "Test exercise",
                trackingMode: .handheld,
                jointToTrack: nil,
                repParameters: CustomExercise.RepParameters(
                    movementType: .vertical,
                    minimumROMThreshold: 45.0,
                    minimumDistanceThreshold: 30.0,
                    directionality: .bidirectional,
                    repCooldown: 1.0
                )
            ),
            
            // Negative thresholds
            CustomExercise(
                name: "Negative Thresholds",
                userDescription: "Test exercise",
                trackingMode: .handheld,
                jointToTrack: nil,
                repParameters: CustomExercise.RepParameters(
                    movementType: .vertical,
                    minimumROMThreshold: -10.0,
                    minimumDistanceThreshold: -5.0,
                    directionality: .bidirectional,
                    repCooldown: -1.0
                )
            ),
            
            // Camera mode without joint
            CustomExercise(
                name: "Camera No Joint",
                userDescription: "Test exercise",
                trackingMode: .camera,
                jointToTrack: nil, // Missing joint for camera mode
                repParameters: CustomExercise.RepParameters(
                    movementType: .vertical,
                    minimumROMThreshold: 45.0,
                    minimumDistanceThreshold: nil,
                    directionality: .bidirectional,
                    repCooldown: 1.0
                )
            ),
            
            // Handheld mode without distance threshold
            CustomExercise(
                name: "Handheld No Distance",
                userDescription: "Test exercise",
                trackingMode: .handheld,
                jointToTrack: nil,
                repParameters: CustomExercise.RepParameters(
                    movementType: .vertical,
                    minimumROMThreshold: 45.0,
                    minimumDistanceThreshold: nil, // Missing distance for handheld
                    directionality: .bidirectional,
                    repCooldown: 1.0
                )
            )
        ]
    }
    
    // MARK: - Motion Data Generation
    
    /// Generate test motion data for pendulum movement
    static func generatePendulumMotionData(
        amplitude: Double = 1.0,
        frequency: Double = 0.5,
        duration: TimeInterval = 10.0,
        sampleRate: Double = 30.0
    ) -> [MotionDataPoint] {
        let sampleCount = Int(duration * sampleRate)
        let startTime = Date()
        var motionData: [MotionDataPoint] = []
        
        for i in 0..<sampleCount {
            let t = Double(i) / sampleRate
            let angle = 2 * .pi * frequency * t
            
            // Pendulum motion in Z-axis (forward/backward)
            let position = SIMD3<Double>(
                0,
                0,
                amplitude * sin(angle)
            )
            
            let velocity = SIMD3<Double>(
                0,
                0,
                amplitude * 2 * .pi * frequency * cos(angle)
            )
            
            let timestamp = startTime.addingTimeInterval(t)
            
            motionData.append(MotionDataPoint(
                timestamp: timestamp,
                position: position,
                velocity: velocity
            ))
        }
        
        return motionData
    }
    
    /// Generate test motion data for circular movement
    static func generateCircularMotionData(
        radius: Double = 0.5,
        angularVelocity: Double = 1.0,
        duration: TimeInterval = 8.0,
        sampleRate: Double = 30.0
    ) -> [MotionDataPoint] {
        let sampleCount = Int(duration * sampleRate)
        let startTime = Date()
        var motionData: [MotionDataPoint] = []
        
        for i in 0..<sampleCount {
            let t = Double(i) / sampleRate
            let angle = angularVelocity * t
            
            // Circular motion in X-Z plane
            let position = SIMD3<Double>(
                radius * cos(angle),
                0,
                radius * sin(angle)
            )
            
            let velocity = SIMD3<Double>(
                -radius * angularVelocity * sin(angle),
                0,
                radius * angularVelocity * cos(angle)
            )
            
            let timestamp = startTime.addingTimeInterval(t)
            
            motionData.append(MotionDataPoint(
                timestamp: timestamp,
                position: position,
                velocity: velocity
            ))
        }
        
        return motionData
    }
    
    /// Generate test motion data for vertical movement
    static func generateVerticalMotionData(
        amplitude: Double = 0.8,
        frequency: Double = 0.3,
        duration: TimeInterval = 12.0,
        sampleRate: Double = 30.0
    ) -> [MotionDataPoint] {
        let sampleCount = Int(duration * sampleRate)
        let startTime = Date()
        var motionData: [MotionDataPoint] = []
        
        for i in 0..<sampleCount {
            let t = Double(i) / sampleRate
            let angle = 2 * .pi * frequency * t
            
            // Vertical motion in Y-axis
            let position = SIMD3<Double>(
                0,
                amplitude * (1 - cos(angle)) / 2, // 0 to amplitude
                0
            )
            
            let velocity = SIMD3<Double>(
                0,
                amplitude * .pi * frequency * sin(angle),
                0
            )
            
            let timestamp = startTime.addingTimeInterval(t)
            
            motionData.append(MotionDataPoint(
                timestamp: timestamp,
                position: position,
                velocity: velocity
            ))
        }
        
        return motionData
    }
    
    /// Generate noisy motion data for robustness testing
    static func generateNoisyMotionData(
        baseData: [MotionDataPoint],
        noiseLevel: Double = 0.1
    ) -> [MotionDataPoint] {
        return baseData.map { dataPoint in
            guard let position = dataPoint.position else { return dataPoint }
            
            let noise = SIMD3<Double>(
                Double.random(in: -noiseLevel...noiseLevel),
                Double.random(in: -noiseLevel...noiseLevel),
                Double.random(in: -noiseLevel...noiseLevel)
            )
            
            return MotionDataPoint(
                timestamp: dataPoint.timestamp,
                position: position + noise,
                velocity: dataPoint.velocity
            )
        }
    }
    
    /// Generate corrupted motion data for error handling tests
    static func generateCorruptedMotionData() -> [MotionDataPoint] {
        let startTime = Date()
        return [
            // Valid data point
            MotionDataPoint(
                timestamp: startTime,
                position: SIMD3<Double>(0, 0, 0)
            ),
            
            // NaN position
            MotionDataPoint(
                timestamp: startTime.addingTimeInterval(1),
                position: SIMD3<Double>(Double.nan, 0, 0)
            ),
            
            // Infinite position
            MotionDataPoint(
                timestamp: startTime.addingTimeInterval(2),
                position: SIMD3<Double>(Double.infinity, 0, 0)
            ),
            
            // Extreme values
            MotionDataPoint(
                timestamp: startTime.addingTimeInterval(3),
                position: SIMD3<Double>(1000000, -1000000, 500000)
            ),
            
            // Nil position
            MotionDataPoint(
                timestamp: startTime.addingTimeInterval(4),
                position: nil
            )
        ]
    }
    
    // MARK: - Test Execution
    
    /// Run comprehensive test suite
    static func runComprehensiveTests() -> CustomExerciseTestResults {
        var results = CustomExerciseTestResults()
        
        // Test valid exercises
        let validExercises = generateTestExercises()
        for exercise in validExercises {
            let result = testExerciseConfiguration(exercise)
            results.configurationTests.append(result)
        }
        
        // Test edge cases
        let edgeCaseExercises = generateEdgeCaseExercises()
        for exercise in edgeCaseExercises {
            let result = testExerciseEdgeCase(exercise)
            results.edgeCaseTests.append(result)
        }
        
        // Test invalid exercises
        let invalidExercises = generateInvalidExercises()
        for exercise in invalidExercises {
            let result = testInvalidExercise(exercise)
            results.errorHandlingTests.append(result)
        }
        
        // Test rep counting accuracy
        results.repCountingTests = testRepCountingAccuracy()
        
        // Test motion data processing
        results.motionProcessingTests = testMotionDataProcessing()
        
        // Calculate overall results
        results.calculateOverallResults()
        
        return results
    }
    
    private static func testExerciseConfiguration(_ exercise: CustomExercise) -> ConfigurationTestResult {
        let errorHandler = CustomExerciseErrorHandler.shared
        let validation = errorHandler.validateExerciseConfiguration(exercise)
        
        return ConfigurationTestResult(
            exerciseName: exercise.name,
            isValid: validation.isValid,
            issues: validation.issues.map { $0.description },
            warnings: validation.warnings,
            testType: .valid
        )
    }
    
    private static func testExerciseEdgeCase(_ exercise: CustomExercise) -> ConfigurationTestResult {
        let errorHandler = CustomExerciseErrorHandler.shared
        let validation = errorHandler.validateExerciseConfiguration(exercise)
        
        // Edge cases may have warnings but should still be processable
        let canProcess = validation.isValid || !validation.hasCriticalIssues
        
        return ConfigurationTestResult(
            exerciseName: exercise.name,
            isValid: canProcess,
            issues: validation.issues.map { $0.description },
            warnings: validation.warnings,
            testType: .edgeCase
        )
    }
    
    private static func testInvalidExercise(_ exercise: CustomExercise) -> ConfigurationTestResult {
        let errorHandler = CustomExerciseErrorHandler.shared
        let validation = errorHandler.validateExerciseConfiguration(exercise)
        
        // Invalid exercises should be caught by validation
        let properlyRejected = !validation.isValid
        
        return ConfigurationTestResult(
            exerciseName: exercise.name,
            isValid: properlyRejected, // Success means it was properly rejected
            issues: validation.issues.map { $0.description },
            warnings: validation.warnings,
            testType: .invalid
        )
    }
    
    private static func testRepCountingAccuracy() -> [RepCountingTestResult] {
        var results: [RepCountingTestResult] = []
        
        // Test pendulum rep counting
        let pendulumData = generatePendulumMotionData(frequency: 0.5, duration: 10.0)
        let pendulumExercise = generateTestExercises().first { $0.repParameters.movementType == .pendulum }!
        let pendulumResult = testRepCounting(exercise: pendulumExercise, motionData: pendulumData, expectedReps: 10)
        results.append(pendulumResult)
        
        // Test circular rep counting
        let circularData = generateCircularMotionData(angularVelocity: 1.0, duration: 8.0)
        let circularExercise = generateTestExercises().first { $0.repParameters.movementType == .circular }!
        let circularResult = testRepCounting(exercise: circularExercise, motionData: circularData, expectedReps: 1)
        results.append(circularResult)
        
        // Test vertical rep counting
        let verticalData = generateVerticalMotionData(frequency: 0.3, duration: 12.0)
        let verticalExercise = generateTestExercises().first { $0.repParameters.movementType == .vertical }!
        let verticalResult = testRepCounting(exercise: verticalExercise, motionData: verticalData, expectedReps: 7)
        results.append(verticalResult)
        
        return results
    }
    
    private static func testRepCounting(
        exercise: CustomExercise,
        motionData: [MotionDataPoint],
        expectedReps: Int
    ) -> RepCountingTestResult {
        let detector = CustomRepDetector()
        detector.startSession(exercise: exercise)
        
        // Process motion data
        for dataPoint in motionData {
            if let position = dataPoint.position {
                let simdPosition = simd_float3(Float(position.x), Float(position.y), Float(position.z))
                detector.processHandheldPosition(simdPosition, timestamp: dataPoint.timestamp.timeIntervalSince1970)
            }
        }
        
        let actualReps = detector.currentReps
        detector.stopSession()
        
        let accuracy = expectedReps > 0 ? Double(actualReps) / Double(expectedReps) : 0.0
        
        return RepCountingTestResult(
            exerciseName: exercise.name,
            movementType: exercise.repParameters.movementType,
            expectedReps: expectedReps,
            actualReps: actualReps,
            accuracy: min(1.0, accuracy),
            passed: abs(actualReps - expectedReps) <= max(1, expectedReps / 5) // Allow 20% tolerance
        )
    }
    
    private static func testMotionDataProcessing() -> [MotionProcessingTestResult] {
        var results: [MotionProcessingTestResult] = []
        
        // Test normal data processing
        let normalData = generateVerticalMotionData()
        let normalResult = testMotionProcessing("Normal Data", motionData: normalData)
        results.append(normalResult)
        
        // Test noisy data processing
        let noisyData = generateNoisyMotionData(baseData: normalData, noiseLevel: 0.2)
        let noisyResult = testMotionProcessing("Noisy Data", motionData: noisyData)
        results.append(noisyResult)
        
        // Test corrupted data processing
        let corruptedData = generateCorruptedMotionData()
        let corruptedResult = testMotionProcessing("Corrupted Data", motionData: corruptedData)
        results.append(corruptedResult)
        
        return results
    }
    
    private static func testMotionProcessing(
        _ testName: String,
        motionData: [MotionDataPoint]
    ) -> MotionProcessingTestResult {
        let testExercise = generateTestExercises().first!
        let detector = CustomRepDetector()
        
        var processingSucceeded = true
        var errorMessage: String?
        
        do {
            detector.startSession(exercise: testExercise)
            
            for dataPoint in motionData {
                if let position = dataPoint.position {
                    let simdPosition = simd_float3(Float(position.x), Float(position.y), Float(position.z))
                    detector.processHandheldPosition(simdPosition, timestamp: dataPoint.timestamp.timeIntervalSince1970)
                }
            }
            
            detector.stopSession()
        } catch {
            processingSucceeded = false
            errorMessage = error.localizedDescription
        }
        
        return MotionProcessingTestResult(
            testName: testName,
            dataPointCount: motionData.count,
            processingSucceeded: processingSucceeded,
            errorMessage: errorMessage
        )
    }
}

// MARK: - Test Result Types

struct CustomExerciseTestResults {
    var configurationTests: [ConfigurationTestResult] = []
    var edgeCaseTests: [ConfigurationTestResult] = []
    var errorHandlingTests: [ConfigurationTestResult] = []
    var repCountingTests: [RepCountingTestResult] = []
    var motionProcessingTests: [MotionProcessingTestResult] = []
    
    var overallPassRate: Double = 0.0
    var totalTests: Int = 0
    var passedTests: Int = 0
    
    mutating func calculateOverallResults() {
        let allTests = configurationTests + edgeCaseTests + errorHandlingTests
        let configPassed = allTests.filter { $0.isValid }.count
        let repCountPassed = repCountingTests.filter { $0.passed }.count
        let motionPassed = motionProcessingTests.filter { $0.processingSucceeded }.count
        
        totalTests = allTests.count + repCountingTests.count + motionProcessingTests.count
        passedTests = configPassed + repCountPassed + motionPassed
        overallPassRate = totalTests > 0 ? Double(passedTests) / Double(totalTests) : 0.0
    }
}

struct ConfigurationTestResult {
    let exerciseName: String
    let isValid: Bool
    let issues: [String]
    let warnings: [String]
    let testType: TestType
    
    enum TestType {
        case valid
        case edgeCase
        case invalid
    }
}

struct RepCountingTestResult {
    let exerciseName: String
    let movementType: CustomExercise.RepParameters.MovementType
    let expectedReps: Int
    let actualReps: Int
    let accuracy: Double
    let passed: Bool
}

struct MotionProcessingTestResult {
    let testName: String
    let dataPointCount: Int
    let processingSucceeded: Bool
    let errorMessage: String?
}