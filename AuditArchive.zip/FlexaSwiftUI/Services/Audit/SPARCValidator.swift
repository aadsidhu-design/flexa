import Foundation
import Accelerate
import simd

/// Validator for SPARC (Spectral Arc Length) calculation accuracy and mathematical correctness
class SPARCValidator: ObservableObject {
    
    // MARK: - Audit Result Types
    
    struct SPARCAuditResult {
        let isValid: Bool
        let calculatedSPARC: Double
        let fftResults: [Double]
        let issues: [SPARCIssue]
        let recommendations: [String]
        let confidence: Double
        let spectralArcLength: Double
        let dominantFrequency: Double
    }
    
    struct GraphAuditResult {
        let isValid: Bool
        let dataPointCount: Int
        let timestampIssues: [TimestampIssue]
        let dataGaps: [DataGap]
        let recommendations: [String]
    }
    
    enum SPARCIssue {
        case incorrectFFTImplementation(details: String)
        case invalidSpectralCalculation(details: String)
        case improperVelocityHandling(details: String)
        case insufficientData(details: String)
        case timestampInconsistency(details: String)
        case mathematicalError(details: String)
    }
    
    enum TimestampIssue {
        case duplicateTimestamp(timestamp: Date)
        case negativeTimeDelta(from: Date, to: Date)
        case excessiveGap(from: Date, to: Date, gap: TimeInterval)
        case inconsistentSampling(averageDelta: Double, variance: Double)
    }
    
    struct DataGap {
        let startTime: Date
        let endTime: Date
        let duration: TimeInterval
        let expectedDataPoints: Int
    }
    
    // MARK: - SPARC Specification Constants
    
    private let sparcFrequencyRange: ClosedRange<Double> = 0.0...20.0 // Hz
    private let minimumSampleCount = 10
    private let maximumAllowableGap: TimeInterval = 0.5 // seconds
    private let expectedSamplingRateRange: ClosedRange<Double> = 10.0...120.0 // Hz
    
    // MARK: - Validation Methods
    
    /// Validate SPARC calculation against the mathematical specification
    func validateSPARCCalculation(velocityData: [Double], samplingRate: Double) -> SPARCAuditResult {
        var issues: [SPARCIssue] = []
        var recommendations: [String] = []
        
        // Validate input data
        guard velocityData.count >= minimumSampleCount else {
            issues.append(.insufficientData(details: "Need at least \(minimumSampleCount) samples, got \(velocityData.count)"))
            return SPARCAuditResult(
                isValid: false,
                calculatedSPARC: 0.0,
                fftResults: [],
                issues: issues,
                recommendations: ["Collect more velocity data points"],
                confidence: 0.0,
                spectralArcLength: 0.0,
                dominantFrequency: 0.0
            )
        }
        
        // Validate sampling rate
        guard expectedSamplingRateRange.contains(samplingRate) else {
            issues.append(.improperVelocityHandling(details: "Sampling rate \(samplingRate) Hz is outside expected range \(expectedSamplingRateRange)"))
            recommendations.append("Verify sampling rate calculation")
        }
        
        // Perform reference SPARC calculation
        let referenceResult = calculateReferenceSPARC(velocityData: velocityData, samplingRate: samplingRate)
        
        // Validate FFT implementation
        let fftValidation = validateFFTImplementation(signal: velocityData, samplingRate: samplingRate)
        if !fftValidation.isValid {
            issues.append(.incorrectFFTImplementation(details: fftValidation.details))
            recommendations.append("Fix FFT implementation to match SPARC specification")
        }
        
        // Validate spectral arc length calculation
        let spectralValidation = validateSpectralArcLength(fftResults: referenceResult.fftMagnitudes, samplingRate: samplingRate)
        if !spectralValidation.isValid {
            issues.append(.invalidSpectralCalculation(details: spectralValidation.details))
            recommendations.append("Correct spectral arc length calculation formula")
        }
        
        let isValid = issues.isEmpty
        
        return SPARCAuditResult(
            isValid: isValid,
            calculatedSPARC: referenceResult.sparc,
            fftResults: referenceResult.fftMagnitudes,
            issues: issues,
            recommendations: recommendations,
            confidence: referenceResult.confidence,
            spectralArcLength: referenceResult.spectralArcLength,
            dominantFrequency: referenceResult.dominantFrequency
        )
    }
    
    /// Audit graph data for timestamp and data integrity issues
    func auditGraphData(smoothnessHistory: [SPARCDataPoint]) -> GraphAuditResult {
        var timestampIssues: [TimestampIssue] = []
        var dataGaps: [DataGap] = []
        var recommendations: [String] = []
        
        guard !smoothnessHistory.isEmpty else {
            return GraphAuditResult(
                isValid: false,
                dataPointCount: 0,
                timestampIssues: [],
                dataGaps: [],
                recommendations: ["No SPARC data points available for graphing"]
            )
        }
        
        // Sort data points by timestamp
        let sortedData = smoothnessHistory.sorted { $0.timestamp < $1.timestamp }
        
        // Check for timestamp issues
        var previousTimestamp: Date?
        var timeDifferences: [TimeInterval] = []
        
        for dataPoint in sortedData {
            if let prevTime = previousTimestamp {
                let timeDiff = dataPoint.timestamp.timeIntervalSince(prevTime)
                
                // Check for duplicate timestamps
                if timeDiff == 0 {
                    timestampIssues.append(.duplicateTimestamp(timestamp: dataPoint.timestamp))
                }
                
                // Check for negative time deltas
                if timeDiff < 0 {
                    timestampIssues.append(.negativeTimeDelta(from: prevTime, to: dataPoint.timestamp))
                }
                
                // Check for excessive gaps
                if timeDiff > maximumAllowableGap {
                    let expectedPoints = Int(timeDiff * 30.0) // Assuming ~30Hz sampling
                    dataGaps.append(DataGap(
                        startTime: prevTime,
                        endTime: dataPoint.timestamp,
                        duration: timeDiff,
                        expectedDataPoints: expectedPoints
                    ))
                }
                
                if timeDiff > 0 {
                    timeDifferences.append(timeDiff)
                }
            }
            previousTimestamp = dataPoint.timestamp
        }
        
        // Check sampling rate consistency
        if !timeDifferences.isEmpty {
            let averageDelta = timeDifferences.reduce(0, +) / Double(timeDifferences.count)
            let variance = timeDifferences.map { pow($0 - averageDelta, 2) }.reduce(0, +) / Double(timeDifferences.count)
            let standardDeviation = sqrt(variance)
            
            // If standard deviation is more than 50% of average, sampling is inconsistent
            if standardDeviation > (averageDelta * 0.5) {
                timestampIssues.append(.inconsistentSampling(averageDelta: averageDelta, variance: variance))
                recommendations.append("Implement consistent sampling rate for SPARC data collection")
            }
        }
        
        // Generate recommendations based on issues found
        if !timestampIssues.isEmpty {
            recommendations.append("Fix timestamp handling in SPARC data collection")
        }
        
        if !dataGaps.isEmpty {
            recommendations.append("Implement gap detection and interpolation for missing SPARC data")
        }
        
        let isValid = timestampIssues.isEmpty && dataGaps.isEmpty
        
        return GraphAuditResult(
            isValid: isValid,
            dataPointCount: smoothnessHistory.count,
            timestampIssues: timestampIssues,
            dataGaps: dataGaps,
            recommendations: recommendations
        )
    }
    
    // MARK: - Reference SPARC Implementation
    
    private struct ReferenceSPARCResult {
        let sparc: Double
        let spectralArcLength: Double
        let fftMagnitudes: [Double]
        let dominantFrequency: Double
        let confidence: Double
    }
    
    /// Calculate SPARC using the correct mathematical specification
    private func calculateReferenceSPARC(velocityData: [Double], samplingRate: Double) -> ReferenceSPARCResult {
        // Convert to Float array for vDSP operations
        let signal = velocityData.map { Float($0) }
        
        // Ensure signal length is power of 2 for optimal FFT
        let n = nextPowerOfTwo(signal.count)
        var paddedSignal = signal
        if paddedSignal.count < n {
            paddedSignal.append(contentsOf: Array(repeating: 0.0, count: n - paddedSignal.count))
        }
        
        // Perform FFT
        var realInput = paddedSignal
        var imaginaryInput = Array(repeating: Float(0.0), count: n)
        
        let fftResult = realInput.withUnsafeMutableBufferPointer { realPtr in
            return imaginaryInput.withUnsafeMutableBufferPointer { imagPtr in
                var splitComplex = DSPSplitComplex(realp: realPtr.baseAddress!, imagp: imagPtr.baseAddress!)
                
                let log2n = vDSP_Length(log2(Float(n)))
                guard let fftSetup = vDSP_create_fftsetup(log2n, FFTRadix(kFFTRadix2)) else {
                    return (magnitudes: [Double](), arcLength: 0.0, dominantFreq: 0.0)
                }
                
                // Forward FFT
                vDSP_fft_zip(fftSetup, &splitComplex, 1, log2n, FFTDirection(FFT_FORWARD))
                
                // Calculate magnitudes
                var magnitudes = Array(repeating: Float(0.0), count: n)
                vDSP_zvmags(&splitComplex, 1, &magnitudes, 1, vDSP_Length(n))
                
                // Convert to Double and normalize
                let doubleMagnitudes = magnitudes.map { Double($0) / Double(n) }
                
                // Calculate spectral arc length (core SPARC metric)
                let spectralArcLength = calculateCorrectSpectralArcLength(
                    magnitudes: doubleMagnitudes,
                    samplingRate: samplingRate
                )
                
                // Find dominant frequency
                let maxIndex = magnitudes.enumerated().max(by: { $0.element < $1.element })?.offset ?? 0
                let dominantFreq = Double(maxIndex) * samplingRate / Double(n)
                
                vDSP_destroy_fftsetup(fftSetup)
                
                return (
                    magnitudes: doubleMagnitudes,
                    arcLength: spectralArcLength,
                    dominantFreq: dominantFreq
                )
            }
        }
        
        // Calculate SPARC score from spectral arc length
        // SPARC = -log(spectral_arc_length) normalized to 0-100 scale
        let sparcScore = calculateSPARCScore(spectralArcLength: fftResult.arcLength)
        
        // Calculate confidence based on signal quality
        let confidence = calculateSignalQuality(magnitudes: fftResult.magnitudes)
        
        return ReferenceSPARCResult(
            sparc: sparcScore,
            spectralArcLength: fftResult.arcLength,
            fftMagnitudes: fftResult.magnitudes,
            dominantFrequency: fftResult.dominantFreq,
            confidence: confidence
        )
    }
    
    /// Calculate spectral arc length according to SPARC specification
    private func calculateCorrectSpectralArcLength(magnitudes: [Double], samplingRate: Double) -> Double {
        guard magnitudes.count > 1 else { return 0.0 }
        
        // Use only positive frequencies (first half of FFT result)
        let positiveFreqMagnitudes = Array(magnitudes.prefix(magnitudes.count / 2))
        let frequencyResolution = samplingRate / Double(magnitudes.count)
        
        var spectralArcLength = 0.0
        
        // Calculate arc length in frequency-magnitude space
        for i in 1..<positiveFreqMagnitudes.count {
            let freq1 = Double(i - 1) * frequencyResolution
            let freq2 = Double(i) * frequencyResolution
            let mag1 = positiveFreqMagnitudes[i - 1]
            let mag2 = positiveFreqMagnitudes[i]
            
            // Normalize frequencies to [0, 1] range for proper arc length calculation
            let normalizedFreq1 = freq1 / (samplingRate / 2.0)
            let normalizedFreq2 = freq2 / (samplingRate / 2.0)
            
            // Calculate arc length segment
            let deltaFreq = normalizedFreq2 - normalizedFreq1
            let deltaMag = mag2 - mag1
            
            spectralArcLength += sqrt(deltaFreq * deltaFreq + deltaMag * deltaMag)
        }
        
        return spectralArcLength
    }
    
    /// Convert spectral arc length to SPARC score (0-100 scale)
    private func calculateSPARCScore(spectralArcLength: Double) -> Double {
        guard spectralArcLength > 0 else { return 100.0 }
        
        // SPARC formula: -log(spectral_arc_length)
        // Normalized to 0-100 scale where higher = smoother
        let rawSPARC = -log(spectralArcLength)
        
        // Normalize to 0-100 scale (empirically determined scaling)
        let normalizedSPARC = max(0.0, min(100.0, (rawSPARC + 5.0) * 10.0))
        
        return normalizedSPARC
    }
    
    /// Calculate signal quality/confidence metric
    private func calculateSignalQuality(magnitudes: [Double]) -> Double {
        guard !magnitudes.isEmpty else { return 0.0 }
        
        let totalPower = magnitudes.reduce(0, +)
        guard totalPower > 0 else { return 0.0 }
        
        // Calculate signal-to-noise ratio
        let maxMagnitude = magnitudes.max() ?? 0.0
        let averageMagnitude = totalPower / Double(magnitudes.count)
        
        let snr = maxMagnitude / averageMagnitude
        return min(1.0, snr / 10.0) // Normalize to 0-1 range
    }
    
    // MARK: - Validation Helper Methods
    
    private struct FFTValidationResult {
        let isValid: Bool
        let details: String
    }
    
    private func validateFFTImplementation(signal: [Double], samplingRate: Double) -> FFTValidationResult {
        // Check if FFT is using proper windowing
        // Check if FFT size is appropriate (power of 2)
        // Check if frequency resolution is correct
        
        let n = signal.count
        let isPowerOfTwo = (n & (n - 1)) == 0
        
        if !isPowerOfTwo {
            return FFTValidationResult(
                isValid: false,
                details: "FFT input size (\(n)) should be padded to power of 2 for optimal performance"
            )
        }
        
        let frequencyResolution = samplingRate / Double(n)
        if frequencyResolution > 1.0 {
            return FFTValidationResult(
                isValid: false,
                details: "Frequency resolution (\(frequencyResolution) Hz) is too coarse for accurate SPARC calculation"
            )
        }
        
        return FFTValidationResult(isValid: true, details: "FFT implementation appears correct")
    }
    
    private struct SpectralValidationResult {
        let isValid: Bool
        let details: String
    }
    
    private func validateSpectralArcLength(fftResults: [Double], samplingRate: Double) -> SpectralValidationResult {
        guard !fftResults.isEmpty else {
            return SpectralValidationResult(
                isValid: false,
                details: "No FFT results available for spectral arc length validation"
            )
        }
        
        // Check if spectral arc length calculation uses proper normalization
        let maxMagnitude = fftResults.max() ?? 0.0
        let totalPower = fftResults.reduce(0, +)
        
        if maxMagnitude == 0.0 || totalPower == 0.0 {
            return SpectralValidationResult(
                isValid: false,
                details: "FFT magnitudes are zero - check input signal preprocessing"
            )
        }
        
        // Check if frequency range is appropriate for SPARC
        let nyquistFreq = samplingRate / 2.0
        if nyquistFreq < sparcFrequencyRange.upperBound {
            return SpectralValidationResult(
                isValid: false,
                details: "Nyquist frequency (\(nyquistFreq) Hz) is below SPARC frequency range upper bound"
            )
        }
        
        return SpectralValidationResult(isValid: true, details: "Spectral arc length calculation appears correct")
    }
    
    private func nextPowerOfTwo(_ n: Int) -> Int {
        guard n > 1 else { return 2 }
        return 1 << (Int(log2(Double(n - 1))) + 1)
    }
}