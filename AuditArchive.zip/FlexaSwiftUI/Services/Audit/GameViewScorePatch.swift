import Foundation
import SwiftUI

/// Patches existing game views to use real AI scoring instead of placeholder data
/// This service provides the integration layer between games and the new scoring system
@MainActor class GameViewScorePatch: ObservableObject {
    static let shared = GameViewScorePatch()
    
    // MARK: - Dependencies
    private let scoreIntegrationService = ScoreIntegrationService.shared
    private let scoreLogger = ScoreCalculationLogger.shared
    private let placeholderFixer = PlaceholderDataFixer.shared
    
    // MARK: - Published State
    @Published var isPatchingEnabled: Bool = true
    @Published var lastPatchedSession: ExerciseSessionData?
    @Published var patchingStatistics: PatchingStatistics = PatchingStatistics()
    
    struct PatchingStatistics {
        var totalSessionsPatched: Int = 0
        var successfulPatches: Int = 0
        var failedPatches: Int = 0
        var averagePatchTime: TimeInterval = 0
        
        var successRate: Double {
            return totalSessionsPatched > 0 ? Double(successfulPatches) / Double(totalSessionsPatched) : 0
        }
    }
    
    private init() {}
    
    // MARK: - Main Patching Method
    
    /// Patch session data from game views to include real AI scores
    /// This replaces the placeholder scoring with actual calculated scores
    func patchGameSessionData(
        originalSessionData: ExerciseSessionData,
        motionService: SimpleMotionService? = nil,
        gameSpecificData: GameSpecificData? = nil
    ) async -> ExerciseSessionData {
        
        guard isPatchingEnabled else {
            FlexaLog.gemini.info("🔧 [GameViewScorePatch] Patching disabled, returning original data")
            return originalSessionData
        }
        
        let patchStartTime = Date()
        let sessionId = originalSessionData.id
        
        // Start logging
        let logSession = scoreLogger.startCalculationLogging(
            sessionId: sessionId,
            exerciseType: originalSessionData.exerciseType
        )
        
        FlexaLog.gemini.info("🎮 [GameViewScorePatch] Patching session data for \(originalSessionData.exerciseType)")
        
        do {
            // Step 1: Validate original data and identify placeholders
            logSession.logStep(
                stepName: "Placeholder Detection",
                stepType: .validation,
                inputData: [
                    "aiScore": originalSessionData.aiScore?.description ?? "nil",
                    "formScore": originalSessionData.formScore,
                    "motionSmoothnessScore": originalSessionData.motionSmoothnessScore,
                    "consistency": originalSessionData.consistency
                ],
                algorithm: "Placeholder validation check",
                outputValue: 0,
                isValid: true,
                notes: "Checking for placeholder values in original session data"
            )
            
            // Step 2: Enhance session data with game-specific information
            let enhancedSessionData = enhanceWithGameSpecificData(
                sessionData: originalSessionData,
                gameData: gameSpecificData
            )
            
            logSession.logStep(
                stepName: "Game Data Enhancement",
                stepType: .dataCollection,
                inputData: [
                    "originalReps": originalSessionData.reps,
                    "originalScore": originalSessionData.score,
                    "gameType": originalSessionData.exerciseType
                ],
                algorithm: "Game-specific data enhancement",
                outputValue: Double(enhancedSessionData.reps),
                isValid: true,
                notes: "Enhanced session data with game-specific metrics"
            )
            
            // Step 3: Calculate real AI scores
            let patchedSessionData = await scoreIntegrationService.calculateIntegratedScores(
                for: enhancedSessionData,
                motionService: motionService
            )
            
            // Step 4: Validate the patched data
            let validation = scoreIntegrationService.validateScoreIntegrity(sessionData: patchedSessionData)
            
            let finalScores = ScoreCalculationLogger.FinalScores(
                aiScore: Double(patchedSessionData.aiScore ?? 0),
                formScore: patchedSessionData.formScore,
                smoothnessScore: patchedSessionData.motionSmoothnessScore,
                consistencyScore: patchedSessionData.consistency,
                gameScore: patchedSessionData.score
            )
            
            let validationResults = ScoreCalculationLogger.ValidationResult(
                allScoresValid: validation.isValid,
                scoresInBounds: true, // Scores are clamped in AIScoreCalculator
                correlationWithMotion: validation.hasRealAIScore,
                noPlaceholderData: validation.hasRealAIScore && validation.hasRealFormScore,
                issues: validation.issues
            )
            
            // Complete logging
            let patchDuration = Date().timeIntervalSince(patchStartTime)
            logSession.complete(
                finalScores: finalScores,
                validationResults: validationResults
            )
            
            // Update statistics
            await updatePatchingStatistics(success: validation.isValid, duration: patchDuration)
            
            await MainActor.run {
                self.lastPatchedSession = patchedSessionData
            }
            
            if validation.isValid {
                FlexaLog.gemini.info("✅ [GameViewScorePatch] Successfully patched session - AI: \(finalScores.aiScore)%, Form: \(finalScores.formScore)%, Smoothness: \(finalScores.smoothnessScore)%, Consistency: \(finalScores.consistencyScore)%")
            } else {
                FlexaLog.gemini.warning("⚠️ [GameViewScorePatch] Patching completed with issues: \(validation.issues.joined(separator: ", "))")
            }
            
            return patchedSessionData
            
        } catch {
            FlexaLog.gemini.error("❌ [GameViewScorePatch] Patching failed: \(error.localizedDescription)")
            
            // Log fallback usage
            scoreLogger.logFallbackUsage(
                sessionId: sessionId,
                reason: "Patching failed: \(error.localizedDescription)",
                fallbackMethod: "Return original session data",
                fallbackScores: ScoreCalculationLogger.FinalScores(
                    aiScore: Double(originalSessionData.aiScore ?? 0),
                    formScore: originalSessionData.formScore,
                    smoothnessScore: originalSessionData.motionSmoothnessScore,
                    consistencyScore: originalSessionData.consistency,
                    gameScore: originalSessionData.score
                )
            )
            
            let patchDuration = Date().timeIntervalSince(patchStartTime)
            await updatePatchingStatistics(success: false, duration: patchDuration)
            
            return originalSessionData
        }
    }
    
    // MARK: - Game-Specific Data Enhancement
    
    struct GameSpecificData {
        let gameType: GameType
        let gameScore: Int
        let gameSpecificMetrics: [String: Double]
        let userInteractions: [UserInteraction]
        let difficultyLevel: DifficultyLevel?
    }
    
    struct UserInteraction {
        let type: InteractionType
        let timestamp: Date
        let accuracy: Double?
        let reactionTime: TimeInterval?
    }
    
    enum InteractionType {
        case balloonPop
        case targetHit
        case circleComplete
        case wallClimb
        case flameExtinguish
    }
    
    enum DifficultyLevel {
        case easy, medium, hard
        
        var scoreMultiplier: Double {
            switch self {
            case .easy: return 0.8
            case .medium: return 1.0
            case .hard: return 1.2
            }
        }
    }
    
    private func enhanceWithGameSpecificData(
        sessionData: ExerciseSessionData,
        gameData: GameSpecificData?
    ) -> ExerciseSessionData {
        
        guard let gameData = gameData else {
            return sessionData // No enhancement needed
        }
        
        // Create enhanced session data with game-specific improvements
        var enhancedData = sessionData
        
        // Apply difficulty-based score adjustments
        if let difficulty = gameData.difficultyLevel {
            let adjustedScore = Int(Double(sessionData.score) * difficulty.scoreMultiplier)
            enhancedData = ExerciseSessionData(
                id: sessionData.id,
                exerciseType: sessionData.exerciseType,
                score: adjustedScore,
                reps: sessionData.reps,
                maxROM: sessionData.maxROM,
                averageROM: sessionData.averageROM,
                duration: sessionData.duration,
                timestamp: sessionData.timestamp,
                romHistory: sessionData.romHistory,
                repTimestamps: sessionData.repTimestamps,
                sparcHistory: sessionData.sparcHistory,
                romData: sessionData.romData,
                sparcData: sessionData.sparcData,
                aiScore: sessionData.aiScore,
                painPre: sessionData.painPre,
                painPost: sessionData.painPost,
                sparcScore: sessionData.sparcScore,
                formScore: sessionData.formScore,
                consistency: sessionData.consistency,
                peakVelocity: sessionData.peakVelocity,
                motionSmoothnessScore: sessionData.motionSmoothnessScore,
                accelAvgMagnitude: sessionData.accelAvgMagnitude,
                accelPeakMagnitude: sessionData.accelPeakMagnitude,
                gyroAvgMagnitude: sessionData.gyroAvgMagnitude,
                gyroPeakMagnitude: sessionData.gyroPeakMagnitude,
                aiFeedback: sessionData.aiFeedback,
                goalsAfter: sessionData.goalsAfter
            )
        }
        
        FlexaLog.gemini.debug("🎮 [GameViewScorePatch] Enhanced session data with game-specific metrics")
        return enhancedData
    }
    
    // MARK: - Game Type Detection
    
    /// Detect game type from exercise type string
    func detectGameType(from exerciseType: String) -> GameType? {
        return GameType.fromDisplayName(exerciseType)
    }
    
    /// Create game-specific data for common game types
    func createGameSpecificData(
        gameType: GameType,
        gameScore: Int,
        interactions: [UserInteraction] = [],
        difficulty: DifficultyLevel? = nil
    ) -> GameSpecificData {
        
        var gameMetrics: [String: Double] = [:]
        
        switch gameType {
        case .balloonPop:
            gameMetrics["balloonsPopped"] = Double(interactions.filter { $0.type == .balloonPop }.count)
            gameMetrics["averageReactionTime"] = interactions.compactMap { $0.reactionTime }.reduce(0, +) / Double(max(1, interactions.count))
            
        case .wallClimbers:
            gameMetrics["wallsClimbed"] = Double(interactions.filter { $0.type == .wallClimb }.count)
            gameMetrics["climbingAccuracy"] = interactions.compactMap { $0.accuracy }.reduce(0, +) / Double(max(1, interactions.count))
            
        case .followCircle, .constellationMaker:
            gameMetrics["circlesCompleted"] = Double(interactions.filter { $0.type == .circleComplete }.count)
            gameMetrics["trackingAccuracy"] = interactions.compactMap { $0.accuracy }.reduce(0, +) / Double(max(1, interactions.count))
            
        case .fanOutFlame:
            gameMetrics["flamesExtinguished"] = Double(interactions.filter { $0.type == .flameExtinguish }.count)
            
        case .fruitSlicer:
            gameMetrics["targetsHit"] = Double(interactions.filter { $0.type == .targetHit }.count)
            gameMetrics["slicingAccuracy"] = interactions.compactMap { $0.accuracy }.reduce(0, +) / Double(max(1, interactions.count))
        }
        
        return GameSpecificData(
            gameType: gameType,
            gameScore: gameScore,
            gameSpecificMetrics: gameMetrics,
            userInteractions: interactions,
            difficultyLevel: difficulty
        )
    }
    
    // MARK: - Statistics Management
    
    private func updatePatchingStatistics(success: Bool, duration: TimeInterval) async {
        await MainActor.run {
            patchingStatistics.totalSessionsPatched += 1
            
            if success {
                patchingStatistics.successfulPatches += 1
            } else {
                patchingStatistics.failedPatches += 1
            }
            
            // Update average patch time
            let totalTime = patchingStatistics.averagePatchTime * Double(patchingStatistics.totalSessionsPatched - 1) + duration
            patchingStatistics.averagePatchTime = totalTime / Double(patchingStatistics.totalSessionsPatched)
        }
    }
    
    /// Reset patching statistics
    func resetStatistics() {
        patchingStatistics = PatchingStatistics()
        FlexaLog.gemini.info("🔄 [GameViewScorePatch] Reset patching statistics")
    }
    
    // MARK: - Utility Methods
    
    /// Check if a session needs patching (has placeholder data)
    func sessionNeedsPatching(_ sessionData: ExerciseSessionData) -> Bool {
        return sessionData.aiScore == nil ||
               sessionData.formScore == 0 ||
               sessionData.motionSmoothnessScore == 0 ||
               (sessionData.consistency == 0 && sessionData.romHistory.count > 1)
    }
    
    /// Get patching recommendations for a session
    func getPatchingRecommendations(for sessionData: ExerciseSessionData) -> [String] {
        var recommendations: [String] = []
        
        if sessionData.aiScore == nil {
            recommendations.append("AI Score is missing - needs calculation")
        }
        
        if sessionData.formScore == 0 {
            recommendations.append("Form Score is 0 - needs movement analysis")
        }
        
        if sessionData.motionSmoothnessScore == 0 {
            recommendations.append("Smoothness Score is 0 - needs SPARC integration")
        }
        
        if sessionData.consistency == 0 && sessionData.romHistory.count > 1 {
            recommendations.append("Consistency Score is 0 - needs ROM variance analysis")
        }
        
        if recommendations.isEmpty {
            recommendations.append("Session data appears to have real calculated scores")
        }
        
        return recommendations
    }
}