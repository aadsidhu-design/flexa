//
//  CircleROMAudit.swift
//  FlexaSwiftUI
//
//  Created by Kiro on 10/13/25.
//
//  🔍 CIRCULAR ROM CALCULATION AUDIT SYSTEM
//  Audits and fixes circular range of motion calculations for 360-degree movements
//

import Foundation
import simd
import Combine

// MARK: - Audit Result Types

struct CircleROMAuditResult {
    let isValid: Bool
    let calculatedRange: Double
    let circularityScore: Double
    let issues: [CircleROMIssue]
    let recommendations: [String]
    let detectedMotionType: CircularMotionType
    let centerPoint: SIMD3<Double>?
    let radius: Double
    let completedAngle: Double
}

struct CalibrationAuditResult {
    let isValid: Bool
    let baselineAccuracy: Double
    let centerStability: Double
    let issues: [CalibrationIssue]
    let recommendations: [String]
}

enum CircleROMIssue {
    case incorrectCircularDetection(details: String)
    case invalidCenterCalculation(details: String)
    case improperRadiusCalculation(details: String)
    case missing360DegreeSupport(details: String)
    case incorrectProjection(details: String)
    case calibrationError(details: String)
    
    var description: String {
        switch self {
        case .incorrectCircularDetection(let details):
            return "Circular motion detection error: \(details)"
        case .invalidCenterCalculation(let details):
            return "Center calculation error: \(details)"
        case .improperRadiusCalculation(let details):
            return "Radius calculation error: \(details)"
        case .missing360DegreeSupport(let details):
            return "360-degree support missing: \(details)"
        case .incorrectProjection(let details):
            return "3D to 2D projection error: \(details)"
        case .calibrationError(let details):
            return "Calibration error: \(details)"
        }
    }
}

enum CalibrationIssue {
    case unstableBaseline(details: String)
    case incorrectCenterDetection(details: String)
    case insufficientCalibrationData(details: String)
    
    var description: String {
        switch self {
        case .unstableBaseline(let details):
            return "Unstable baseline: \(details)"
        case .incorrectCenterDetection(let details):
            return "Incorrect center detection: \(details)"
        case .insufficientCalibrationData(let details):
            return "Insufficient calibration data: \(details)"
        }
    }
}

enum CircularMotionType {
    case fullCircle
    case partialCircle
    case linear
    case irregular
    
    var description: String {
        switch self {
        case .fullCircle: return "Full circular motion (>270°)"
        case .partialCircle: return "Partial circular motion (90°-270°)"
        case .linear: return "Linear motion"
        case .irregular: return "Irregular motion pattern"
        }
    }
}

// MARK: - Circle ROM Validator Protocol

protocol CircleROMValidator {
    func validateCircularROM(positions: [SIMD3<Double>]) -> CircleROMAuditResult
    func auditCircularCalibration(calibrationData: CalibrationData) -> CalibrationAuditResult
    func detectCircularMotion(positions: [SIMD3<Double>]) -> CircularMotionType
    func calculateCircularCenter(positions: [SIMD3<Double>]) -> SIMD3<Double>?
    func calculateCircularRadius(positions: [SIMD3<Double>], center: SIMD3<Double>) -> Double
    func calculate360DegreeROM(positions: [SIMD3<Double>], center: SIMD3<Double>) -> Double
}

// MARK: - Calibration Data Structure

struct CalibrationData {
    let baselinePosition: SIMD3<Double>
    let centerPosition: SIMD3<Double>?
    let armLength: Double
    let timestamp: TimeInterval
    let confidence: Double
}

// MARK: - Circle ROM Audit Implementation

final class CircleROMAudit: CircleROMValidator {
    
    // MARK: - Constants
    
    private let minimumSamplesForCircle = 20
    private let circularityThreshold = 0.7 // 0.0 = linear, 1.0 = perfect circle
    private let fullCircleAngleThreshold = 270.0 // degrees
    private let partialCircleAngleThreshold = 90.0 // degrees
    private let maxValidRadius = 2.0 // meters
    private let minValidRadius = 0.05 // meters (5cm)
    
    // MARK: - Public API
    
    func validateCircularROM(positions: [SIMD3<Double>]) -> CircleROMAuditResult {
        var issues: [CircleROMIssue] = []
        var recommendations: [String] = []
        
        // Check minimum sample requirement
        guard positions.count >= minimumSamplesForCircle else {
            issues.append(.incorrectCircularDetection(details: "Insufficient samples: \(positions.count) < \(minimumSamplesForCircle)"))
            recommendations.append("Collect more position samples for accurate circular ROM calculation")
            return CircleROMAuditResult(
                isValid: false,
                calculatedRange: 0.0,
                circularityScore: 0.0,
                issues: issues,
                recommendations: recommendations,
                detectedMotionType: .linear,
                centerPoint: nil,
                radius: 0.0,
                completedAngle: 0.0
            )
        }
        
        // Detect motion type
        let motionType = detectCircularMotion(positions: positions)
        
        // Calculate center point
        guard let center = calculateCircularCenter(positions: positions) else {
            issues.append(.invalidCenterCalculation(details: "Unable to determine circular motion center"))
            recommendations.append("Ensure consistent circular motion pattern for center detection")
            return CircleROMAuditResult(
                isValid: false,
                calculatedRange: 0.0,
                circularityScore: 0.0,
                issues: issues,
                recommendations: recommendations,
                detectedMotionType: motionType,
                centerPoint: nil,
                radius: 0.0,
                completedAngle: 0.0
            )
        }
        
        // Calculate radius
        let radius = calculateCircularRadius(positions: positions, center: center)
        
        // Validate radius
        if radius < minValidRadius {
            issues.append(.improperRadiusCalculation(details: "Radius too small: \(String(format: "%.3f", radius))m"))
            recommendations.append("Increase movement radius for better ROM measurement")
        } else if radius > maxValidRadius {
            issues.append(.improperRadiusCalculation(details: "Radius too large: \(String(format: "%.3f", radius))m"))
            recommendations.append("Reduce movement radius to realistic arm length")
        }
        
        // Calculate circularity score
        let circularityScore = calculateCircularityScore(positions: positions, center: center, radius: radius)
        
        // Calculate completed angle
        let completedAngle = calculate360DegreeROM(positions: positions, center: center)
        
        // Calculate ROM based on motion type
        let calculatedRange = calculateROMForMotionType(motionType: motionType, radius: radius, completedAngle: completedAngle)
        
        // Check for 360-degree support
        if motionType == .fullCircle && completedAngle < fullCircleAngleThreshold {
            issues.append(.missing360DegreeSupport(details: "Full circle detected but angle calculation incomplete: \(String(format: "%.1f", completedAngle))°"))
            recommendations.append("Implement proper 360-degree angle accumulation")
        }
        
        // Validate overall result
        let isValid = issues.isEmpty && circularityScore >= circularityThreshold && radius >= minValidRadius && radius <= maxValidRadius
        
        if !isValid {
            recommendations.append("Review circular motion detection algorithm for accuracy")
        }
        
        FlexaLog.motion.info("🔍 [CircleROMAudit] Motion: \(motionType.description), Radius: \(String(format: "%.3f", radius))m, Angle: \(String(format: "%.1f", completedAngle))°, ROM: \(String(format: "%.1f", calculatedRange))°")
        
        return CircleROMAuditResult(
            isValid: isValid,
            calculatedRange: calculatedRange,
            circularityScore: circularityScore,
            issues: issues,
            recommendations: recommendations,
            detectedMotionType: motionType,
            centerPoint: center,
            radius: radius,
            completedAngle: completedAngle
        )
    }
    
    func auditCircularCalibration(calibrationData: CalibrationData) -> CalibrationAuditResult {
        var issues: [CalibrationIssue] = []
        var recommendations: [String] = []
        
        // Check baseline stability
        let baselineAccuracy = validateBaselinePosition(calibrationData.baselinePosition)
        if baselineAccuracy < 0.8 {
            issues.append(.unstableBaseline(details: "Baseline accuracy: \(String(format: "%.2f", baselineAccuracy))"))
            recommendations.append("Ensure stable starting position during calibration")
        }
        
        // Check center detection
        var centerStability = 0.0
        if let center = calibrationData.centerPosition {
            centerStability = validateCenterPosition(center, baseline: calibrationData.baselinePosition)
            if centerStability < 0.7 {
                issues.append(.incorrectCenterDetection(details: "Center stability: \(String(format: "%.2f", centerStability))"))
                recommendations.append("Perform circular motion during calibration for better center detection")
            }
        } else {
            issues.append(.incorrectCenterDetection(details: "No center position detected"))
            recommendations.append("Ensure circular motion is performed during calibration")
        }
        
        // Check calibration data sufficiency
        if calibrationData.confidence < 0.6 {
            issues.append(.insufficientCalibrationData(details: "Low confidence: \(String(format: "%.2f", calibrationData.confidence))"))
            recommendations.append("Repeat calibration with more consistent motion")
        }
        
        let isValid = issues.isEmpty && baselineAccuracy >= 0.8 && centerStability >= 0.7
        
        return CalibrationAuditResult(
            isValid: isValid,
            baselineAccuracy: baselineAccuracy,
            centerStability: centerStability,
            issues: issues,
            recommendations: recommendations
        )
    }
    
    // MARK: - Motion Detection
    
    func detectCircularMotion(positions: [SIMD3<Double>]) -> CircularMotionType {
        guard positions.count >= minimumSamplesForCircle else { return .linear }
        
        // Calculate center and radius
        guard let center = calculateCircularCenter(positions: positions) else { return .irregular }
        let radius = calculateCircularRadius(positions: positions, center: center)
        
        // Calculate circularity score
        let circularityScore = calculateCircularityScore(positions: positions, center: center, radius: radius)
        
        // Calculate total angle traversed
        let totalAngle = calculate360DegreeROM(positions: positions, center: center)
        
        // Classify motion type
        if circularityScore < 0.5 {
            return .linear
        } else if totalAngle >= fullCircleAngleThreshold {
            return .fullCircle
        } else if totalAngle >= partialCircleAngleThreshold {
            return .partialCircle
        } else {
            return .irregular
        }
    }
    
    // MARK: - Center Calculation
    
    func calculateCircularCenter(positions: [SIMD3<Double>]) -> SIMD3<Double>? {
        guard positions.count >= 3 else { return nil }
        
        // Use least squares circle fitting in the horizontal plane (XZ)
        // Project to 2D, find center, then restore Y coordinate
        
        let points2D = positions.map { SIMD2<Double>($0.x, $0.z) }
        
        // Calculate centroid as initial estimate
        var centroidX = 0.0
        var centroidZ = 0.0
        for point in points2D {
            centroidX += point.x
            centroidZ += point.y
        }
        centroidX /= Double(points2D.count)
        centroidZ /= Double(points2D.count)
        
        // Refine center using iterative approach
        var centerX = centroidX
        var centerZ = centroidZ
        
        for _ in 0..<10 { // Maximum 10 iterations
            var sumX = 0.0
            var sumZ = 0.0
            var sumWeights = 0.0
            
            for point in points2D {
                let distance = sqrt(pow(point.x - centerX, 2) + pow(point.y - centerZ, 2))
                let weight = 1.0 / max(distance, 0.001) // Avoid division by zero
                
                sumX += point.x * weight
                sumZ += point.y * weight
                sumWeights += weight
            }
            
            let newCenterX = sumX / sumWeights
            let newCenterZ = sumZ / sumWeights
            
            // Check convergence
            let deltaX = abs(newCenterX - centerX)
            let deltaZ = abs(newCenterZ - centerZ)
            
            centerX = newCenterX
            centerZ = newCenterZ
            
            if deltaX < 0.001 && deltaZ < 0.001 {
                break // Converged
            }
        }
        
        // Calculate average Y coordinate
        let averageY = positions.map { $0.y }.reduce(0, +) / Double(positions.count)
        
        return SIMD3<Double>(centerX, averageY, centerZ)
    }
    
    // MARK: - Radius Calculation
    
    func calculateCircularRadius(positions: [SIMD3<Double>], center: SIMD3<Double>) -> Double {
        guard !positions.isEmpty else { return 0.0 }
        
        // Calculate distances in horizontal plane (XZ)
        let distances = positions.map { position in
            let dx = position.x - center.x
            let dz = position.z - center.z
            return sqrt(dx * dx + dz * dz)
        }
        
        // Use median distance to avoid outliers
        let sortedDistances = distances.sorted()
        let medianIndex = sortedDistances.count / 2
        
        if sortedDistances.count % 2 == 0 {
            return (sortedDistances[medianIndex - 1] + sortedDistances[medianIndex]) / 2.0
        } else {
            return sortedDistances[medianIndex]
        }
    }
    
    // MARK: - 360-Degree ROM Calculation
    
    func calculate360DegreeROM(positions: [SIMD3<Double>], center: SIMD3<Double>) -> Double {
        guard positions.count >= 2 else { return 0.0 }
        
        // Calculate angles in horizontal plane (XZ)
        var angles: [Double] = []
        for position in positions {
            let dx = position.x - center.x
            let dz = position.z - center.z
            let angle = atan2(dz, dx)
            angles.append(angle)
        }
        
        // Calculate total angle traversed, handling wraparound
        var totalAngle = 0.0
        for i in 1..<angles.count {
            var deltaAngle = angles[i] - angles[i-1]
            
            // Handle wraparound at ±π
            if deltaAngle > .pi {
                deltaAngle -= 2 * .pi
            } else if deltaAngle < -.pi {
                deltaAngle += 2 * .pi
            }
            
            totalAngle += abs(deltaAngle)
        }
        
        // Convert to degrees
        return totalAngle * 180.0 / .pi
    }
    
    // MARK: - Private Helper Methods
    
    private func calculateCircularityScore(positions: [SIMD3<Double>], center: SIMD3<Double>, radius: Double) -> Double {
        guard !positions.isEmpty && radius > 0 else { return 0.0 }
        
        // Calculate how close each point is to the ideal circle
        var deviationSum = 0.0
        for position in positions {
            let dx = position.x - center.x
            let dz = position.z - center.z
            let actualRadius = sqrt(dx * dx + dz * dz)
            let deviation = abs(actualRadius - radius) / radius
            deviationSum += deviation
        }
        
        let averageDeviation = deviationSum / Double(positions.count)
        
        // Convert to circularity score (1.0 = perfect circle, 0.0 = not circular)
        return max(0.0, 1.0 - averageDeviation)
    }
    
    private func calculateROMForMotionType(motionType: CircularMotionType, radius: Double, completedAngle: Double) -> Double {
        switch motionType {
        case .fullCircle:
            // For full circles, ROM is based on the diameter of motion
            return min(180.0, radius * 100.0) // Scale radius to degrees
        case .partialCircle:
            // For partial circles, use the actual angle traversed
            return min(180.0, completedAngle)
        case .linear:
            // For linear motion, calculate based on distance
            return min(90.0, radius * 50.0) // Reduced scaling for linear motion
        case .irregular:
            // For irregular motion, use conservative estimate
            return min(45.0, completedAngle * 0.5)
        }
    }
    
    private func validateBaselinePosition(_ baseline: SIMD3<Double>) -> Double {
        // Check if baseline position is reasonable (not at origin, not too far)
        let magnitude = sqrt(baseline.x * baseline.x + baseline.y * baseline.y + baseline.z * baseline.z)
        
        if magnitude < 0.1 { // Too close to origin
            return 0.3
        } else if magnitude > 3.0 { // Too far from origin
            return 0.5
        } else {
            return 1.0 // Good baseline position
        }
    }
    
    private func validateCenterPosition(_ center: SIMD3<Double>, baseline: SIMD3<Double>) -> Double {
        // Check if center is reasonably close to baseline
        let distance = sqrt(pow(center.x - baseline.x, 2) + pow(center.y - baseline.y, 2) + pow(center.z - baseline.z, 2))
        
        if distance > 1.0 { // Center too far from baseline
            return 0.4
        } else if distance < 0.05 { // Center too close to baseline (no movement)
            return 0.6
        } else {
            return 1.0 // Good center position
        }
    }
}