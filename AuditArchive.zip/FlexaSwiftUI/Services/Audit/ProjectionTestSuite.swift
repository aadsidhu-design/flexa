//
//  ProjectionTestSuite.swift
//  FlexaSwiftUI
//
//  Created by Kiro on 10/13/25.
//
//  🧪 3D TO 2D PROJECTION TEST SUITE
//  Comprehensive testing for circular motion projection accuracy
//

import Foundation
import simd

// MARK: - Projection Test Cases

struct ProjectionTestCase {
    let name: String
    let points3D: [SIMD3<Double>]
    let expectedPlane: ProjectionPlane
    let expectedCircularity: Double
    let expectedROMRange: ClosedRange<Double>
    let tolerance: Double
    
    init(name: String, points3D: [SIMD3<Double>], expectedPlane: ProjectionPlane, expectedCircularity: Double, expectedROMRange: ClosedRange<Double>, tolerance: Double = 0.1) {
        self.name = name
        self.points3D = points3D
        self.expectedPlane = expectedPlane
        self.expectedCircularity = expectedCircularity
        self.expectedROMRange = expectedROMRange
        self.tolerance = tolerance
    }
}

// MARK: - Test Data Generators

struct ProjectionTestData {
    
    /// Generate perfect horizontal circle (XZ plane)
    static func generateHorizontalCircle(center: SIMD3<Double>, radius: Double, samples: Int = 100) -> [SIMD3<Double>] {
        var points: [SIMD3<Double>] = []
        
        for i in 0..<samples {
            let angle = 2.0 * .pi * Double(i) / Double(samples)
            let x = center.x + radius * cos(angle)
            let z = center.z + radius * sin(angle)
            points.append(SIMD3<Double>(x, center.y, z))
        }
        
        return points
    }
    
    /// Generate perfect vertical circle (XY plane)
    static func generateVerticalCircle(center: SIMD3<Double>, radius: Double, samples: Int = 100) -> [SIMD3<Double>] {
        var points: [SIMD3<Double>] = []
        
        for i in 0..<samples {
            let angle = 2.0 * .pi * Double(i) / Double(samples)
            let x = center.x + radius * cos(angle)
            let y = center.y + radius * sin(angle)
            points.append(SIMD3<Double>(x, y, center.z))
        }
        
        return points
    }
    
    /// Generate frontal circle (YZ plane)
    static func generateFrontalCircle(center: SIMD3<Double>, radius: Double, samples: Int = 100) -> [SIMD3<Double>] {
        var points: [SIMD3<Double>] = []
        
        for i in 0..<samples {
            let angle = 2.0 * .pi * Double(i) / Double(samples)
            let y = center.y + radius * cos(angle)
            let z = center.z + radius * sin(angle)
            points.append(SIMD3<Double>(center.x, y, z))
        }
        
        return points
    }
    
    /// Generate tilted circle (arbitrary plane)
    static func generateTiltedCircle(center: SIMD3<Double>, radius: Double, normal: SIMD3<Double>, samples: Int = 100) -> [SIMD3<Double>] {
        var points: [SIMD3<Double>] = []
        
        // Create orthonormal basis for the plane
        let normalizedNormal = simd_normalize(normal)
        
        // Find two perpendicular vectors in the plane
        var u = SIMD3<Double>(1, 0, 0)
        if abs(simd_dot(u, normalizedNormal)) > 0.9 {
            u = SIMD3<Double>(0, 1, 0)
        }
        
        let v1 = simd_normalize(simd_cross(normalizedNormal, u))
        let v2 = simd_cross(normalizedNormal, v1)
        
        for i in 0..<samples {
            let angle = 2.0 * .pi * Double(i) / Double(samples)
            let localX = radius * cos(angle)
            let localY = radius * sin(angle)
            
            let point = center + localX * v1 + localY * v2
            points.append(point)
        }
        
        return points
    }
    
    /// Generate 3D linear motion
    static func generate3DLinearMotion(start: SIMD3<Double>, end: SIMD3<Double>, samples: Int = 50) -> [SIMD3<Double>] {
        var points: [SIMD3<Double>] = []
        
        for i in 0..<samples {
            let t = Double(i) / Double(samples - 1)
            let point = start + t * (end - start)
            points.append(point)
        }
        
        return points
    }
    
    /// Generate 3D spiral motion
    static func generateSpiral(center: SIMD3<Double>, radius: Double, height: Double, turns: Double, samples: Int = 100) -> [SIMD3<Double>] {
        var points: [SIMD3<Double>] = []
        
        for i in 0..<samples {
            let t = Double(i) / Double(samples - 1)
            let angle = turns * 2.0 * .pi * t
            let currentRadius = radius * (1.0 - t * 0.5) // Decreasing radius
            
            let x = center.x + currentRadius * cos(angle)
            let z = center.z + currentRadius * sin(angle)
            let y = center.y + height * t
            
            points.append(SIMD3<Double>(x, y, z))
        }
        
        return points
    }
    
    /// Generate noisy 3D circle
    static func generateNoisy3DCircle(center: SIMD3<Double>, radius: Double, plane: ProjectionPlane, noiseLevel: Double, samples: Int = 80) -> [SIMD3<Double>] {
        let basePoints: [SIMD3<Double>]
        
        switch plane {
        case .horizontal:
            basePoints = generateHorizontalCircle(center: center, radius: radius, samples: samples)
        case .sagittal:
            basePoints = generateVerticalCircle(center: center, radius: radius, samples: samples)
        case .frontal:
            basePoints = generateFrontalCircle(center: center, radius: radius, samples: samples)
        case .optimal:
            basePoints = generateHorizontalCircle(center: center, radius: radius, samples: samples)
        }
        
        return basePoints.map { point in
            let noise = SIMD3<Double>(
                Double.random(in: -noiseLevel...noiseLevel),
                Double.random(in: -noiseLevel...noiseLevel),
                Double.random(in: -noiseLevel...noiseLevel)
            )
            return point + noise
        }
    }
}

// MARK: - Projection Test Results

struct ProjectionTestResult {
    let testCase: ProjectionTestCase
    let projectionResult: ProjectionResult
    let calculatedROM: Double
    let passed: Bool
    let failureReasons: [String]
    let executionTime: TimeInterval
}

struct ProjectionTestSummary {
    let totalTests: Int
    let passedTests: Int
    let failedTests: Int
    let averageExecutionTime: TimeInterval
    let results: [ProjectionTestResult]
    
    var passRate: Double {
        return totalTests > 0 ? Double(passedTests) / Double(totalTests) : 0.0
    }
}

// MARK: - Projection Test Suite

final class ProjectionTestSuite {
    
    private let projectionEngine = CircularProjectionEngine()
    
    // MARK: - Test Case Generation
    
    private func generateTestCases() -> [ProjectionTestCase] {
        let center = SIMD3<Double>(0.0, 1.0, 0.0)
        
        return [
            // Horizontal circle tests
            ProjectionTestCase(
                name: "Perfect Horizontal Circle",
                points3D: ProjectionTestData.generateHorizontalCircle(center: center, radius: 0.4, samples: 100),
                expectedPlane: .horizontal,
                expectedCircularity: 0.95,
                expectedROMRange: 35...45
            ),
            
            ProjectionTestCase(
                name: "Large Horizontal Circle",
                points3D: ProjectionTestData.generateHorizontalCircle(center: center, radius: 0.8, samples: 120),
                expectedPlane: .horizontal,
                expectedCircularity: 0.95,
                expectedROMRange: 70...90
            ),
            
            // Vertical circle tests
            ProjectionTestCase(
                name: "Perfect Vertical Circle",
                points3D: ProjectionTestData.generateVerticalCircle(center: center, radius: 0.3, samples: 90),
                expectedPlane: .sagittal,
                expectedCircularity: 0.95,
                expectedROMRange: 25...35
            ),
            
            ProjectionTestCase(
                name: "Large Vertical Circle",
                points3D: ProjectionTestData.generateVerticalCircle(center: center, radius: 0.6, samples: 100),
                expectedPlane: .sagittal,
                expectedCircularity: 0.95,
                expectedROMRange: 50...70
            ),
            
            // Frontal circle tests
            ProjectionTestCase(
                name: "Perfect Frontal Circle",
                points3D: ProjectionTestData.generateFrontalCircle(center: center, radius: 0.35, samples: 80),
                expectedPlane: .frontal,
                expectedCircularity: 0.95,
                expectedROMRange: 30...40
            ),
            
            // Tilted circle tests
            ProjectionTestCase(
                name: "Tilted Circle (45° XY)",
                points3D: ProjectionTestData.generateTiltedCircle(
                    center: center,
                    radius: 0.4,
                    normal: simd_normalize(SIMD3<Double>(1, 1, 0)),
                    samples: 100
                ),
                expectedPlane: .optimal,
                expectedCircularity: 0.85,
                expectedROMRange: 30...50,
                tolerance: 0.2
            ),
            
            ProjectionTestCase(
                name: "Tilted Circle (30° XZ)",
                points3D: ProjectionTestData.generateTiltedCircle(
                    center: center,
                    radius: 0.5,
                    normal: simd_normalize(SIMD3<Double>(1, 0, 1)),
                    samples: 90
                ),
                expectedPlane: .optimal,
                expectedCircularity: 0.85,
                expectedROMRange: 40...60,
                tolerance: 0.2
            ),
            
            // Linear motion tests
            ProjectionTestCase(
                name: "3D Linear Motion - Horizontal",
                points3D: ProjectionTestData.generate3DLinearMotion(
                    start: SIMD3<Double>(-0.4, 1.0, 0.0),
                    end: SIMD3<Double>(0.4, 1.0, 0.0),
                    samples: 30
                ),
                expectedPlane: .horizontal,
                expectedCircularity: 0.1,
                expectedROMRange: 15...25
            ),
            
            ProjectionTestCase(
                name: "3D Linear Motion - Vertical",
                points3D: ProjectionTestData.generate3DLinearMotion(
                    start: SIMD3<Double>(0.0, 0.6, 0.0),
                    end: SIMD3<Double>(0.0, 1.4, 0.0),
                    samples: 25
                ),
                expectedPlane: .sagittal,
                expectedCircularity: 0.1,
                expectedROMRange: 20...30
            ),
            
            ProjectionTestCase(
                name: "3D Linear Motion - Diagonal",
                points3D: ProjectionTestData.generate3DLinearMotion(
                    start: SIMD3<Double>(-0.3, 0.8, -0.2),
                    end: SIMD3<Double>(0.3, 1.2, 0.2),
                    samples: 35
                ),
                expectedPlane: .optimal,
                expectedCircularity: 0.2,
                expectedROMRange: 20...35
            ),
            
            // Noisy data tests
            ProjectionTestCase(
                name: "Noisy Horizontal Circle - Low Noise",
                points3D: ProjectionTestData.generateNoisy3DCircle(
                    center: center,
                    radius: 0.4,
                    plane: .horizontal,
                    noiseLevel: 0.02,
                    samples: 80
                ),
                expectedPlane: .horizontal,
                expectedCircularity: 0.8,
                expectedROMRange: 30...50,
                tolerance: 0.15
            ),
            
            ProjectionTestCase(
                name: "Noisy Vertical Circle - Medium Noise",
                points3D: ProjectionTestData.generateNoisy3DCircle(
                    center: center,
                    radius: 0.5,
                    plane: .sagittal,
                    noiseLevel: 0.05,
                    samples: 90
                ),
                expectedPlane: .sagittal,
                expectedCircularity: 0.7,
                expectedROMRange: 40...65,
                tolerance: 0.2
            ),
            
            // Complex motion tests
            ProjectionTestCase(
                name: "3D Spiral Motion",
                points3D: ProjectionTestData.generateSpiral(
                    center: center,
                    radius: 0.3,
                    height: 0.2,
                    turns: 1.5,
                    samples: 100
                ),
                expectedPlane: .optimal,
                expectedCircularity: 0.6,
                expectedROMRange: 25...45,
                tolerance: 0.25
            ),
            
            // Edge cases
            ProjectionTestCase(
                name: "Minimal Samples Circle",
                points3D: ProjectionTestData.generateHorizontalCircle(center: center, radius: 0.3, samples: 15),
                expectedPlane: .horizontal,
                expectedCircularity: 0.9,
                expectedROMRange: 25...35,
                tolerance: 0.2
            ),
            
            ProjectionTestCase(
                name: "Very Small Circle",
                points3D: ProjectionTestData.generateHorizontalCircle(center: center, radius: 0.05, samples: 50),
                expectedPlane: .horizontal,
                expectedCircularity: 0.95,
                expectedROMRange: 3...8,
                tolerance: 0.3
            )
        ]
    }
    
    // MARK: - Test Execution
    
    func runAllTests() -> ProjectionTestSummary {
        let testCases = generateTestCases()
        var results: [ProjectionTestResult] = []
        var totalExecutionTime: TimeInterval = 0
        
        FlexaLog.motion.info("🧪 [ProjectionTest] Starting projection test suite with \(testCases.count) test cases")
        
        for testCase in testCases {
            let result = runSingleTest(testCase)
            results.append(result)
            totalExecutionTime += result.executionTime
            
            let status = result.passed ? "✅ PASS" : "❌ FAIL"
            FlexaLog.motion.info("🧪 [ProjectionTest] \(status) - \(testCase.name)")
            
            if !result.passed {
                for reason in result.failureReasons {
                    FlexaLog.motion.warning("🧪 [ProjectionTest]   └─ \(reason)")
                }
            }
        }
        
        let passedCount = results.filter { $0.passed }.count
        let averageTime = totalExecutionTime / Double(testCases.count)
        
        let summary = ProjectionTestSummary(
            totalTests: testCases.count,
            passedTests: passedCount,
            failedTests: testCases.count - passedCount,
            averageExecutionTime: averageTime,
            results: results
        )
        
        FlexaLog.motion.info("🧪 [ProjectionTest] Test suite completed - Pass rate: \(String(format: "%.1f", summary.passRate * 100))% (\(passedCount)/\(testCases.count))")
        
        return summary
    }
    
    private func runSingleTest(_ testCase: ProjectionTestCase) -> ProjectionTestResult {
        let startTime = Date()
        
        // Run projection
        let projectionResult = projectionEngine.projectCircularMotion(
            points: testCase.points3D,
            preferredPlane: testCase.expectedPlane == .optimal ? .optimal : testCase.expectedPlane
        )
        
        // Calculate ROM
        let calculatedROM = projectionEngine.calculateCircularROM(from: projectionResult)
        
        let executionTime = Date().timeIntervalSince(startTime)
        
        // Validate results
        var failureReasons: [String] = []
        var passed = true
        
        // Check projection plane (only if not optimal)
        if testCase.expectedPlane != .optimal && projectionResult.plane != testCase.expectedPlane {
            failureReasons.append("Projection plane mismatch: expected \(testCase.expectedPlane.description), got \(projectionResult.plane.description)")
            passed = false
        }
        
        // Check circularity score
        if projectionResult.circularityScore < testCase.expectedCircularity - testCase.tolerance {
            failureReasons.append("Circularity too low: \(String(format: "%.2f", projectionResult.circularityScore)) < \(String(format: "%.2f", testCase.expectedCircularity - testCase.tolerance))")
            passed = false
        }
        
        // Check ROM range
        if !testCase.expectedROMRange.contains(calculatedROM) {
            failureReasons.append("ROM out of expected range: \(String(format: "%.1f", calculatedROM))° not in \(testCase.expectedROMRange)")
            passed = false
        }
        
        // Check projection validity
        if !projectionResult.isValid {
            failureReasons.append("Projection result marked as invalid")
            passed = false
        }
        
        return ProjectionTestResult(
            testCase: testCase,
            projectionResult: projectionResult,
            calculatedROM: calculatedROM,
            passed: passed,
            failureReasons: failureReasons,
            executionTime: executionTime
        )
    }
    
    // MARK: - Specific Tests
    
    func testHorizontalCircleProjection() -> Bool {
        let center = SIMD3<Double>(0.0, 1.0, 0.0)
        let points = ProjectionTestData.generateHorizontalCircle(center: center, radius: 0.4, samples: 100)
        
        let result = projectionEngine.projectCircularMotion(points: points)
        
        return result.plane == .horizontal && result.circularityScore >= 0.9 && result.isValid
    }
    
    func testVerticalCircleProjection() -> Bool {
        let center = SIMD3<Double>(0.0, 1.0, 0.0)
        let points = ProjectionTestData.generateVerticalCircle(center: center, radius: 0.3, samples: 80)
        
        let result = projectionEngine.projectCircularMotion(points: points)
        
        return result.plane == .sagittal && result.circularityScore >= 0.9 && result.isValid
    }
    
    func testLinearMotionDetection() -> Bool {
        let points = ProjectionTestData.generate3DLinearMotion(
            start: SIMD3<Double>(-0.3, 1.0, 0.0),
            end: SIMD3<Double>(0.3, 1.0, 0.0),
            samples: 30
        )
        
        let motionType = projectionEngine.detectMotionType(points: points)
        
        return motionType == .linear
    }
    
    func testTiltedCircleHandling() -> Bool {
        let center = SIMD3<Double>(0.0, 1.0, 0.0)
        let points = ProjectionTestData.generateTiltedCircle(
            center: center,
            radius: 0.4,
            normal: simd_normalize(SIMD3<Double>(1, 1, 0)),
            samples: 100
        )
        
        let result = projectionEngine.projectCircularMotion(points: points)
        
        return result.circularityScore >= 0.7 && result.isValid
    }
    
    func testNoisyDataRobustness() -> Bool {
        let center = SIMD3<Double>(0.0, 1.0, 0.0)
        let points = ProjectionTestData.generateNoisy3DCircle(
            center: center,
            radius: 0.4,
            plane: .horizontal,
            noiseLevel: 0.03,
            samples: 80
        )
        
        let result = projectionEngine.projectCircularMotion(points: points)
        
        return result.circularityScore >= 0.6 && result.isValid
    }
    
    // MARK: - Performance Tests
    
    func benchmarkProjectionPerformance(sampleCount: Int = 100) -> TimeInterval {
        let center = SIMD3<Double>(0.0, 1.0, 0.0)
        let points = ProjectionTestData.generateHorizontalCircle(center: center, radius: 0.4, samples: sampleCount)
        
        let startTime = Date()
        _ = projectionEngine.projectCircularMotion(points: points)
        let executionTime = Date().timeIntervalSince(startTime)
        
        FlexaLog.motion.info("🧪 [ProjectionTest] Performance benchmark (\(sampleCount) samples): \(String(format: "%.3f", executionTime * 1000))ms")
        
        return executionTime
    }
}