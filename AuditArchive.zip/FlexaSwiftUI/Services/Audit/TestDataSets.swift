import Foundation
import simd

/// Test data sets with known correct results for audit validation
struct TestDataSets {
    
    // MARK: - Motion Data Test Sets
    
    /// Perfect linear motion data for testing ROM calculations
    static func createLinearMotionData(
        startPosition: SIMD3<Double> = SIMD3(0, 0, 0),
        endPosition: SIMD3<Double> = SIMD3(1, 0, 0),
        duration: TimeInterval = 2.0,
        sampleRate: Double = 30.0
    ) -> TestMotionDataSet {
        let sampleCount = Int(duration * sampleRate)
        let startTime = Date()
        var motionData: [MotionDataPoint] = []
        
        for i in 0..<sampleCount {
            let progress = Double(i) / Double(sampleCount - 1)
            let position = startPosition + (endPosition - startPosition) * progress
            let timestamp = startTime.addingTimeInterval(Double(i) / sampleRate)
            
            // Calculate velocity (constant for linear motion)
            let velocity = (endPosition - startPosition) / duration
            
            motionData.append(MotionDataPoint(
                timestamp: timestamp,
                position: position,
                velocity: velocity,
                acceleration: SIMD3(0, 0, 0)
            ))
        }
        
        let expectedROM = distance(startPosition, endPosition) * 180 / .pi // Convert to degrees if needed
        let expectedSPARC = -1.5 // Expected SPARC for smooth linear motion
        
        return TestMotionDataSet(
            name: "Linear Motion",
            motionData: motionData,
            expectedROM: expectedROM,
            expectedSPARC: expectedSPARC,
            expectedRepCount: 1,
            expectedAIScore: 95.0,
            description: "Perfect linear motion from \(startPosition) to \(endPosition)"
        )
    }
    
    /// Circular motion data for testing circle ROM calculations
    static func createCircularMotionData(
        center: SIMD3<Double> = SIMD3(0, 0, 0),
        radius: Double = 1.0,
        fullCircles: Double = 1.0,
        duration: TimeInterval = 4.0,
        sampleRate: Double = 30.0
    ) -> TestMotionDataSet {
        let sampleCount = Int(duration * sampleRate)
        let startTime = Date()
        var motionData: [MotionDataPoint] = []
        
        let totalAngle = fullCircles * 2 * .pi
        let angularVelocity = totalAngle / duration
        
        for i in 0..<sampleCount {
            let t = Double(i) / sampleRate
            let angle = angularVelocity * t
            
            let position = center + SIMD3(
                radius * cos(angle),
                radius * sin(angle),
                0
            )
            
            let velocity = SIMD3(
                -radius * angularVelocity * sin(angle),
                radius * angularVelocity * cos(angle),
                0
            )
            
            let acceleration = SIMD3(
                -radius * angularVelocity * angularVelocity * cos(angle),
                -radius * angularVelocity * angularVelocity * sin(angle),
                0
            )
            
            let timestamp = startTime.addingTimeInterval(t)
            
            motionData.append(MotionDataPoint(
                timestamp: timestamp,
                position: position,
                velocity: velocity,
                acceleration: acceleration
            ))
        }
        
        let expectedROM = fullCircles * 360.0 // Full circle ROM
        let expectedSPARC = -1.8 // Expected SPARC for smooth circular motion
        
        return TestMotionDataSet(
            name: "Circular Motion",
            motionData: motionData,
            expectedROM: expectedROM,
            expectedSPARC: expectedSPARC,
            expectedRepCount: Int(fullCircles),
            expectedAIScore: 92.0,
            description: "Perfect circular motion with radius \(radius) and \(fullCircles) full circles"
        )
    }
    
    /// Oscillatory motion data for testing rep counting
    static func createOscillatoryMotionData(
        amplitude: Double = 1.0,
        frequency: Double = 0.5, // Hz
        cycles: Double = 3.0,
        duration: TimeInterval = 6.0,
        sampleRate: Double = 30.0
    ) -> TestMotionDataSet {
        let sampleCount = Int(duration * sampleRate)
        let startTime = Date()
        var motionData: [MotionDataPoint] = []
        
        for i in 0..<sampleCount {
            let t = Double(i) / sampleRate
            let angle = 2 * .pi * frequency * t
            
            let position = SIMD3(
                amplitude * sin(angle),
                0,
                0
            )
            
            let velocity = SIMD3(
                amplitude * 2 * .pi * frequency * cos(angle),
                0,
                0
            )
            
            let acceleration = SIMD3(
                -amplitude * pow(2 * .pi * frequency, 2) * sin(angle),
                0,
                0
            )
            
            let timestamp = startTime.addingTimeInterval(t)
            
            motionData.append(MotionDataPoint(
                timestamp: timestamp,
                position: position,
                velocity: velocity,
                acceleration: acceleration
            ))
        }
        
        let expectedROM = amplitude * 2 * 180 / .pi // Peak-to-peak ROM in degrees
        let expectedSPARC = -2.0 // Expected SPARC for smooth oscillation
        
        return TestMotionDataSet(
            name: "Oscillatory Motion",
            motionData: motionData,
            expectedROM: expectedROM,
            expectedSPARC: expectedSPARC,
            expectedRepCount: Int(cycles * 2), // Each cycle has 2 reps (up and down)
            expectedAIScore: 88.0,
            description: "Sinusoidal oscillation with amplitude \(amplitude) and \(cycles) cycles"
        )
    }
    
    /// Noisy motion data for testing robustness
    static func createNoisyMotionData(
        baseMotion: TestMotionDataSet,
        noiseLevel: Double = 0.1
    ) -> TestMotionDataSet {
        var noisyMotionData = baseMotion.motionData
        
        for i in 0..<noisyMotionData.count {
            let noise = SIMD3<Double>(
                Double.random(in: -noiseLevel...noiseLevel),
                Double.random(in: -noiseLevel...noiseLevel),
                Double.random(in: -noiseLevel...noiseLevel)
            )
            
            if let position = noisyMotionData[i].position {
                noisyMotionData[i] = MotionDataPoint(
                    timestamp: noisyMotionData[i].timestamp,
                    position: position + noise,
                    velocity: noisyMotionData[i].velocity,
                    acceleration: noisyMotionData[i].acceleration
                )
            }
        }
        
        return TestMotionDataSet(
            name: "Noisy \(baseMotion.name)",
            motionData: noisyMotionData,
            expectedROM: baseMotion.expectedROM,
            expectedSPARC: baseMotion.expectedSPARC - 0.5, // Noise reduces SPARC
            expectedRepCount: baseMotion.expectedRepCount,
            expectedAIScore: baseMotion.expectedAIScore - 10.0, // Noise reduces AI score
            description: "\(baseMotion.description) with \(noiseLevel) noise level"
        )
    }
    
    // MARK: - Session Data Test Sets
    
    /// Perfect exercise session data
    static func createPerfectSessionData() -> TestSessionDataSet {
        let motionData = createLinearMotionData()
        
        let sessionData = ExerciseSessionData(
            id: "test_perfect_session",
            exerciseType: "arm_raises",
            score: 95,
            reps: 10,
            maxROM: 90.0,
            averageROM: 85.0,
            duration: 120.0, // 2 minutes
            timestamp: Date(),
            romHistory: Array(repeating: 90.0, count: 10), // Perfect 90-degree ROM
            repTimestamps: (0..<10).map { Date().addingTimeInterval(Double($0) * 12) },
            sparcHistory: Array(repeating: -1.5, count: 10), // Good smoothness
            romData: (0..<10).map { ROMPoint(angle: 90.0, timestamp: Date().addingTimeInterval(Double($0) * 12)) },
            sparcData: (0..<10).map { SPARCPoint(sparc: -1.5, timestamp: Date().addingTimeInterval(Double($0) * 12)) },
            aiScore: 95,
            sparcScore: -1.5,
            formScore: 95.0,
            consistency: 0.95,
            peakVelocity: 2.5,
            motionSmoothnessScore: 0.9
        )
        
        return TestSessionDataSet(
            name: "Perfect Session",
            sessionData: sessionData,
            expectedValidation: true,
            expectedDataQuality: DataQualityScore(accuracy: 1.0, completeness: 1.0, consistency: 1.0, timeliness: 1.0),
            description: "Perfect exercise session with ideal metrics"
        )
    }
    
    /// Session data with missing fields
    static func createIncompleteSessionData() -> TestSessionDataSet {
        let sessionData = ExerciseSessionData(
            id: "", // Missing session ID
            exerciseType: "arm_raises",
            score: 150, // Invalid score (out of range)
            reps: -5, // Invalid rep count
            maxROM: 0.0, // Missing ROM data
            averageROM: 0.0,
            duration: -60.0, // Invalid duration
            timestamp: Date(),
            romHistory: [], // Empty ROM history
            repTimestamps: [],
            sparcHistory: [], // Empty SPARC data
            romData: [],
            sparcData: [],
            aiScore: 150, // Invalid AI score (out of range)
            sparcScore: 0.0,
            formScore: 0.0,
            consistency: 0.0,
            peakVelocity: 0.0,
            motionSmoothnessScore: 0.0
        )
        
        return TestSessionDataSet(
            name: "Incomplete Session",
            sessionData: sessionData,
            expectedValidation: false,
            expectedDataQuality: DataQualityScore(accuracy: 0.2, completeness: 0.3, consistency: 0.1, timeliness: 0.0),
            description: "Session with multiple missing and invalid fields"
        )
    }
    
    /// Session data with corrupted metrics
    static func createCorruptedSessionData() -> TestSessionDataSet {
        let sessionData = ExerciseSessionData(
            id: "test_corrupted_session",
            exerciseType: "arm_raises",
            score: 75,
            reps: 10,
            maxROM: Double.nan, // Corrupted max ROM
            averageROM: Double.infinity, // Corrupted average ROM
            duration: 120.0,
            timestamp: Date(),
            romHistory: [Double.nan, Double.infinity, -500.0, 400.0], // Corrupted ROM data
            repTimestamps: (0..<4).map { Date().addingTimeInterval(Double($0) * 30) },
            sparcHistory: [Double.nan, 50.0, -100.0], // Corrupted SPARC data
            romData: [
                ROMPoint(angle: Double.nan, timestamp: Date()),
                ROMPoint(angle: Double.infinity, timestamp: Date()),
                ROMPoint(angle: -500.0, timestamp: Date()),
                ROMPoint(angle: 400.0, timestamp: Date())
            ],
            sparcData: [
                SPARCPoint(sparc: Double.nan, timestamp: Date()),
                SPARCPoint(sparc: 50.0, timestamp: Date()),
                SPARCPoint(sparc: -100.0, timestamp: Date())
            ],
            aiScore: 75,
            sparcScore: Double.nan,
            formScore: 75.0,
            consistency: Double.infinity,
            peakVelocity: -10.0, // Invalid negative velocity
            motionSmoothnessScore: 2.0 // Invalid score > 1.0
        )
        
        return TestSessionDataSet(
            name: "Corrupted Session",
            sessionData: sessionData,
            expectedValidation: false,
            expectedDataQuality: DataQualityScore(accuracy: 0.4, completeness: 0.8, consistency: 0.2, timeliness: 1.0),
            description: "Session with corrupted numeric data"
        )
    }
    
    // MARK: - SPARC Test Data
    
    /// Generate test data for SPARC calculation validation
    static func createSPARCTestData() -> [SPARCTestCase] {
        return [
            SPARCTestCase(
                name: "Smooth Linear Velocity",
                velocityData: Array(stride(from: 0.0, through: 10.0, by: 0.1)),
                expectedSPARC: -1.5,
                tolerance: 0.1,
                description: "Linear velocity profile should have good SPARC score"
            ),
            SPARCTestCase(
                name: "Jerky Motion",
                velocityData: [0, 5, 0, 8, 0, 3, 0, 10, 0],
                expectedSPARC: -5.0,
                tolerance: 1.0,
                description: "Jerky motion should have poor SPARC score"
            ),
            SPARCTestCase(
                name: "Bell Curve Velocity",
                velocityData: generateBellCurveVelocity(samples: 100, peak: 5.0),
                expectedSPARC: -1.2,
                tolerance: 0.2,
                description: "Bell curve velocity profile should have excellent SPARC score"
            )
        ]
    }
    
    private static func generateBellCurveVelocity(samples: Int, peak: Double) -> [Double] {
        let sigma = Double(samples) / 6.0 // Standard deviation
        let mu = Double(samples) / 2.0    // Mean (center)
        
        return (0..<samples).map { i in
            let x = Double(i)
            let exponent = -0.5 * pow((x - mu) / sigma, 2)
            return peak * exp(exponent)
        }
    }
    
    // MARK: - AI Scoring Test Data
    
    /// Generate test cases for AI scoring validation
    static func createAIScoringTestCases() -> [AIScoringTestCase] {
        return [
            AIScoringTestCase(
                name: "Perfect Form",
                motionData: createLinearMotionData().motionData,
                expectedScore: 95.0,
                tolerance: 5.0,
                description: "Perfect linear motion should score highly"
            ),
            AIScoringTestCase(
                name: "Poor Form",
                motionData: createNoisyMotionData(
                    baseMotion: createLinearMotionData(),
                    noiseLevel: 0.5
                ).motionData,
                expectedScore: 60.0,
                tolerance: 10.0,
                description: "Noisy motion should score poorly"
            ),
            AIScoringTestCase(
                name: "Incomplete Motion",
                motionData: Array(createLinearMotionData().motionData.prefix(10)), // Only first 10 points
                expectedScore: 40.0,
                tolerance: 15.0,
                description: "Incomplete motion should score very poorly"
            )
        ]
    }
    
    // MARK: - All Test Sets
    
    /// Get all available test data sets
    static func getAllTestSets() -> TestDataCollection {
        return TestDataCollection(
            motionDataSets: [
                createLinearMotionData(),
                createCircularMotionData(),
                createOscillatoryMotionData(),
                createNoisyMotionData(baseMotion: createLinearMotionData())
            ],
            sessionDataSets: [
                createPerfectSessionData(),
                createIncompleteSessionData(),
                createCorruptedSessionData()
            ],
            sparcTestCases: createSPARCTestData(),
            aiScoringTestCases: createAIScoringTestCases()
        )
    }
}

// MARK: - Test Data Models

struct TestMotionDataSet {
    let name: String
    let motionData: [MotionDataPoint]
    let expectedROM: Double
    let expectedSPARC: Double
    let expectedRepCount: Int
    let expectedAIScore: Double
    let description: String
}

struct TestSessionDataSet {
    let name: String
    let sessionData: ExerciseSessionData
    let expectedValidation: Bool
    let expectedDataQuality: DataQualityScore
    let description: String
}

struct SPARCTestCase {
    let name: String
    let velocityData: [Double]
    let expectedSPARC: Double
    let tolerance: Double
    let description: String
}

struct AIScoringTestCase {
    let name: String
    let motionData: [MotionDataPoint]
    let expectedScore: Double
    let tolerance: Double
    let description: String
}

struct TestDataCollection {
    let motionDataSets: [TestMotionDataSet]
    let sessionDataSets: [TestSessionDataSet]
    let sparcTestCases: [SPARCTestCase]
    let aiScoringTestCases: [AIScoringTestCase]
}

// MARK: - Test Utilities

extension TestDataSets {
    
    /// Validate that a test result matches expected values within tolerance
    static func validateTestResult<T: FloatingPoint>(
        actual: T,
        expected: T,
        tolerance: T,
        testName: String
    ) -> Bool {
        let difference = abs(actual - expected)
        let isValid = difference <= tolerance
        
        if !isValid {
            AuditLogger.shared.logError(
                TestValidationError.resultOutOfTolerance(
                    testName: testName,
                    expected: Double(expected),
                    actual: Double(actual),
                    tolerance: Double(tolerance)
                ),
                context: "Test Validation"
            )
        }
        
        return isValid
    }
    
    /// Run all validation tests and return summary
    static func runAllValidationTests() -> TestValidationSummary {
        let testSets = getAllTestSets()
        var passedTests = 0
        var totalTests = 0
        var failedTests: [String] = []
        
        // Test motion data validation
        for testSet in testSets.motionDataSets {
            totalTests += 1
            let validation = ValidationUtilities.validateMotionData(testSet.motionData)
            if validation.isValid {
                passedTests += 1
            } else {
                failedTests.append("Motion data validation failed for \(testSet.name)")
            }
        }
        
        // Test session data validation
        for testSet in testSets.sessionDataSets {
            totalTests += 1
            let validation = ValidationUtilities.validateSessionData(testSet.sessionData)
            if validation.isValid == testSet.expectedValidation {
                passedTests += 1
            } else {
                failedTests.append("Session data validation failed for \(testSet.name)")
            }
        }
        
        return TestValidationSummary(
            totalTests: totalTests,
            passedTests: passedTests,
            failedTests: failedTests,
            successRate: Double(passedTests) / Double(totalTests)
        )
    }
}

struct TestValidationSummary {
    let totalTests: Int
    let passedTests: Int
    let failedTests: [String]
    let successRate: Double
}

enum TestValidationError: Error {
    case resultOutOfTolerance(testName: String, expected: Double, actual: Double, tolerance: Double)
    
    var localizedDescription: String {
        switch self {
        case .resultOutOfTolerance(let testName, let expected, let actual, let tolerance):
            return "Test '\(testName)' failed: expected \(expected) ± \(tolerance), got \(actual)"
        }
    }
}