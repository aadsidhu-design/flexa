import Foundation
import SwiftUI

// MARK: - Core Audit Framework Protocols

/// Base protocol for all audit validators
protocol AuditValidator {
    associatedtype AuditResult: AuditResultProtocol
    
    /// Performs validation and returns audit result
    func performAudit() async -> AuditResult
    
    /// Returns the name of this validator for logging
    var validatorName: String { get }
}

/// Protocol that all audit results must conform to
protocol AuditResultProtocol {
    var isValid: Bool { get }
    var issues: [AuditIssue] { get }
    var recommendations: [String] { get }
    var timestamp: Date { get }
    var validatorName: String { get }
}

/// Represents an issue found during audit
struct AuditIssue: Identifiable, Codable {
    let id = UUID()
    let severity: AuditSeverity
    let category: AuditCategory
    let description: String
    let details: String?
    let timestamp: Date
    
    init(severity: AuditSeverity, category: AuditCategory, description: String, details: String? = nil) {
        self.severity = severity
        self.category = category
        self.description = description
        self.details = details
        self.timestamp = Date()
    }
}

/// Severity levels for audit issues
enum AuditSeverity: String, CaseIterable, Codable {
    case critical = "Critical"
    case high = "High"
    case medium = "Medium"
    case low = "Low"
    case info = "Info"
    
    var priority: Int {
        switch self {
        case .critical: return 5
        case .high: return 4
        case .medium: return 3
        case .low: return 2
        case .info: return 1
        }
    }
}

/// Categories for audit issues
enum AuditCategory: String, CaseIterable, Codable {
    case aiScoring = "AI Scoring"
    case sparcCalculation = "SPARC Calculation"
    case customExercise = "Custom Exercise"
    case circleROM = "Circle ROM"
    case metricsCollection = "Metrics Collection"
    case dataUpload = "Data Upload"
    case systemHealth = "System Health"
    case dataIntegrity = "Data Integrity"
    case performance = "Performance"
}

// MARK: - Base Audit Result Implementation

/// Base implementation of audit result
struct BaseAuditResult: AuditResultProtocol {
    let isValid: Bool
    let issues: [AuditIssue]
    let recommendations: [String]
    let timestamp: Date
    let validatorName: String
    
    init(isValid: Bool, issues: [AuditIssue], recommendations: [String], validatorName: String) {
        self.isValid = isValid
        self.issues = issues
        self.recommendations = recommendations
        self.timestamp = Date()
        self.validatorName = validatorName
    }
}

// MARK: - Comprehensive System Audit Result

/// Comprehensive audit result containing all system audits
struct SystemAuditResult: AuditResultProtocol {
    let aiScoringAudit: AIScoreAuditResult?
    let sparcAudit: SPARCAuditResult?
    let customExerciseAudit: CustomExerciseAuditResult?
    let circleROMAudit: CircleROMAuditResult?
    let metricsAudit: MetricsAuditResult?
    let uploadAudit: UploadAuditResult?
    let overallHealthScore: Double
    let timestamp: Date
    let validatorName: String
    
    var isValid: Bool {
        let audits: [AuditResultProtocol?] = [
            aiScoringAudit, sparcAudit, customExerciseAudit,
            circleROMAudit, metricsAudit, uploadAudit
        ]
        
        return audits.compactMap { $0 }.allSatisfy { $0.isValid }
    }
    
    var issues: [AuditIssue] {
        let audits: [AuditResultProtocol?] = [
            aiScoringAudit, sparcAudit, customExerciseAudit,
            circleROMAudit, metricsAudit, uploadAudit
        ]
        
        return audits.compactMap { $0 }.flatMap { $0.issues }
    }
    
    var recommendations: [String] {
        let audits: [AuditResultProtocol?] = [
            aiScoringAudit, sparcAudit, customExerciseAudit,
            circleROMAudit, metricsAudit, uploadAudit
        ]
        
        return audits.compactMap { $0 }.flatMap { $0.recommendations }
    }
    
    init(
        aiScoringAudit: AIScoreAuditResult? = nil,
        sparcAudit: SPARCAuditResult? = nil,
        customExerciseAudit: CustomExerciseAuditResult? = nil,
        circleROMAudit: CircleROMAuditResult? = nil,
        metricsAudit: MetricsAuditResult? = nil,
        uploadAudit: UploadAuditResult? = nil,
        overallHealthScore: Double = 0.0
    ) {
        self.aiScoringAudit = aiScoringAudit
        self.sparcAudit = sparcAudit
        self.customExerciseAudit = customExerciseAudit
        self.circleROMAudit = circleROMAudit
        self.metricsAudit = metricsAudit
        self.uploadAudit = uploadAudit
        self.overallHealthScore = overallHealthScore
        self.timestamp = Date()
        self.validatorName = "SystemAuditValidator"
    }
}

// MARK: - Specific Audit Result Types

struct AIScoreAuditResult: AuditResultProtocol {
    let isValid: Bool
    let issues: [AuditIssue]
    let recommendations: [String]
    let timestamp: Date
    let validatorName: String
    let calculatedScore: Double?
    let scoreRange: ClosedRange<Double>?
    let algorithmValidation: AlgorithmValidationResult?
}

struct SPARCAuditResult: AuditResultProtocol {
    let isValid: Bool
    let issues: [AuditIssue]
    let recommendations: [String]
    let timestamp: Date
    let validatorName: String
    let calculatedSPARC: Double?
    let fftResults: [Double]?
    let dataQuality: DataQualityScore?
}

struct CustomExerciseAuditResult: AuditResultProtocol {
    let isValid: Bool
    let issues: [AuditIssue]
    let recommendations: [String]
    let timestamp: Date
    let validatorName: String
    let repCountAccuracy: Double?
    let configValidation: ConfigValidationResult?
}

struct CircleROMAuditResult: AuditResultProtocol {
    let isValid: Bool
    let issues: [AuditIssue]
    let recommendations: [String]
    let timestamp: Date
    let validatorName: String
    let calculatedRange: Double?
    let circularityScore: Double?
    let calibrationValidation: CalibrationValidationResult?
}

struct MetricsAuditResult: AuditResultProtocol {
    let isValid: Bool
    let issues: [AuditIssue]
    let recommendations: [String]
    let timestamp: Date
    let validatorName: String
    let dataIntegrity: DataIntegrityResult?
    let calculationAccuracy: Double?
}

struct UploadAuditResult: AuditResultProtocol {
    let isValid: Bool
    let issues: [AuditIssue]
    let recommendations: [String]
    let timestamp: Date
    let validatorName: String
    let hasRealData: Bool
    let missingFields: [String]
    let uploadSuccess: Bool?
}

// MARK: - Supporting Types

struct AlgorithmValidationResult {
    let isCorrect: Bool
    let expectedResult: Double?
    let actualResult: Double?
    let variance: Double?
}

struct ConfigValidationResult {
    let isValid: Bool
    let missingFields: [String]
    let invalidValues: [String: String]
}

struct CalibrationValidationResult {
    let isValid: Bool
    let baselineAccuracy: Double?
    let calibrationQuality: Double?
}

struct DataIntegrityResult {
    let isIntact: Bool
    let corruptedFields: [String]
    let missingDataPoints: Int
    let dataQuality: DataQualityScore
}

struct DataQualityScore {
    let accuracy: Double        // 0.0 - 1.0
    let completeness: Double    // 0.0 - 1.0
    let consistency: Double     // 0.0 - 1.0
    let timeliness: Double      // 0.0 - 1.0
    
    var overall: Double {
        (accuracy + completeness + consistency + timeliness) / 4.0
    }
}