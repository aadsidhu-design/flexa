import Foundation
import simd

/// Comprehensive validation utilities for data integrity checking
struct ValidationUtilities {
    
    // MARK: - Motion Data Validation
    
    /// Validates motion data points for completeness and accuracy
    static func validateMotionData(_ motionData: [MotionDataPoint]) -> DataValidationResult {
        var issues: [ValidationIssue] = []
        
        // Check for empty data
        if motionData.isEmpty {
            issues.append(ValidationIssue(type: .missingData, description: "Motion data is empty"))
            return DataValidationResult(isValid: false, issues: issues, dataQuality: DataQualityScore(accuracy: 0, completeness: 0, consistency: 0, timeliness: 0))
        }
        
        // Check for minimum data points
        if motionData.count < 10 {
            issues.append(ValidationIssue(type: .insufficientData, description: "Insufficient motion data points: \(motionData.count) (minimum: 10)"))
        }
        
        // Validate timestamps
        let timestampIssues = validateTimestamps(motionData.map { $0.timestamp })
        issues.append(contentsOf: timestampIssues)
        
        // Validate position data
        let positionIssues = validatePositions(motionData.compactMap { $0.position })
        issues.append(contentsOf: positionIssues)
        
        // Check for data gaps
        let gapIssues = validateDataContinuity(motionData)
        issues.append(contentsOf: gapIssues)
        
        // Calculate data quality
        let quality = calculateDataQuality(motionData, issues: issues)
        
        return DataValidationResult(
            isValid: issues.filter { $0.type.severity >= .medium }.isEmpty,
            issues: issues,
            dataQuality: quality
        )
    }
    
    /// Validates exercise session data integrity
    static func validateSessionData(_ sessionData: ExerciseSessionData) -> DataValidationResult {
        var issues: [ValidationIssue] = []
        
        // Validate basic session properties
        if sessionData.id.isEmpty {
            issues.append(ValidationIssue(type: .missingData, description: "Session ID is missing"))
        }
        
        if sessionData.duration < 0 {
            issues.append(ValidationIssue(type: .invalidData, description: "Duration is negative: \(sessionData.duration)"))
        }
        
        // Validate ROM data
        if !sessionData.romHistory.isEmpty {
            let romIssues = validateROMData(sessionData.romHistory)
            issues.append(contentsOf: romIssues)
        }
        
        // Validate max ROM
        if !sessionData.maxROM.isFinite {
            issues.append(ValidationIssue(type: .invalidData, description: "Max ROM is not finite: \(sessionData.maxROM)"))
        } else if sessionData.maxROM < 0 || sessionData.maxROM > 360 {
            issues.append(ValidationIssue(type: .outOfRange, description: "Max ROM out of range: \(sessionData.maxROM) (expected: 0-360)"))
        }
        
        // Validate average ROM
        if !sessionData.averageROM.isFinite {
            issues.append(ValidationIssue(type: .invalidData, description: "Average ROM is not finite: \(sessionData.averageROM)"))
        } else if sessionData.averageROM < 0 || sessionData.averageROM > 360 {
            issues.append(ValidationIssue(type: .outOfRange, description: "Average ROM out of range: \(sessionData.averageROM) (expected: 0-360)"))
        }
        
        // Validate SPARC data
        if !sessionData.sparcHistory.isEmpty {
            let sparcIssues = validateSPARCData(sessionData.sparcHistory)
            issues.append(contentsOf: sparcIssues)
        }
        
        // Validate SPARC score
        if !sessionData.sparcScore.isFinite {
            issues.append(ValidationIssue(type: .invalidData, description: "SPARC score is not finite: \(sessionData.sparcScore)"))
        } else if sessionData.sparcScore > 0 || sessionData.sparcScore < -10 {
            issues.append(ValidationIssue(type: .outOfRange, description: "SPARC score out of range: \(sessionData.sparcScore) (expected: -10 to 0)"))
        }
        
        // Validate rep count
        if sessionData.reps < 0 {
            issues.append(ValidationIssue(type: .invalidData, description: "Negative rep count: \(sessionData.reps)"))
        }
        
        // Validate scores
        if let aiScore = sessionData.aiScore {
            if aiScore < 0 || aiScore > 100 {
                issues.append(ValidationIssue(type: .invalidData, description: "AI score out of range: \(aiScore) (expected: 0-100)"))
            }
        }
        
        if sessionData.score < 0 || sessionData.score > 100 {
            issues.append(ValidationIssue(type: .invalidData, description: "Score out of range: \(sessionData.score) (expected: 0-100)"))
        }
        
        if sessionData.formScore < 0 || sessionData.formScore > 100 {
            issues.append(ValidationIssue(type: .outOfRange, description: "Form score out of range: \(sessionData.formScore) (expected: 0-100)"))
        }
        
        // Validate consistency
        if !sessionData.consistency.isFinite {
            issues.append(ValidationIssue(type: .invalidData, description: "Consistency is not finite: \(sessionData.consistency)"))
        } else if sessionData.consistency < 0 || sessionData.consistency > 1 {
            issues.append(ValidationIssue(type: .outOfRange, description: "Consistency out of range: \(sessionData.consistency) (expected: 0-1)"))
        }
        
        // Validate peak velocity
        if !sessionData.peakVelocity.isFinite {
            issues.append(ValidationIssue(type: .invalidData, description: "Peak velocity is not finite: \(sessionData.peakVelocity)"))
        } else if sessionData.peakVelocity < 0 {
            issues.append(ValidationIssue(type: .invalidData, description: "Peak velocity is negative: \(sessionData.peakVelocity)"))
        }
        
        // Validate motion smoothness score
        if !sessionData.motionSmoothnessScore.isFinite {
            issues.append(ValidationIssue(type: .invalidData, description: "Motion smoothness score is not finite: \(sessionData.motionSmoothnessScore)"))
        } else if sessionData.motionSmoothnessScore < 0 || sessionData.motionSmoothnessScore > 1 {
            issues.append(ValidationIssue(type: .outOfRange, description: "Motion smoothness score out of range: \(sessionData.motionSmoothnessScore) (expected: 0-1)"))
        }
        
        // Validate timestamp arrays consistency
        if sessionData.romHistory.count != sessionData.repTimestamps.count {
            issues.append(ValidationIssue(type: .invalidData, description: "ROM history and rep timestamps count mismatch: \(sessionData.romHistory.count) vs \(sessionData.repTimestamps.count)"))
        }
        
        let quality = calculateSessionDataQuality(sessionData, issues: issues)
        
        return DataValidationResult(
            isValid: issues.filter { $0.type.severity >= .medium }.isEmpty,
            issues: issues,
            dataQuality: quality
        )
    }
    
    // MARK: - Numeric Validation
    
    /// Validates numeric values are within expected ranges
    static func validateNumericRange<T: Comparable>(_ value: T, range: ClosedRange<T>, fieldName: String) -> ValidationIssue? {
        if !range.contains(value) {
            return ValidationIssue(type: .outOfRange, description: "\(fieldName) value \(value) is outside expected range \(range)")
        }
        return nil
    }
    
    /// Validates array of numeric values for outliers and anomalies
    static func validateNumericArray(_ values: [Double], fieldName: String, expectedRange: ClosedRange<Double>? = nil) -> [ValidationIssue] {
        var issues: [ValidationIssue] = []
        
        if values.isEmpty {
            issues.append(ValidationIssue(type: .missingData, description: "\(fieldName) array is empty"))
            return issues
        }
        
        // Check for NaN or infinite values
        let invalidValues = values.enumerated().filter { !$0.element.isFinite }
        for (index, value) in invalidValues {
            issues.append(ValidationIssue(type: .invalidData, description: "\(fieldName)[\(index)] contains invalid value: \(value)"))
        }
        
        // Check range if provided
        if let range = expectedRange {
            let outOfRangeValues = values.enumerated().filter { !range.contains($0.element) }
            for (index, value) in outOfRangeValues {
                issues.append(ValidationIssue(type: .outOfRange, description: "\(fieldName)[\(index)] value \(value) is outside expected range \(range)"))
            }
        }
        
        // Check for statistical outliers
        let outliers = detectOutliers(values)
        if !outliers.isEmpty {
            issues.append(ValidationIssue(type: .statisticalAnomaly, description: "\(fieldName) contains \(outliers.count) statistical outliers"))
        }
        
        return issues
    }
    
    // MARK: - Timestamp Validation
    
    private static func validateTimestamps(_ timestamps: [Date]) -> [ValidationIssue] {
        var issues: [ValidationIssue] = []
        
        if timestamps.isEmpty {
            issues.append(ValidationIssue(type: .missingData, description: "No timestamps found"))
            return issues
        }
        
        // Check for chronological order
        for i in 1..<timestamps.count {
            if timestamps[i] < timestamps[i-1] {
                issues.append(ValidationIssue(type: .invalidData, description: "Timestamps not in chronological order at index \(i)"))
            }
        }
        
        // Check for reasonable time intervals
        if timestamps.count > 1 {
            let intervals = zip(timestamps.dropFirst(), timestamps).map { $0.timeIntervalSince($1) }
            let avgInterval = intervals.reduce(0, +) / Double(intervals.count)
            
            // Flag intervals that are too large (> 5x average) or too small (< 0.1x average)
            let anomalousIntervals = intervals.enumerated().filter { 
                $0.element > avgInterval * 5 || $0.element < avgInterval * 0.1 
            }
            
            for (index, interval) in anomalousIntervals {
                issues.append(ValidationIssue(type: .temporalAnomaly, description: "Unusual time interval at index \(index): \(interval)s (avg: \(avgInterval)s)"))
            }
        }
        
        return issues
    }
    
    // MARK: - Position Data Validation
    
    private static func validatePositions(_ positions: [SIMD3<Double>]) -> [ValidationIssue] {
        var issues: [ValidationIssue] = []
        
        if positions.isEmpty {
            issues.append(ValidationIssue(type: .missingData, description: "No position data found"))
            return issues
        }
        
        // Check for invalid coordinates
        for (index, position) in positions.enumerated() {
            if !position.x.isFinite || !position.y.isFinite || !position.z.isFinite {
                issues.append(ValidationIssue(type: .invalidData, description: "Invalid position at index \(index): \(position)"))
            }
        }
        
        // Check for unrealistic position values (assuming normalized coordinates)
        let unrealisticPositions = positions.enumerated().filter { 
            abs($0.element.x) > 10 || abs($0.element.y) > 10 || abs($0.element.z) > 10 
        }
        
        for (index, position) in unrealisticPositions {
            issues.append(ValidationIssue(type: .outOfRange, description: "Unrealistic position at index \(index): \(position)"))
        }
        
        return issues
    }
    
    // MARK: - Data Continuity Validation
    
    private static func validateDataContinuity(_ motionData: [MotionDataPoint]) -> [ValidationIssue] {
        var issues: [ValidationIssue] = []
        
        if motionData.count < 2 {
            return issues
        }
        
        // Calculate expected time interval
        let totalDuration = motionData.last!.timestamp.timeIntervalSince(motionData.first!.timestamp)
        let expectedInterval = totalDuration / Double(motionData.count - 1)
        
        // Find gaps larger than 3x expected interval
        for i in 1..<motionData.count {
            let actualInterval = motionData[i].timestamp.timeIntervalSince(motionData[i-1].timestamp)
            if actualInterval > expectedInterval * 3 {
                issues.append(ValidationIssue(type: .dataGap, description: "Data gap detected between indices \(i-1) and \(i): \(actualInterval)s"))
            }
        }
        
        return issues
    }
    
    // MARK: - ROM Data Validation
    
    private static func validateROMData(_ romData: [Double]) -> [ValidationIssue] {
        return validateNumericArray(romData, fieldName: "ROM", expectedRange: 0...360)
    }
    
    // MARK: - SPARC Data Validation
    
    private static func validateSPARCData(_ sparcData: [Double]) -> [ValidationIssue] {
        return validateNumericArray(sparcData, fieldName: "SPARC", expectedRange: -10...0)
    }
    
    // MARK: - Statistical Analysis
    
    private static func detectOutliers(_ values: [Double]) -> [Int] {
        guard values.count > 4 else { return [] }
        
        let sortedValues = values.sorted()
        let q1Index = sortedValues.count / 4
        let q3Index = 3 * sortedValues.count / 4
        
        let q1 = sortedValues[q1Index]
        let q3 = sortedValues[q3Index]
        let iqr = q3 - q1
        
        let lowerBound = q1 - 1.5 * iqr
        let upperBound = q3 + 1.5 * iqr
        
        return values.enumerated().compactMap { index, value in
            (value < lowerBound || value > upperBound) ? index : nil
        }
    }
    
    // MARK: - Data Quality Calculation
    
    private static func calculateDataQuality(_ motionData: [MotionDataPoint], issues: [ValidationIssue]) -> DataQualityScore {
        let totalPoints = motionData.count
        let criticalIssues = issues.filter { $0.type.severity >= .high }.count
        let mediumIssues = issues.filter { $0.type.severity == .medium }.count
        
        // Calculate accuracy (1.0 - weighted issue ratio)
        let accuracy = max(0.0, 1.0 - (Double(criticalIssues) * 0.5 + Double(mediumIssues) * 0.2) / Double(totalPoints))
        
        // Calculate completeness (ratio of valid data points)
        let validPoints = motionData.filter { $0.position != nil && $0.timestamp.timeIntervalSince1970 > 0 }.count
        let completeness = Double(validPoints) / Double(totalPoints)
        
        // Calculate consistency (based on temporal continuity)
        let gapIssues = issues.filter { $0.type == .dataGap || $0.type == .temporalAnomaly }.count
        let consistency = max(0.0, 1.0 - Double(gapIssues) / Double(totalPoints))
        
        // Calculate timeliness (based on timestamp validity)
        let timestampIssues = issues.filter { $0.type == .temporalAnomaly }.count
        let timeliness = max(0.0, 1.0 - Double(timestampIssues) / Double(totalPoints))
        
        return DataQualityScore(
            accuracy: accuracy,
            completeness: completeness,
            consistency: consistency,
            timeliness: timeliness
        )
    }
    
    private static func calculateSessionDataQuality(_ sessionData: ExerciseSessionData, issues: [ValidationIssue]) -> DataQualityScore {
        let criticalIssues = issues.filter { $0.type.severity >= .high }.count
        let mediumIssues = issues.filter { $0.type.severity == .medium }.count
        
        // Base quality on issue count and data completeness
        let accuracy = max(0.0, 1.0 - Double(criticalIssues) * 0.3 - Double(mediumIssues) * 0.1)
        
        var completenessScore = 1.0
        if sessionData.romHistory.isEmpty { completenessScore -= 0.2 }
        if sessionData.sparcHistory.isEmpty { completenessScore -= 0.2 }
        if sessionData.aiScore == nil { completenessScore -= 0.2 }
        if sessionData.reps == 0 { completenessScore -= 0.2 }
        if sessionData.duration <= 0 { completenessScore -= 0.2 }
        
        let consistency = max(0.0, 1.0 - Double(issues.filter { $0.type == .invalidData }.count) * 0.2)
        let timeliness = sessionData.duration > 0 ? 1.0 : 0.0
        
        return DataQualityScore(
            accuracy: accuracy,
            completeness: max(0.0, completenessScore),
            consistency: consistency,
            timeliness: timeliness
        )
    }
}

// MARK: - Supporting Types

struct DataValidationResult {
    let isValid: Bool
    let issues: [ValidationIssue]
    let dataQuality: DataQualityScore
}

struct ValidationIssue {
    let type: ValidationIssueType
    let description: String
    let timestamp: Date
    
    init(type: ValidationIssueType, description: String) {
        self.type = type
        self.description = description
        self.timestamp = Date()
    }
}

enum ValidationIssueType {
    case missingData
    case insufficientData
    case invalidData
    case outOfRange
    case dataGap
    case temporalAnomaly
    case statisticalAnomaly
    
    var severity: ValidationSeverity {
        switch self {
        case .missingData, .invalidData:
            return .high
        case .insufficientData, .outOfRange, .dataGap:
            return .medium
        case .temporalAnomaly, .statisticalAnomaly:
            return .low
        }
    }
}

enum ValidationSeverity: Int, Comparable {
    case low = 1
    case medium = 2
    case high = 3
    case critical = 4
    
    static func < (lhs: ValidationSeverity, rhs: ValidationSeverity) -> Bool {
        return lhs.rawValue < rhs.rawValue
    }
}

// MARK: - Motion Data Point (if not already defined)

struct MotionDataPoint {
    let timestamp: Date
    let position: SIMD3<Double>?
    let velocity: SIMD3<Double>?
    let acceleration: SIMD3<Double>?
    
    init(timestamp: Date, position: SIMD3<Double>? = nil, velocity: SIMD3<Double>? = nil, acceleration: SIMD3<Double>? = nil) {
        self.timestamp = timestamp
        self.position = position
        self.velocity = velocity
        self.acceleration = acceleration
    }
}