import Foundation
import SwiftUI

/// Integrates AI scoring with existing motion analysis services
/// Bridges the gap between motion tracking and score calculation
@MainActor class ScoreIntegrationService: ObservableObject {
    static let shared = ScoreIntegrationService()
    
    // MARK: - Dependencies
    private let aiScoreCalculator = AIScoreCalculator.shared
    private let movementAnalyzer = MovementPatternAnalyzer()
    
    // MARK: - Published State
    @Published var lastCalculatedScores: AIScoreCalculator.AIScoreResult?
    @Published var isCalculatingScores: Bool = false
    
    private init() {}
    
    // MARK: - Main Integration Method
    
    /// Calculate comprehensive AI scores by integrating all motion analysis services
    func calculateIntegratedScores(
        for sessionData: ExerciseSessionData,
        motionService: SimpleMotionService? = nil
    ) async -> ExerciseSessionData {
        
        await MainActor.run {
            isCalculatingScores = true
        }
        
        FlexaLog.gemini.info("🔗 [ScoreIntegration] Calculating integrated AI scores for session: \(sessionData.exerciseType)")
        
        do {
            // Step 1: Gather motion analysis data
            let analysisData = await gatherMotionAnalysisData(
                sessionData: sessionData,
                motionService: motionService
            )
            
            // Step 2: Calculate AI scores
            let scoreResult = aiScoreCalculator.calculateAIScore(
                sessionData: sessionData,
                movementQuality: analysisData.movementQuality,
                sparcValues: analysisData.sparcValues,
                compensatoryMovements: analysisData.compensatoryMovements
            )
            
            // Step 3: Create updated session data with real AI scores
            let updatedSessionData = createUpdatedSessionData(
                originalData: sessionData,
                scoreResult: scoreResult
            )
            
            await MainActor.run {
                self.lastCalculatedScores = scoreResult
                self.isCalculatingScores = false
            }
            
            FlexaLog.gemini.info("✅ [ScoreIntegration] AI scores calculated - AI: \(Int(scoreResult.aiScore))%, Form: \(Int(scoreResult.formScore))%, Smoothness: \(Int(scoreResult.smoothnessScore))%, Consistency: \(Int(scoreResult.consistencyScore))%")
            
            return updatedSessionData
            
        } catch {
            FlexaLog.gemini.error("❌ [ScoreIntegration] Score calculation failed: \(error.localizedDescription)")
            
            // Return fallback scores
            let fallbackResult = aiScoreCalculator.getFallbackScore(
                for: sessionData.exerciseType,
                sessionDuration: sessionData.duration
            )
            
            let updatedSessionData = createUpdatedSessionData(
                originalData: sessionData,
                scoreResult: fallbackResult
            )
            
            await MainActor.run {
                self.lastCalculatedScores = fallbackResult
                self.isCalculatingScores = false
            }
            
            return updatedSessionData
        }
    }
    
    // MARK: - Motion Analysis Data Gathering
    
    private struct MotionAnalysisData {
        let movementQuality: Double?
        let sparcValues: [Double]?
        let compensatoryMovements: [CompensatoryMovement]?
        let additionalMetrics: [String: Double]
    }
    
    private func gatherMotionAnalysisData(
        sessionData: ExerciseSessionData,
        motionService: SimpleMotionService?
    ) async -> MotionAnalysisData {
        
        FlexaLog.gemini.debug("📊 [ScoreIntegration] Gathering motion analysis data...")
        
        var movementQuality: Double? = nil
        var sparcValues: [Double]? = nil
        var compensatoryMovements: [CompensatoryMovement]? = nil
        var additionalMetrics: [String: Double] = [:]
        
        // Try to get movement quality from MovementPatternAnalyzer
        movementQuality = await getMovementQualityScore(sessionData: sessionData)
        
        // Try to get SPARC values from various sources
        sparcValues = await getSPARCValues(sessionData: sessionData, motionService: motionService)
        
        // Try to get compensatory movement data
        compensatoryMovements = await getCompensatoryMovements(sessionData: sessionData)
        
        // Gather additional metrics
        additionalMetrics["averageROM"] = sessionData.averageROM
        additionalMetrics["maxROM"] = sessionData.maxROM
        additionalMetrics["repCount"] = Double(sessionData.reps)
        additionalMetrics["duration"] = sessionData.duration
        additionalMetrics["peakVelocity"] = sessionData.peakVelocity
        
        FlexaLog.gemini.debug("📊 [ScoreIntegration] Gathered data - Quality: \(movementQuality?.description ?? "nil"), SPARC count: \(sparcValues?.count ?? 0), Compensatory movements: \(compensatoryMovements?.count ?? 0)")
        
        return MotionAnalysisData(
            movementQuality: movementQuality,
            sparcValues: sparcValues,
            compensatoryMovements: compensatoryMovements,
            additionalMetrics: additionalMetrics
        )
    }
    
    private func getMovementQualityScore(sessionData: ExerciseSessionData) async -> Double? {
        // In a real implementation, we would need to run MovementPatternAnalyzer
        // on the session's pose data. For now, we'll estimate based on available data.
        
        // Check if we have any indication of movement quality issues
        if sessionData.averageROM < 30 {
            return 40.0 // Poor ROM suggests poor movement quality
        } else if sessionData.averageROM > 70 {
            return 85.0 // Good ROM suggests good movement quality
        } else {
            return 65.0 // Moderate ROM suggests moderate quality
        }
    }
    
    private func getSPARCValues(
        sessionData: ExerciseSessionData,
        motionService: SimpleMotionService?
    ) async -> [Double]? {
        
        // Try session SPARC history first
        if !sessionData.sparcHistory.isEmpty {
            FlexaLog.gemini.debug("📊 [ScoreIntegration] Using session SPARC history: \(sessionData.sparcHistory.count) values")
            return sessionData.sparcHistory
        }
        
        // Try overall session SPARC score
        if sessionData.sparcScore > 0 {
            FlexaLog.gemini.debug("📊 [ScoreIntegration] Using session SPARC score: \(sessionData.sparcScore)")
            return [sessionData.sparcScore]
        }
        
        // Try to get from motion service if available
        if let motionService = motionService {
            // In a real implementation, we would access SPARC data from the motion service
            FlexaLog.gemini.debug("📊 [ScoreIntegration] Motion service available but SPARC integration needed")
        }
        
        FlexaLog.gemini.debug("📊 [ScoreIntegration] No SPARC data available")
        return nil
    }
    
    private func getCompensatoryMovements(sessionData: ExerciseSessionData) async -> [CompensatoryMovement]? {
        // In a real implementation, we would need to analyze pose data for compensatory movements
        // For now, we'll make educated guesses based on available metrics
        
        var movements: [CompensatoryMovement] = []
        
        // Check for potential issues based on ROM patterns
        if !sessionData.romHistory.isEmpty {
            let romVariance = calculateROMVariance(sessionData.romHistory)
            
            if romVariance > 15 { // High variance suggests inconsistent movement
                movements.append(CompensatoryMovement(
                    type: .shoulderHiking,
                    severity: min(1.0, romVariance / 20.0),
                    description: "Inconsistent ROM suggests possible compensatory movements"
                ))
            }
        }
        
        // Check for potential trunk lean based on low average ROM
        if sessionData.averageROM < 40 && sessionData.maxROM > 60 {
            movements.append(CompensatoryMovement(
                type: .trunkLean,
                severity: 0.6,
                description: "Large difference between average and max ROM suggests compensatory patterns"
            ))
        }
        
        return movements.isEmpty ? nil : movements
    }
    
    private func calculateROMVariance(_ romValues: [Double]) -> Double {
        guard romValues.count > 1 else { return 0 }
        
        let mean = romValues.reduce(0, +) / Double(romValues.count)
        let variance = romValues.map { pow($0 - mean, 2) }.reduce(0, +) / Double(romValues.count)
        return sqrt(variance)
    }
    
    // MARK: - Session Data Update
    
    private func createUpdatedSessionData(
        originalData: ExerciseSessionData,
        scoreResult: AIScoreCalculator.AIScoreResult
    ) -> ExerciseSessionData {
        
        // Create new session data with calculated AI scores
        return ExerciseSessionData(
            id: originalData.id,
            exerciseType: originalData.exerciseType,
            score: originalData.score, // Keep original game score
            reps: originalData.reps,
            maxROM: originalData.maxROM,
            averageROM: originalData.averageROM,
            duration: originalData.duration,
            timestamp: originalData.timestamp,
            romHistory: originalData.romHistory,
            repTimestamps: originalData.repTimestamps,
            sparcHistory: originalData.sparcHistory,
            romData: originalData.romData,
            sparcData: originalData.sparcData,
            aiScore: Int(scoreResult.aiScore), // ✅ NOW CALCULATED
            painPre: originalData.painPre,
            painPost: originalData.painPost,
            sparcScore: originalData.sparcScore,
            formScore: scoreResult.formScore, // ✅ NOW CALCULATED
            consistency: scoreResult.consistencyScore, // ✅ NOW CALCULATED
            peakVelocity: originalData.peakVelocity,
            motionSmoothnessScore: scoreResult.smoothnessScore, // ✅ NOW CALCULATED
            accelAvgMagnitude: originalData.accelAvgMagnitude,
            accelPeakMagnitude: originalData.accelPeakMagnitude,
            gyroAvgMagnitude: originalData.gyroAvgMagnitude,
            gyroPeakMagnitude: originalData.gyroPeakMagnitude,
            aiFeedback: generateAIFeedback(scoreResult: scoreResult),
            goalsAfter: originalData.goalsAfter
        )
    }
    
    private func generateAIFeedback(scoreResult: AIScoreCalculator.AIScoreResult) -> String {
        var feedback = "AI Analysis: \(scoreResult.quality.description)\n\n"
        
        feedback += "Score Breakdown:\n"
        feedback += "• Form: \(Int(scoreResult.formScore))%\n"
        feedback += "• Smoothness: \(Int(scoreResult.smoothnessScore))%\n"
        feedback += "• Consistency: \(Int(scoreResult.consistencyScore))%\n\n"
        
        if !scoreResult.recommendations.isEmpty {
            feedback += "Recommendations:\n"
            for recommendation in scoreResult.recommendations.prefix(3) {
                feedback += "• \(recommendation)\n"
            }
        }
        
        return feedback
    }
    
    // MARK: - Validation Methods
    
    /// Validate that AI scores are properly calculated and not placeholder values
    func validateScoreIntegrity(sessionData: ExerciseSessionData) -> ScoreIntegrityResult {
        var issues: [String] = []
        var isValid = true
        
        // Check AI Score
        if sessionData.aiScore == nil {
            issues.append("aiScore is nil - should be calculated")
            isValid = false
        } else if let aiScore = sessionData.aiScore, aiScore == 0 {
            issues.append("aiScore is 0 - may be placeholder")
        }
        
        // Check Form Score
        if sessionData.formScore == 0 {
            issues.append("formScore is 0 - should be calculated from movement analysis")
            isValid = false
        }
        
        // Check Motion Smoothness Score
        if sessionData.motionSmoothnessScore == 0 {
            issues.append("motionSmoothnessScore is 0 - should be calculated from SPARC")
            isValid = false
        }
        
        // Check Consistency
        if sessionData.consistency == 0 && sessionData.romHistory.count > 1 {
            issues.append("consistency is 0 despite having ROM history - should be calculated")
            isValid = false
        }
        
        return ScoreIntegrityResult(
            isValid: isValid,
            issues: issues,
            hasRealAIScore: sessionData.aiScore != nil && sessionData.aiScore != 0,
            hasRealFormScore: sessionData.formScore > 0,
            hasRealSmoothnessScore: sessionData.motionSmoothnessScore > 0,
            hasRealConsistencyScore: sessionData.consistency > 0
        )
    }
    
    struct ScoreIntegrityResult {
        let isValid: Bool
        let issues: [String]
        let hasRealAIScore: Bool
        let hasRealFormScore: Bool
        let hasRealSmoothnessScore: Bool
        let hasRealConsistencyScore: Bool
        
        var summary: String {
            let validScores = [
                hasRealAIScore ? "AI" : nil,
                hasRealFormScore ? "Form" : nil,
                hasRealSmoothnessScore ? "Smoothness" : nil,
                hasRealConsistencyScore ? "Consistency" : nil
            ].compactMap { $0 }
            
            return "Valid scores: \(validScores.joined(separator: ", "))"
        }
    }
    
    // MARK: - Batch Processing
    
    /// Process multiple sessions to update their AI scores
    func batchUpdateScores(sessions: [ExerciseSessionData]) async -> [ExerciseSessionData] {
        FlexaLog.gemini.info("🔄 [ScoreIntegration] Batch updating \(sessions.count) sessions")
        
        var updatedSessions: [ExerciseSessionData] = []
        
        for (index, session) in sessions.enumerated() {
            FlexaLog.gemini.debug("🔄 [ScoreIntegration] Processing session \(index + 1)/\(sessions.count)")
            
            let updatedSession = await calculateIntegratedScores(for: session)
            updatedSessions.append(updatedSession)
            
            // Small delay to prevent overwhelming the system
            try? await Task.sleep(nanoseconds: 100_000_000) // 0.1 seconds
        }
        
        FlexaLog.gemini.info("✅ [ScoreIntegration] Batch update completed")
        return updatedSessions
    }
}