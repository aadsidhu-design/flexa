//
//  CircularROMTestSuite.swift
//  FlexaSwiftUI
//
//  Created by Kiro on 10/13/25.
//
//  🧪 CIRCULAR ROM TEST SUITE
//  Comprehensive testing for circular ROM calculation accuracy
//

import Foundation
import simd

// MARK: - Test Data Generator

struct CircularROMTestData {
    static func generatePerfectCircle(center: SIMD3<Double>, radius: Double, samples: Int = 100) -> [SIMD3<Double>] {
        var positions: [SIMD3<Double>] = []
        
        for i in 0..<samples {
            let angle = 2.0 * .pi * Double(i) / Double(samples)
            let x = center.x + radius * cos(angle)
            let z = center.z + radius * sin(angle)
            positions.append(SIMD3<Double>(x, center.y, z))
        }
        
        return positions
    }
    
    static func generatePartialCircle(center: SIMD3<Double>, radius: Double, startAngle: Double, endAngle: Double, samples: Int = 50) -> [SIMD3<Double>] {
        var positions: [SIMD3<Double>] = []
        
        let angleRange = endAngle - startAngle
        for i in 0..<samples {
            let angle = startAngle + angleRange * Double(i) / Double(samples - 1)
            let x = center.x + radius * cos(angle)
            let z = center.z + radius * sin(angle)
            positions.append(SIMD3<Double>(x, center.y, z))
        }
        
        return positions
    }
    
    static func generateLinearMotion(start: SIMD3<Double>, end: SIMD3<Double>, samples: Int = 30) -> [SIMD3<Double>] {
        var positions: [SIMD3<Double>] = []
        
        for i in 0..<samples {
            let t = Double(i) / Double(samples - 1)
            let position = start + t * (end - start)
            positions.append(position)
        }
        
        return positions
    }
    
    static func generateNoisyCircle(center: SIMD3<Double>, radius: Double, noiseLevel: Double, samples: Int = 80) -> [SIMD3<Double>] {
        var positions: [SIMD3<Double>] = []
        
        for i in 0..<samples {
            let angle = 2.0 * .pi * Double(i) / Double(samples)
            let noisyRadius = radius + (Double.random(in: -1...1) * noiseLevel)
            let x = center.x + noisyRadius * cos(angle)
            let z = center.z + noisyRadius * sin(angle)
            positions.append(SIMD3<Double>(x, center.y, z))
        }
        
        return positions
    }
    
    static func generateEllipticalMotion(center: SIMD3<Double>, radiusX: Double, radiusZ: Double, samples: Int = 90) -> [SIMD3<Double>] {
        var positions: [SIMD3<Double>] = []
        
        for i in 0..<samples {
            let angle = 2.0 * .pi * Double(i) / Double(samples)
            let x = center.x + radiusX * cos(angle)
            let z = center.z + radiusZ * sin(angle)
            positions.append(SIMD3<Double>(x, center.y, z))
        }
        
        return positions
    }
}

// MARK: - Test Case Structure

struct CircularROMTestCase {
    let name: String
    let positions: [SIMD3<Double>]
    let expectedMotionType: CircularMotionType
    let expectedROMRange: ClosedRange<Double>
    let expectedRadius: Double?
    let tolerance: Double
    
    init(name: String, positions: [SIMD3<Double>], expectedMotionType: CircularMotionType, expectedROMRange: ClosedRange<Double>, expectedRadius: Double? = nil, tolerance: Double = 0.1) {
        self.name = name
        self.positions = positions
        self.expectedMotionType = expectedMotionType
        self.expectedROMRange = expectedROMRange
        self.expectedRadius = expectedRadius
        self.tolerance = tolerance
    }
}

// MARK: - Test Results

struct CircularROMTestResult {
    let testCase: CircularROMTestCase
    let auditResult: CircleROMAuditResult
    let passed: Bool
    let failureReasons: [String]
    let executionTime: TimeInterval
}

struct CircularROMTestSummary {
    let totalTests: Int
    let passedTests: Int
    let failedTests: Int
    let averageExecutionTime: TimeInterval
    let results: [CircularROMTestResult]
    
    var passRate: Double {
        return totalTests > 0 ? Double(passedTests) / Double(totalTests) : 0.0
    }
}

// MARK: - Circular ROM Test Suite

final class CircularROMTestSuite {
    
    private let audit = CircleROMAudit()
    
    // MARK: - Test Cases
    
    private func generateTestCases() -> [CircularROMTestCase] {
        let center = SIMD3<Double>(0.0, 1.0, 0.0)
        
        return [
            // Perfect circle tests
            CircularROMTestCase(
                name: "Perfect Circle - Small Radius",
                positions: CircularROMTestData.generatePerfectCircle(center: center, radius: 0.2, samples: 100),
                expectedMotionType: .fullCircle,
                expectedROMRange: 15...25,
                expectedRadius: 0.2,
                tolerance: 0.05
            ),
            
            CircularROMTestCase(
                name: "Perfect Circle - Medium Radius",
                positions: CircularROMTestData.generatePerfectCircle(center: center, radius: 0.5, samples: 120),
                expectedMotionType: .fullCircle,
                expectedROMRange: 40...60,
                expectedRadius: 0.5,
                tolerance: 0.05
            ),
            
            CircularROMTestCase(
                name: "Perfect Circle - Large Radius",
                positions: CircularROMTestData.generatePerfectCircle(center: center, radius: 0.8, samples: 150),
                expectedMotionType: .fullCircle,
                expectedROMRange: 70...90,
                expectedRadius: 0.8,
                tolerance: 0.05
            ),
            
            // Partial circle tests
            CircularROMTestCase(
                name: "Quarter Circle (90°)",
                positions: CircularROMTestData.generatePartialCircle(center: center, radius: 0.4, startAngle: 0, endAngle: .pi/2, samples: 30),
                expectedMotionType: .partialCircle,
                expectedROMRange: 80...100,
                expectedRadius: 0.4,
                tolerance: 0.1
            ),
            
            CircularROMTestCase(
                name: "Half Circle (180°)",
                positions: CircularROMTestData.generatePartialCircle(center: center, radius: 0.3, startAngle: 0, endAngle: .pi, samples: 50),
                expectedMotionType: .partialCircle,
                expectedROMRange: 160...180,
                expectedRadius: 0.3,
                tolerance: 0.1
            ),
            
            CircularROMTestCase(
                name: "Three-Quarter Circle (270°)",
                positions: CircularROMTestData.generatePartialCircle(center: center, radius: 0.6, startAngle: 0, endAngle: 3*.pi/2, samples: 80),
                expectedMotionType: .fullCircle,
                expectedROMRange: 250...280,
                expectedRadius: 0.6,
                tolerance: 0.1
            ),
            
            // Linear motion tests
            CircularROMTestCase(
                name: "Linear Motion - Horizontal",
                positions: CircularROMTestData.generateLinearMotion(
                    start: SIMD3<Double>(-0.3, 1.0, 0.0),
                    end: SIMD3<Double>(0.3, 1.0, 0.0),
                    samples: 30
                ),
                expectedMotionType: .linear,
                expectedROMRange: 10...30,
                tolerance: 0.2
            ),
            
            CircularROMTestCase(
                name: "Linear Motion - Diagonal",
                positions: CircularROMTestData.generateLinearMotion(
                    start: SIMD3<Double>(-0.2, 1.0, -0.2),
                    end: SIMD3<Double>(0.2, 1.0, 0.2),
                    samples: 25
                ),
                expectedMotionType: .linear,
                expectedROMRange: 15...35,
                tolerance: 0.2
            ),
            
            // Noisy data tests
            CircularROMTestCase(
                name: "Noisy Circle - Low Noise",
                positions: CircularROMTestData.generateNoisyCircle(center: center, radius: 0.4, noiseLevel: 0.02, samples: 80),
                expectedMotionType: .fullCircle,
                expectedROMRange: 35...45,
                expectedRadius: 0.4,
                tolerance: 0.15
            ),
            
            CircularROMTestCase(
                name: "Noisy Circle - High Noise",
                positions: CircularROMTestData.generateNoisyCircle(center: center, radius: 0.5, noiseLevel: 0.1, samples: 100),
                expectedMotionType: .fullCircle,
                expectedROMRange: 40...60,
                expectedRadius: 0.5,
                tolerance: 0.25
            ),
            
            // Elliptical motion tests
            CircularROMTestCase(
                name: "Elliptical Motion - Slight Ellipse",
                positions: CircularROMTestData.generateEllipticalMotion(center: center, radiusX: 0.4, radiusZ: 0.3, samples: 90),
                expectedMotionType: .fullCircle,
                expectedROMRange: 30...50,
                tolerance: 0.2
            ),
            
            CircularROMTestCase(
                name: "Elliptical Motion - Pronounced Ellipse",
                positions: CircularROMTestData.generateEllipticalMotion(center: center, radiusX: 0.6, radiusZ: 0.2, samples: 100),
                expectedMotionType: .partialCircle,
                expectedROMRange: 40...70,
                tolerance: 0.3
            ),
            
            // Edge cases
            CircularROMTestCase(
                name: "Minimal Samples",
                positions: CircularROMTestData.generatePerfectCircle(center: center, radius: 0.3, samples: 20),
                expectedMotionType: .fullCircle,
                expectedROMRange: 25...35,
                expectedRadius: 0.3,
                tolerance: 0.2
            ),
            
            CircularROMTestCase(
                name: "Very Small Circle",
                positions: CircularROMTestData.generatePerfectCircle(center: center, radius: 0.06, samples: 50),
                expectedMotionType: .fullCircle,
                expectedROMRange: 5...10,
                expectedRadius: 0.06,
                tolerance: 0.3
            )
        ]
    }
    
    // MARK: - Test Execution
    
    func runAllTests() -> CircularROMTestSummary {
        let testCases = generateTestCases()
        var results: [CircularROMTestResult] = []
        var totalExecutionTime: TimeInterval = 0
        
        FlexaLog.motion.info("🧪 [CircularROMTest] Starting comprehensive test suite with \(testCases.count) test cases")
        
        for testCase in testCases {
            let result = runSingleTest(testCase)
            results.append(result)
            totalExecutionTime += result.executionTime
            
            let status = result.passed ? "✅ PASS" : "❌ FAIL"
            FlexaLog.motion.info("🧪 [CircularROMTest] \(status) - \(testCase.name)")
            
            if !result.passed {
                for reason in result.failureReasons {
                    FlexaLog.motion.warning("🧪 [CircularROMTest]   └─ \(reason)")
                }
            }
        }
        
        let passedCount = results.filter { $0.passed }.count
        let averageTime = totalExecutionTime / Double(testCases.count)
        
        let summary = CircularROMTestSummary(
            totalTests: testCases.count,
            passedTests: passedCount,
            failedTests: testCases.count - passedCount,
            averageExecutionTime: averageTime,
            results: results
        )
        
        FlexaLog.motion.info("🧪 [CircularROMTest] Test suite completed - Pass rate: \(String(format: "%.1f", summary.passRate * 100))% (\(passedCount)/\(testCases.count))")
        
        return summary
    }
    
    private func runSingleTest(_ testCase: CircularROMTestCase) -> CircularROMTestResult {
        let startTime = Date()
        
        // Run the audit
        let auditResult = audit.validateCircularROM(positions: testCase.positions)
        
        let executionTime = Date().timeIntervalSince(startTime)
        
        // Validate results
        var failureReasons: [String] = []
        var passed = true
        
        // Check motion type
        if auditResult.detectedMotionType != testCase.expectedMotionType {
            failureReasons.append("Motion type mismatch: expected \(testCase.expectedMotionType.description), got \(auditResult.detectedMotionType.description)")
            passed = false
        }
        
        // Check ROM range
        if !testCase.expectedROMRange.contains(auditResult.calculatedRange) {
            failureReasons.append("ROM out of expected range: \(String(format: "%.1f", auditResult.calculatedRange))° not in \(testCase.expectedROMRange)")
            passed = false
        }
        
        // Check radius if specified
        if let expectedRadius = testCase.expectedRadius {
            let radiusDifference = abs(auditResult.radius - expectedRadius)
            if radiusDifference > testCase.tolerance {
                failureReasons.append("Radius error too large: expected \(String(format: "%.3f", expectedRadius))m, got \(String(format: "%.3f", auditResult.radius))m (diff: \(String(format: "%.3f", radiusDifference))m)")
                passed = false
            }
        }
        
        // Check for critical issues
        let criticalIssues = auditResult.issues.filter { issue in
            switch issue {
            case .incorrectCircularDetection, .invalidCenterCalculation, .missing360DegreeSupport:
                return true
            default:
                return false
            }
        }
        
        if !criticalIssues.isEmpty {
            failureReasons.append("Critical issues detected: \(criticalIssues.map { $0.description }.joined(separator: ", "))")
            passed = false
        }
        
        return CircularROMTestResult(
            testCase: testCase,
            auditResult: auditResult,
            passed: passed,
            failureReasons: failureReasons,
            executionTime: executionTime
        )
    }
    
    // MARK: - Specific Test Methods
    
    func testPerfectCircleAccuracy() -> Bool {
        let center = SIMD3<Double>(0.0, 1.0, 0.0)
        let radius = 0.4
        let positions = CircularROMTestData.generatePerfectCircle(center: center, radius: radius, samples: 100)
        
        let result = audit.validateCircularROM(positions: positions)
        
        let radiusAccurate = abs(result.radius - radius) < 0.05
        let motionTypeCorrect = result.detectedMotionType == .fullCircle
        let romReasonable = result.calculatedRange >= 30 && result.calculatedRange <= 50
        
        return radiusAccurate && motionTypeCorrect && romReasonable
    }
    
    func testLinearMotionDetection() -> Bool {
        let start = SIMD3<Double>(-0.3, 1.0, 0.0)
        let end = SIMD3<Double>(0.3, 1.0, 0.0)
        let positions = CircularROMTestData.generateLinearMotion(start: start, end: end, samples: 30)
        
        let result = audit.validateCircularROM(positions: positions)
        
        return result.detectedMotionType == .linear
    }
    
    func testNoisyDataRobustness() -> Bool {
        let center = SIMD3<Double>(0.0, 1.0, 0.0)
        let radius = 0.5
        let positions = CircularROMTestData.generateNoisyCircle(center: center, radius: radius, noiseLevel: 0.05, samples: 80)
        
        let result = audit.validateCircularROM(positions: positions)
        
        let radiusReasonable = abs(result.radius - radius) < 0.15
        let motionTypeCorrect = result.detectedMotionType == .fullCircle
        
        return radiusReasonable && motionTypeCorrect
    }
    
    func test360DegreeSupport() -> Bool {
        let center = SIMD3<Double>(0.0, 1.0, 0.0)
        let radius = 0.3
        let positions = CircularROMTestData.generatePerfectCircle(center: center, radius: radius, samples: 120)
        
        let result = audit.validateCircularROM(positions: positions)
        
        // Should detect full circle and calculate appropriate angle
        return result.detectedMotionType == .fullCircle && result.completedAngle >= 270.0
    }
    
    // MARK: - Performance Tests
    
    func benchmarkPerformance(sampleCount: Int = 100) -> TimeInterval {
        let center = SIMD3<Double>(0.0, 1.0, 0.0)
        let positions = CircularROMTestData.generatePerfectCircle(center: center, radius: 0.4, samples: sampleCount)
        
        let startTime = Date()
        _ = audit.validateCircularROM(positions: positions)
        let executionTime = Date().timeIntervalSince(startTime)
        
        FlexaLog.motion.info("🧪 [CircularROMTest] Performance benchmark (\(sampleCount) samples): \(String(format: "%.3f", executionTime * 1000))ms")
        
        return executionTime
    }
}