import SwiftUI
import Charts
import Foundation

/// Fixes for SPARC graph rendering and visualization issues
class SPARCGraphRenderingFixes {
    
    // MARK: - Graph Data Processing
    
    /// Generate properly formatted and validated graph data points
    static func generateValidatedGraphData(
        from sparcDataPoints: [SPARCDataPoint],
        sessionStartTime: Date
    ) -> [SPARCGraphPoint] {
        
        guard !sparcDataPoints.isEmpty else {
            FlexaLog.ui.warning("📊 [SPARCGraphFix] No SPARC data points available for graphing")
            return []
        }
        
        // Sort data points by timestamp
        let sortedDataPoints = sparcDataPoints.sorted { $0.timestamp < $1.timestamp }
        
        // Validate and convert to graph points
        var graphPoints: [SPARCGraphPoint] = []
        var lastValidTime: TimeInterval = 0
        
        for dataPoint in sortedDataPoints {
            // Validate data point
            guard SPARCCalculationFixes.validateSPARCDataPoint(dataPoint) else {
                FlexaLog.ui.warning("📊 [SPARCGraphFix] Skipping invalid data point")
                continue
            }
            
            // Calculate time from session start
            let timeFromStart = dataPoint.timestamp.timeIntervalSince(sessionStartTime)
            
            // Ensure monotonic time progression
            guard timeFromStart >= lastValidTime else {
                FlexaLog.ui.warning("📊 [SPARCGraphFix] Skipping non-monotonic timestamp")
                continue
            }
            
            // Create validated graph point
            let graphPoint = SPARCGraphPoint(
                id: UUID(),
                timeFromStart: timeFromStart,
                sparcValue: dataPoint.sparcValue,
                confidence: dataPoint.confidence,
                dataSource: dataPoint.dataSource,
                movementPhase: dataPoint.movementPhase
            )
            
            graphPoints.append(graphPoint)
            lastValidTime = timeFromStart
        }
        
        // Fill gaps if necessary
        let gapFilledPoints = fillDataGaps(graphPoints)
        
        FlexaLog.ui.info("📊 [SPARCGraphFix] Generated \(gapFilledPoints.count) validated graph points from \(sparcDataPoints.count) raw points")
        
        return gapFilledPoints
    }
    
    /// Fill gaps in graph data with interpolated points
    private static func fillDataGaps(_ graphPoints: [SPARCGraphPoint], maxGap: TimeInterval = 1.0) -> [SPARCGraphPoint] {
        guard graphPoints.count > 1 else { return graphPoints }
        
        var filledPoints: [SPARCGraphPoint] = []
        
        for i in 0..<graphPoints.count {
            filledPoints.append(graphPoints[i])
            
            // Check for gap to next point
            if i < graphPoints.count - 1 {
                let currentPoint = graphPoints[i]
                let nextPoint = graphPoints[i + 1]
                let gap = nextPoint.timeFromStart - currentPoint.timeFromStart
                
                if gap > maxGap {
                    // Insert interpolated points
                    let interpolatedPoints = interpolateGraphPoints(
                        from: currentPoint,
                        to: nextPoint,
                        maxGapSize: maxGap
                    )
                    filledPoints.append(contentsOf: interpolatedPoints)
                }
            }
        }
        
        return filledPoints
    }
    
    /// Interpolate graph points to fill gaps
    private static func interpolateGraphPoints(
        from startPoint: SPARCGraphPoint,
        to endPoint: SPARCGraphPoint,
        maxGapSize: TimeInterval
    ) -> [SPARCGraphPoint] {
        
        let totalGap = endPoint.timeFromStart - startPoint.timeFromStart
        let numberOfInterpolations = Int(ceil(totalGap / maxGapSize)) - 1
        
        guard numberOfInterpolations > 0 else { return [] }
        
        var interpolatedPoints: [SPARCGraphPoint] = []
        
        for i in 1...numberOfInterpolations {
            let t = Double(i) / Double(numberOfInterpolations + 1)
            
            let interpolatedTime = startPoint.timeFromStart + (endPoint.timeFromStart - startPoint.timeFromStart) * t
            let interpolatedSPARC = startPoint.sparcValue + (endPoint.sparcValue - startPoint.sparcValue) * t
            let interpolatedConfidence = startPoint.confidence + (endPoint.confidence - startPoint.confidence) * t
            
            let interpolatedPoint = SPARCGraphPoint(
                id: UUID(),
                timeFromStart: interpolatedTime,
                sparcValue: interpolatedSPARC,
                confidence: interpolatedConfidence,
                dataSource: startPoint.dataSource,
                movementPhase: "interpolated"
            )
            
            interpolatedPoints.append(interpolatedPoint)
        }
        
        return interpolatedPoints
    }
    
    // MARK: - Axis Scaling Fixes
    
    /// Calculate optimal Y-axis scale for SPARC values
    static func calculateOptimalYAxisScale(for graphPoints: [SPARCGraphPoint]) -> (min: Double, max: Double, stride: Double) {
        guard !graphPoints.isEmpty else {
            return (min: 0.0, max: 100.0, stride: 20.0)
        }
        
        let sparcValues = graphPoints.map { $0.sparcValue }
        let minValue = sparcValues.min() ?? 0.0
        let maxValue = sparcValues.max() ?? 100.0
        
        // Always show full 0-100 range for SPARC values for consistency
        let yMin = 0.0
        let yMax = 100.0
        
        // Calculate appropriate stride based on data range
        let dataRange = maxValue - minValue
        let stride: Double
        
        if dataRange <= 20 {
            stride = 5.0
        } else if dataRange <= 50 {
            stride = 10.0
        } else {
            stride = 20.0
        }
        
        return (min: yMin, max: yMax, stride: stride)
    }
    
    /// Calculate optimal X-axis scale for time values
    static func calculateOptimalXAxisScale(for graphPoints: [SPARCGraphPoint]) -> (min: Double, max: Double, stride: Double) {
        guard !graphPoints.isEmpty else {
            return (min: 0.0, max: 1.0, stride: 0.2)
        }
        
        let timeValues = graphPoints.map { $0.timeFromStart }
        let minTime = timeValues.min() ?? 0.0
        let maxTime = timeValues.max() ?? 1.0
        
        // Start from 0 and extend to cover all data
        let xMin = 0.0
        let xMax = max(1.0, ceil(maxTime * 10) / 10.0) // Round up to nearest 0.1 second
        
        // Calculate appropriate stride based on time range
        let timeRange = xMax - xMin
        let stride: Double
        
        if timeRange <= 5 {
            stride = 1.0
        } else if timeRange <= 30 {
            stride = 5.0
        } else if timeRange <= 120 {
            stride = 15.0
        } else {
            stride = 30.0
        }
        
        return (min: xMin, max: xMax, stride: stride)
    }
    
    // MARK: - Chart Rendering Helpers
    
    /// Create properly formatted axis labels for time values
    static func formatTimeAxisLabel(_ timeValue: Double) -> String {
        if timeValue < 60 {
            return String(format: "%.0fs", timeValue)
        } else {
            let minutes = Int(timeValue / 60)
            let seconds = Int(timeValue.truncatingRemainder(dividingBy: 60))
            return String(format: "%d:%02ds", minutes, seconds)
        }
    }
    
    /// Create properly formatted axis labels for SPARC values
    static func formatSPARCAxisLabel(_ sparcValue: Double) -> String {
        return String(format: "%.0f%%", sparcValue)
    }
    
    /// Generate chart colors based on data source
    static func getChartColor(for dataSource: SPARCDataSource) -> Color {
        switch dataSource {
        case .arkit:
            return .blue
        case .imu:
            return .orange
        case .camera:
            return .green
        }
    }
    
    /// Generate gradient for area charts
    static func getChartGradient(for dataSource: SPARCDataSource) -> LinearGradient {
        let color = getChartColor(for: dataSource)
        return LinearGradient(
            gradient: Gradient(colors: [color.opacity(0.3), color.opacity(0.1)]),
            startPoint: .top,
            endPoint: .bottom
        )
    }
    
    // MARK: - Data Quality Indicators
    
    /// Generate visual indicators for data quality issues
    static func generateQualityIndicators(for graphPoints: [SPARCGraphPoint]) -> [QualityIndicator] {
        var indicators: [QualityIndicator] = []
        
        // Check for low confidence regions
        for point in graphPoints {
            if point.confidence < 0.5 {
                indicators.append(QualityIndicator(
                    timeFromStart: point.timeFromStart,
                    type: .lowConfidence,
                    severity: point.confidence < 0.3 ? .high : .medium
                ))
            }
        }
        
        // Check for data gaps
        for i in 1..<graphPoints.count {
            let gap = graphPoints[i].timeFromStart - graphPoints[i-1].timeFromStart
            if gap > 2.0 {
                indicators.append(QualityIndicator(
                    timeFromStart: graphPoints[i-1].timeFromStart + gap/2,
                    type: .dataGap,
                    severity: gap > 5.0 ? .high : .medium
                ))
            }
        }
        
        return indicators
    }
    
    // MARK: - Chart Statistics
    
    /// Calculate comprehensive statistics for the chart
    static func calculateChartStatistics(for graphPoints: [SPARCGraphPoint]) -> ChartStatistics {
        guard !graphPoints.isEmpty else {
            return ChartStatistics(
                averageSPARC: 0.0,
                peakSPARC: 0.0,
                minimumSPARC: 0.0,
                averageConfidence: 0.0,
                dataPointCount: 0,
                sessionDuration: 0.0,
                qualityScore: 0.0
            )
        }
        
        let sparcValues = graphPoints.map { $0.sparcValue }
        let confidenceValues = graphPoints.map { $0.confidence }
        
        let averageSPARC = sparcValues.reduce(0, +) / Double(sparcValues.count)
        let peakSPARC = sparcValues.max() ?? 0.0
        let minimumSPARC = sparcValues.min() ?? 0.0
        let averageConfidence = confidenceValues.reduce(0, +) / Double(confidenceValues.count)
        
        let sessionDuration = graphPoints.last?.timeFromStart ?? 0.0
        
        // Calculate quality score based on confidence and data consistency
        let highConfidencePoints = confidenceValues.filter { $0 >= 0.7 }.count
        let qualityScore = Double(highConfidencePoints) / Double(confidenceValues.count)
        
        return ChartStatistics(
            averageSPARC: averageSPARC,
            peakSPARC: peakSPARC,
            minimumSPARC: minimumSPARC,
            averageConfidence: averageConfidence,
            dataPointCount: graphPoints.count,
            sessionDuration: sessionDuration,
            qualityScore: qualityScore
        )
    }
}

// MARK: - Supporting Types

struct SPARCGraphPoint: Identifiable {
    let id: UUID
    let timeFromStart: TimeInterval
    let sparcValue: Double
    let confidence: Double
    let dataSource: SPARCDataSource
    let movementPhase: String
}

struct QualityIndicator {
    let timeFromStart: TimeInterval
    let type: QualityIndicatorType
    let severity: QualityIndicatorSeverity
}

enum QualityIndicatorType {
    case lowConfidence
    case dataGap
    case interpolated
}

enum QualityIndicatorSeverity {
    case low
    case medium
    case high
    
    var color: Color {
        switch self {
        case .low:
            return .yellow
        case .medium:
            return .orange
        case .high:
            return .red
        }
    }
}

struct ChartStatistics {
    let averageSPARC: Double
    let peakSPARC: Double
    let minimumSPARC: Double
    let averageConfidence: Double
    let dataPointCount: Int
    let sessionDuration: TimeInterval
    let qualityScore: Double
}

// MARK: - Enhanced Chart Views

/// Enhanced SPARC chart view with proper data handling and visualization
struct EnhancedSPARCChartView: View {
    let sessionData: ExerciseSessionData
    @EnvironmentObject var motionService: SimpleMotionService
    
    var body: some View {
        VStack(alignment: .leading, spacing: 16) {
            Text("Movement Smoothness Analysis")
                .font(.title2)
                .fontWeight(.bold)
                .foregroundColor(.white)
            
            // Generate validated graph data
            let sparcDataPoints = motionService.sparcService.getSPARCDataPoints()
            let sessionStartTime = motionService.sparcService.getSessionStartTime()
            let graphPoints = SPARCGraphRenderingFixes.generateValidatedGraphData(
                from: sparcDataPoints,
                sessionStartTime: sessionStartTime
            )
            
            if !graphPoints.isEmpty {
                // Calculate optimal scaling
                let yAxisScale = SPARCGraphRenderingFixes.calculateOptimalYAxisScale(for: graphPoints)
                let xAxisScale = SPARCGraphRenderingFixes.calculateOptimalXAxisScale(for: graphPoints)
                
                // Generate quality indicators
                let qualityIndicators = SPARCGraphRenderingFixes.generateQualityIndicators(for: graphPoints)
                
                Chart {
                    // Main SPARC line and area
                    ForEach(graphPoints) { point in
                        AreaMark(
                            x: .value("Time", point.timeFromStart),
                            y: .value("SPARC", point.sparcValue)
                        )
                        .foregroundStyle(SPARCGraphRenderingFixes.getChartGradient(for: point.dataSource))
                        
                        LineMark(
                            x: .value("Time", point.timeFromStart),
                            y: .value("SPARC", point.sparcValue)
                        )
                        .foregroundStyle(SPARCGraphRenderingFixes.getChartColor(for: point.dataSource))
                        .lineStyle(StrokeStyle(lineWidth: 2))
                    }
                    
                    // Quality indicators
                    ForEach(qualityIndicators, id: \.timeFromStart) { indicator in
                        RuleMark(x: .value("Issue", indicator.timeFromStart))
                            .foregroundStyle(indicator.severity.color.opacity(0.6))
                            .lineStyle(StrokeStyle(lineWidth: 1, dash: [5, 5]))
                    }
                }
                .frame(height: 200)
                .chartYScale(domain: yAxisScale.min...yAxisScale.max)
                .chartXScale(domain: xAxisScale.min...xAxisScale.max)
                .chartYAxis {
                    AxisMarks(position: .leading, values: .stride(by: yAxisScale.stride)) { value in
                        AxisGridLine().foregroundStyle(.white.opacity(0.1))
                        AxisTick().foregroundStyle(.white)
                        AxisValueLabel {
                            if let v = value.as(Double.self) {
                                Text(SPARCGraphRenderingFixes.formatSPARCAxisLabel(v))
                                    .font(.caption)
                                    .foregroundColor(.white)
                            }
                        }
                    }
                }
                .chartXAxis {
                    AxisMarks(position: .bottom, values: .stride(by: xAxisScale.stride)) { value in
                        AxisGridLine().foregroundStyle(.white.opacity(0.1))
                        AxisTick().foregroundStyle(.white)
                        AxisValueLabel {
                            if let v = value.as(Double.self) {
                                Text(SPARCGraphRenderingFixes.formatTimeAxisLabel(v))
                                    .font(.caption)
                                    .foregroundColor(.white)
                            }
                        }
                    }
                }
                
                // Enhanced statistics
                let statistics = SPARCGraphRenderingFixes.calculateChartStatistics(for: graphPoints)
                
                HStack {
                    VStack(alignment: .leading) {
                        Text("Average SPARC")
                            .font(.caption)
                            .foregroundColor(.secondary)
                        Text(String(format: "%.1f%%", statistics.averageSPARC))
                            .font(.headline)
                            .foregroundColor(.white)
                    }
                    
                    Spacer()
                    
                    VStack(alignment: .center) {
                        Text("Peak SPARC")
                            .font(.caption)
                            .foregroundColor(.secondary)
                        Text(String(format: "%.1f%%", statistics.peakSPARC))
                            .font(.headline)
                            .foregroundColor(.white)
                    }
                    
                    Spacer()
                    
                    VStack(alignment: .trailing) {
                        Text("Data Quality")
                            .font(.caption)
                            .foregroundColor(.secondary)
                        Text(String(format: "%.0f%%", statistics.qualityScore * 100))
                            .font(.headline)
                            .foregroundColor(statistics.qualityScore > 0.8 ? .green : statistics.qualityScore > 0.6 ? .orange : .red)
                    }
                }
                .padding(.top)
                
            } else {
                VStack {
                    Text("No SPARC data available")
                        .foregroundColor(.gray)
                    Text("SPARC measures movement smoothness")
                        .font(.caption)
                        .foregroundColor(.secondary)
                }
                .frame(height: 200)
            }
        }
        .padding()
        .background(Color.gray.opacity(0.1))
        .cornerRadius(12)
    }
}