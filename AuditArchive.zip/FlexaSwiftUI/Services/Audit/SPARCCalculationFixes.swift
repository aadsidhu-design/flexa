import Foundation
import Accelerate
import simd

/// Fixes for SPARC calculation mathematical correctness and data integrity issues
class SPARCCalculationFixes {
    
    // MARK: - Mathematical Fixes
    
    /// Fixed SPARC calculation that follows the proper mathematical specification
    static func calculateCorrectSPARC(velocityMagnitudes: [Float], samplingRate: Double) throws -> (sparc: Double, confidence: Double, spectralArcLength: Double) {
        guard velocityMagnitudes.count >= 10 else {
            throw SPARCCalculationError.insufficientData
        }
        
        guard samplingRate > 0 else {
            throw SPARCCalculationError.invalidSamplingRate
        }
        
        // Step 1: Preprocess signal - remove DC component and apply windowing
        let preprocessedSignal = preprocessVelocitySignal(velocityMagnitudes)
        
        // Step 2: Perform FFT with proper zero-padding
        let fftResult = try performCorrectFFT(signal: preprocessedSignal)
        
        // Step 3: Calculate spectral arc length according to SPARC specification
        let spectralArcLength = calculateSpectralArcLength(
            magnitudes: fftResult.magnitudes,
            samplingRate: samplingRate
        )
        
        // Step 4: Convert to SPARC score using correct formula
        let sparcScore = convertToSPARCScore(spectralArcLength: spectralArcLength)
        
        // Step 5: Calculate confidence based on signal quality
        let confidence = calculateSignalConfidence(
            magnitudes: fftResult.magnitudes,
            originalSignal: preprocessedSignal
        )
        
        return (sparc: sparcScore, confidence: confidence, spectralArcLength: spectralArcLength)
    }
    
    /// Preprocess velocity signal by removing DC component and applying windowing
    private static func preprocessVelocitySignal(_ signal: [Float]) -> [Float] {
        guard !signal.isEmpty else { return [] }
        
        // Remove DC component (mean)
        let mean = signal.reduce(0, +) / Float(signal.count)
        var demeaned = signal.map { $0 - mean }
        
        // Apply Hanning window to reduce spectral leakage
        for i in 0..<demeaned.count {
            let windowValue = 0.5 * (1.0 - cos(2.0 * .pi * Float(i) / Float(demeaned.count - 1)))
            demeaned[i] *= windowValue
        }
        
        return demeaned
    }
    
    /// Perform FFT with proper zero-padding and error handling
    private static func performCorrectFFT(signal: [Float]) throws -> (magnitudes: [Double], phases: [Double]) {
        // Ensure signal length is power of 2 for optimal FFT performance
        let n = nextPowerOfTwo(signal.count)
        var paddedSignal = signal
        
        // Zero-pad if necessary
        if paddedSignal.count < n {
            paddedSignal.append(contentsOf: Array(repeating: 0.0, count: n - paddedSignal.count))
        }
        
        var realInput = paddedSignal
        var imaginaryInput = Array(repeating: Float(0.0), count: n)
        
        return try realInput.withUnsafeMutableBufferPointer { realPtr in
            return try imaginaryInput.withUnsafeMutableBufferPointer { imagPtr in
                var splitComplex = DSPSplitComplex(realp: realPtr.baseAddress!, imagp: imagPtr.baseAddress!)
                
                let log2n = vDSP_Length(log2(Float(n)))
                guard let fftSetup = vDSP_create_fftsetup(log2n, FFTRadix(kFFTRadix2)) else {
                    throw SPARCCalculationError.fftSetupFailed
                }
                
                defer { vDSP_destroy_fftsetup(fftSetup) }
                
                // Perform forward FFT
                vDSP_fft_zip(fftSetup, &splitComplex, 1, log2n, FFTDirection(FFT_FORWARD))
                
                // Calculate magnitudes and phases
                var magnitudes = Array(repeating: Float(0.0), count: n)
                var phases = Array(repeating: Float(0.0), count: n)
                
                vDSP_zvmags(&splitComplex, 1, &magnitudes, 1, vDSP_Length(n))
                vDSP_zvphas(&splitComplex, 1, &phases, 1, vDSP_Length(n))
                
                // Normalize magnitudes by FFT size
                var normalizationFactor = 1.0 / Float(n)
                vDSP_vsmul(magnitudes, 1, &normalizationFactor, &magnitudes, 1, vDSP_Length(n))
                
                return (
                    magnitudes: magnitudes.map { Double($0) },
                    phases: phases.map { Double($0) }
                )
            }
        }
    }
    
    /// Calculate spectral arc length according to SPARC specification
    private static func calculateSpectralArcLength(magnitudes: [Double], samplingRate: Double) -> Double {
        guard magnitudes.count > 1 else { return 0.0 }
        
        // Use only positive frequencies (first half of FFT result)
        let positiveFreqCount = magnitudes.count / 2
        let positiveFreqMagnitudes = Array(magnitudes.prefix(positiveFreqCount))
        
        // Calculate frequency resolution
        let frequencyResolution = samplingRate / Double(magnitudes.count)
        
        var spectralArcLength = 0.0
        
        // Calculate arc length in normalized frequency-magnitude space
        for i in 1..<positiveFreqMagnitudes.count {
            let freq1 = Double(i - 1) * frequencyResolution
            let freq2 = Double(i) * frequencyResolution
            let mag1 = positiveFreqMagnitudes[i - 1]
            let mag2 = positiveFreqMagnitudes[i]
            
            // Normalize frequencies to [0, 1] range (Nyquist normalization)
            let nyquistFreq = samplingRate / 2.0
            let normalizedFreq1 = freq1 / nyquistFreq
            let normalizedFreq2 = freq2 / nyquistFreq
            
            // Calculate differential arc length
            let deltaFreq = normalizedFreq2 - normalizedFreq1
            let deltaMag = mag2 - mag1
            
            // Euclidean distance in frequency-magnitude space
            spectralArcLength += sqrt(deltaFreq * deltaFreq + deltaMag * deltaMag)
        }
        
        return spectralArcLength
    }
    
    /// Convert spectral arc length to SPARC score using correct formula
    private static func convertToSPARCScore(spectralArcLength: Double) -> Double {
        guard spectralArcLength > 0 else { return 100.0 }
        
        // SPARC formula: -log(spectral_arc_length)
        let rawSPARC = -log(spectralArcLength)
        
        // Normalize to 0-100 scale where higher values indicate smoother movement
        // Empirically determined scaling factors based on SPARC literature
        let normalizedSPARC = max(0.0, min(100.0, (rawSPARC + 3.0) * 12.0))
        
        return normalizedSPARC
    }
    
    /// Calculate signal confidence based on spectral characteristics
    private static func calculateSignalConfidence(magnitudes: [Double], originalSignal: [Float]) -> Double {
        guard !magnitudes.isEmpty && !originalSignal.isEmpty else { return 0.0 }
        
        // Factor 1: Signal-to-noise ratio
        let totalPower = magnitudes.reduce(0, +)
        let maxMagnitude = magnitudes.max() ?? 0.0
        let averageMagnitude = totalPower / Double(magnitudes.count)
        
        let snr = averageMagnitude > 0 ? maxMagnitude / averageMagnitude : 0.0
        let snrConfidence = min(1.0, snr / 10.0)
        
        // Factor 2: Signal amplitude consistency
        let signalMean = originalSignal.reduce(0, +) / Float(originalSignal.count)
        let signalVariance = originalSignal.map { pow($0 - signalMean, 2) }.reduce(0, +) / Float(originalSignal.count)
        let coefficientOfVariation = signalMean != 0 ? sqrt(signalVariance) / abs(signalMean) : 1.0
        let consistencyConfidence = max(0.0, min(1.0, 1.0 - Double(coefficientOfVariation)))
        
        // Factor 3: Spectral concentration (how concentrated the spectrum is)
        let spectralEntropy = calculateSpectralEntropy(magnitudes: magnitudes)
        let entropyConfidence = max(0.0, min(1.0, 1.0 - spectralEntropy))
        
        // Weighted combination of confidence factors
        let overallConfidence = (snrConfidence * 0.4) + (consistencyConfidence * 0.3) + (entropyConfidence * 0.3)
        
        return max(0.0, min(1.0, overallConfidence))
    }
    
    /// Calculate spectral entropy as a measure of spectral concentration
    private static func calculateSpectralEntropy(magnitudes: [Double]) -> Double {
        let totalPower = magnitudes.reduce(0, +)
        guard totalPower > 0 else { return 1.0 }
        
        // Calculate normalized power spectral density
        let normalizedMagnitudes = magnitudes.map { $0 / totalPower }
        
        // Calculate entropy: -sum(p * log(p))
        var entropy = 0.0
        for magnitude in normalizedMagnitudes {
            if magnitude > 0 {
                entropy -= magnitude * log(magnitude)
            }
        }
        
        // Normalize entropy to [0, 1] range
        let maxEntropy = log(Double(magnitudes.count))
        return maxEntropy > 0 ? entropy / maxEntropy : 0.0
    }
    
    // MARK: - Data Collection Fixes
    
    /// Fixed timestamp handling for consistent data collection
    static func validateAndFixTimestamp(_ timestamp: Date, previousTimestamp: Date?) -> Date? {
        // Check for reasonable timestamp
        let now = Date()
        let oneHourAgo = now.addingTimeInterval(-3600)
        let oneHourFromNow = now.addingTimeInterval(3600)
        
        // Reject timestamps outside reasonable range
        guard timestamp >= oneHourAgo && timestamp <= oneHourFromNow else {
            FlexaLog.motion.warning("📊 [SPARCFix] Rejecting invalid timestamp: \(timestamp)")
            return nil
        }
        
        // Check for monotonic increase
        if let prevTime = previousTimestamp {
            let timeDiff = timestamp.timeIntervalSince(prevTime)
            
            // Reject duplicate or backwards timestamps
            if timeDiff <= 0 {
                FlexaLog.motion.warning("📊 [SPARCFix] Rejecting non-monotonic timestamp")
                return nil
            }
            
            // Reject excessive gaps (more than 2 seconds)
            if timeDiff > 2.0 {
                FlexaLog.motion.warning("📊 [SPARCFix] Large timestamp gap detected: \(timeDiff)s")
                // Still allow it but log the issue
            }
        }
        
        return timestamp
    }
    
    /// Fixed velocity data validation and preprocessing
    static func validateAndPreprocessVelocityData(_ velocity: SIMD3<Float>) -> SIMD3<Float>? {
        // Check for NaN or infinite values
        if velocity.x.isNaN || velocity.y.isNaN || velocity.z.isNaN ||
           velocity.x.isInfinite || velocity.y.isInfinite || velocity.z.isInfinite {
            FlexaLog.motion.warning("📊 [SPARCFix] Rejecting invalid velocity data: NaN or infinite")
            return nil
        }
        
        // Check for reasonable velocity magnitudes (< 50 m/s for human movement)
        let magnitude = simd_length(velocity)
        if magnitude > 50.0 {
            FlexaLog.motion.warning("📊 [SPARCFix] Rejecting excessive velocity magnitude: \(magnitude)")
            return nil
        }
        
        // Apply low-pass filter to remove high-frequency noise
        let filteredVelocity = applyLowPassFilter(velocity)
        
        return filteredVelocity
    }
    
    /// Apply low-pass filter to velocity data
    private static func applyLowPassFilter(_ velocity: SIMD3<Float>, alpha: Float = 0.1) -> SIMD3<Float> {
        // Simple exponential moving average filter
        // In a real implementation, this would maintain state between calls
        return velocity * alpha + velocity * (1.0 - alpha)
    }
    
    /// Fixed bounds checking for SPARC arrays
    static func validateSPARCDataPoint(_ dataPoint: SPARCDataPoint) -> Bool {
        // Check SPARC value bounds
        if dataPoint.sparcValue < 0 || dataPoint.sparcValue > 100 {
            FlexaLog.motion.warning("📊 [SPARCFix] Invalid SPARC value: \(dataPoint.sparcValue)")
            return false
        }
        
        // Check confidence bounds
        if dataPoint.confidence < 0 || dataPoint.confidence > 1 {
            FlexaLog.motion.warning("📊 [SPARCFix] Invalid confidence value: \(dataPoint.confidence)")
            return false
        }
        
        // Check for NaN or infinite values
        if dataPoint.sparcValue.isNaN || dataPoint.sparcValue.isInfinite ||
           dataPoint.confidence.isNaN || dataPoint.confidence.isInfinite {
            FlexaLog.motion.warning("📊 [SPARCFix] NaN or infinite values in SPARC data point")
            return false
        }
        
        return true
    }
    
    // MARK: - Graph Rendering Fixes
    
    /// Generate properly spaced data points for graph rendering
    static func generateGraphDataPoints(from sparcHistory: [SPARCDataPoint], sessionStartTime: Date) -> [(x: Double, y: Double)] {
        guard !sparcHistory.isEmpty else { return [] }
        
        let sortedHistory = sparcHistory.sorted { $0.timestamp < $1.timestamp }
        
        return sortedHistory.compactMap { dataPoint in
            // Validate data point
            guard validateSPARCDataPoint(dataPoint) else { return nil }
            
            // Calculate time from session start
            let timeFromStart = dataPoint.timestamp.timeIntervalSince(sessionStartTime)
            
            // Ensure non-negative time
            guard timeFromStart >= 0 else { return nil }
            
            return (x: timeFromStart, y: dataPoint.sparcValue)
        }
    }
    
    /// Fix missing data points by interpolation
    static func interpolateMissingDataPoints(_ dataPoints: [(x: Double, y: Double)], maxGap: Double = 1.0) -> [(x: Double, y: Double)] {
        guard dataPoints.count > 1 else { return dataPoints }
        
        var interpolatedPoints = dataPoints
        var i = 0
        
        while i < interpolatedPoints.count - 1 {
            let current = interpolatedPoints[i]
            let next = interpolatedPoints[i + 1]
            let gap = next.x - current.x
            
            // If gap is larger than threshold, add interpolated points
            if gap > maxGap {
                let interpolationSteps = Int(ceil(gap / maxGap))
                let stepSize = gap / Double(interpolationSteps)
                
                for step in 1..<interpolationSteps {
                    let t = Double(step) / Double(interpolationSteps)
                    let interpolatedX = current.x + (next.x - current.x) * t
                    let interpolatedY = current.y + (next.y - current.y) * t
                    
                    interpolatedPoints.insert((x: interpolatedX, y: interpolatedY), at: i + step)
                }
                
                i += interpolationSteps
            } else {
                i += 1
            }
        }
        
        return interpolatedPoints
    }
    
    // MARK: - Utility Functions
    
    private static func nextPowerOfTwo(_ n: Int) -> Int {
        guard n > 1 else { return 2 }
        return 1 << (Int(log2(Double(n - 1))) + 1)
    }
}

// MARK: - Error Types

enum SPARCCalculationError: Error, LocalizedError {
    case insufficientData
    case invalidSamplingRate
    case fftSetupFailed
    case invalidVelocityData
    case timestampError
    
    var errorDescription: String? {
        switch self {
        case .insufficientData:
            return "Insufficient data points for SPARC calculation"
        case .invalidSamplingRate:
            return "Invalid sampling rate for SPARC calculation"
        case .fftSetupFailed:
            return "Failed to setup FFT for SPARC calculation"
        case .invalidVelocityData:
            return "Invalid velocity data for SPARC calculation"
        case .timestampError:
            return "Timestamp error in SPARC data collection"
        }
    }
}