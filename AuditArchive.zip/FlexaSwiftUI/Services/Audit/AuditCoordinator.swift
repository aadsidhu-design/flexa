import Foundation
import SwiftUI

/// Main coordinator for the audit system that manages all audit validators
@MainActor
class AuditCoordinator: ObservableObject {
    static let shared = AuditCoordinator()
    
    @Published private(set) var isAuditInProgress = false
    @Published private(set) var lastAuditResult: SystemAuditResult?
    @Published private(set) var auditHistory: [SystemAuditResult] = []
    
    private let logger = AuditLogger.shared
    private let maxHistoryEntries = 50
    
    // Audit validators (will be implemented in subsequent tasks)
    private var aiScoringValidator: (any AuditValidator)?
    private var sparcValidator: (any AuditValidator)?
    private var customExerciseValidator: (any AuditValidator)?
    private var circleROMValidator: (any AuditValidator)?
    private var metricsValidator: (any AuditValidator)?
    private var uploadValidator: (any AuditValidator)?
    
    private init() {
        setupAuditSystem()
    }
    
    // MARK: - Public Interface
    
    /// Run comprehensive system audit
    func runSystemAudit() async -> SystemAuditResult {
        guard !isAuditInProgress else {
            logger.logError(AuditError.auditInProgress, context: "System Audit")
            return lastAuditResult ?? createEmptyAuditResult()
        }
        
        isAuditInProgress = true
        logger.logAuditStart("SystemAudit", details: "Starting comprehensive system audit")
        
        let startTime = Date()
        
        do {
            // Run individual audits in parallel where possible
            async let aiAudit = runAIScoringAudit()
            async let sparcAudit = runSPARCAudit()
            async let customExerciseAudit = runCustomExerciseAudit()
            async let circleROMAudit = runCircleROMAudit()
            async let metricsAudit = runMetricsAudit()
            async let uploadAudit = runUploadAudit()
            
            // Wait for all audits to complete
            let results = await (
                aiAudit, sparcAudit, customExerciseAudit,
                circleROMAudit, metricsAudit, uploadAudit
            )
            
            // Calculate overall health score
            let overallHealthScore = calculateOverallHealthScore(
                aiResult: results.0,
                sparcResult: results.1,
                customExerciseResult: results.2,
                circleROMResult: results.3,
                metricsResult: results.4,
                uploadResult: results.5
            )
            
            let systemResult = SystemAuditResult(
                aiScoringAudit: results.0,
                sparcAudit: results.1,
                customExerciseAudit: results.2,
                circleROMAudit: results.3,
                metricsAudit: results.4,
                uploadAudit: results.5,
                overallHealthScore: overallHealthScore
            )
            
            // Log completion
            let duration = Date().timeIntervalSince(startTime)
            logger.logPerformance(
                validator: "SystemAudit",
                operation: "Complete System Audit",
                duration: duration,
                details: "Health Score: \(overallHealthScore), Issues: \(systemResult.issues.count)"
            )
            
            logger.logAuditComplete("SystemAudit", result: systemResult)
            
            // Update state
            lastAuditResult = systemResult
            addToHistory(systemResult)
            
            return systemResult
            
        } catch {
            logger.logError(error, context: "System Audit", validator: "SystemAudit")
            let errorResult = createErrorAuditResult(error: error)
            lastAuditResult = errorResult
            return errorResult
        }
        
        defer {
            isAuditInProgress = false
        }
    }
    
    /// Run audit for specific component
    func runComponentAudit(_ component: AuditComponent) async -> AuditResultProtocol? {
        logger.logAuditStart("Component Audit", details: "Running audit for \(component.rawValue)")
        
        let result: AuditResultProtocol?
        
        switch component {
        case .aiScoring:
            result = await runAIScoringAudit()
        case .sparcCalculation:
            result = await runSPARCAudit()
        case .customExercise:
            result = await runCustomExerciseAudit()
        case .circleROM:
            result = await runCircleROMAudit()
        case .metricsCollection:
            result = await runMetricsAudit()
        case .dataUpload:
            result = await runUploadAudit()
        }
        
        if let result = result {
            logger.logAuditComplete("Component Audit", result: result)
        }
        
        return result
    }
    
    /// Validate test data sets
    func validateTestDataSets() async -> TestValidationSummary {
        logger.logAuditStart("Test Data Validation", details: "Validating all test data sets")
        
        let summary = TestDataSets.runAllValidationTests()
        
        logger.logDataValidation(
            validator: "TestDataValidator",
            dataType: "Test Data Sets",
            isValid: summary.successRate > 0.8,
            details: "Passed: \(summary.passedTests)/\(summary.totalTests) (\(Int(summary.successRate * 100))%)"
        )
        
        return summary
    }
    
    /// Get audit history filtered by component
    func getAuditHistory(for component: AuditComponent) -> [AuditResultProtocol] {
        return auditHistory.compactMap { systemResult in
            switch component {
            case .aiScoring:
                return systemResult.aiScoringAudit
            case .sparcCalculation:
                return systemResult.sparcAudit
            case .customExercise:
                return systemResult.customExerciseAudit
            case .circleROM:
                return systemResult.circleROMAudit
            case .metricsCollection:
                return systemResult.metricsAudit
            case .dataUpload:
                return systemResult.uploadAudit
            }
        }
    }
    
    /// Clear audit history
    func clearAuditHistory() {
        auditHistory.removeAll()
        logger.log(level: .info, category: .system, message: "Audit history cleared")
    }
    
    // MARK: - Private Audit Methods
    
    private func runAIScoringAudit() async -> AIScoreAuditResult? {
        // Placeholder implementation - will be implemented in task 2
        logger.logAuditStart("AI Scoring Audit", details: "Auditing AI scoring system")
        
        // For now, return a basic result indicating the audit framework is ready
        let issues: [AuditIssue] = []
        let recommendations = ["AI scoring audit implementation pending"]
        
        return AIScoreAuditResult(
            isValid: true,
            issues: issues,
            recommendations: recommendations,
            timestamp: Date(),
            validatorName: "AIScoreValidator",
            calculatedScore: nil,
            scoreRange: nil,
            algorithmValidation: nil
        )
    }
    
    private func runSPARCAudit() async -> SPARCAuditResult? {
        // Placeholder implementation - will be implemented in task 3
        logger.logAuditStart("SPARC Audit", details: "Auditing SPARC calculation system")
        
        let issues: [AuditIssue] = []
        let recommendations = ["SPARC audit implementation pending"]
        
        return SPARCAuditResult(
            isValid: true,
            issues: issues,
            recommendations: recommendations,
            timestamp: Date(),
            validatorName: "SPARCValidator",
            calculatedSPARC: nil,
            fftResults: nil,
            dataQuality: nil
        )
    }
    
    private func runCustomExerciseAudit() async -> CustomExerciseAuditResult? {
        // Placeholder implementation - will be implemented in task 4
        logger.logAuditStart("Custom Exercise Audit", details: "Auditing custom exercise system")
        
        let issues: [AuditIssue] = []
        let recommendations = ["Custom exercise audit implementation pending"]
        
        return CustomExerciseAuditResult(
            isValid: true,
            issues: issues,
            recommendations: recommendations,
            timestamp: Date(),
            validatorName: "CustomExerciseValidator",
            repCountAccuracy: nil,
            configValidation: nil
        )
    }
    
    private func runCircleROMAudit() async -> CircleROMAuditResult? {
        // Placeholder implementation - will be implemented in task 5
        logger.logAuditStart("Circle ROM Audit", details: "Auditing circle ROM calculation system")
        
        let issues: [AuditIssue] = []
        let recommendations = ["Circle ROM audit implementation pending"]
        
        return CircleROMAuditResult(
            isValid: true,
            issues: issues,
            recommendations: recommendations,
            timestamp: Date(),
            validatorName: "CircleROMValidator",
            calculatedRange: nil,
            circularityScore: nil,
            calibrationValidation: nil
        )
    }
    
    private func runMetricsAudit() async -> MetricsAuditResult? {
        // Placeholder implementation - will be implemented in task 6
        logger.logAuditStart("Metrics Audit", details: "Auditing metrics collection system")
        
        let issues: [AuditIssue] = []
        let recommendations = ["Metrics audit implementation pending"]
        
        return MetricsAuditResult(
            isValid: true,
            issues: issues,
            recommendations: recommendations,
            timestamp: Date(),
            validatorName: "MetricsValidator",
            dataIntegrity: nil,
            calculationAccuracy: nil
        )
    }
    
    private func runUploadAudit() async -> UploadAuditResult? {
        // Placeholder implementation - will be implemented in task 7
        logger.logAuditStart("Upload Audit", details: "Auditing data upload system")
        
        let issues: [AuditIssue] = []
        let recommendations = ["Upload audit implementation pending"]
        
        return UploadAuditResult(
            isValid: true,
            issues: issues,
            recommendations: recommendations,
            timestamp: Date(),
            validatorName: "UploadValidator",
            hasRealData: true,
            missingFields: [],
            uploadSuccess: nil
        )
    }
    
    // MARK: - Helper Methods
    
    private func calculateOverallHealthScore(
        aiResult: AIScoreAuditResult?,
        sparcResult: SPARCAuditResult?,
        customExerciseResult: CustomExerciseAuditResult?,
        circleROMResult: CircleROMAuditResult?,
        metricsResult: MetricsAuditResult?,
        uploadResult: UploadAuditResult?
    ) -> Double {
        let results: [AuditResultProtocol?] = [
            aiResult, sparcResult, customExerciseResult,
            circleROMResult, metricsResult, uploadResult
        ]
        
        let validResults = results.compactMap { $0 }
        guard !validResults.isEmpty else { return 0.0 }
        
        // Calculate weighted score based on validity and issue severity
        let totalScore = validResults.reduce(0.0) { total, result in
            var score = result.isValid ? 100.0 : 0.0
            
            // Deduct points for issues based on severity
            for issue in result.issues {
                switch issue.severity {
                case .critical:
                    score -= 25.0
                case .high:
                    score -= 15.0
                case .medium:
                    score -= 10.0
                case .low:
                    score -= 5.0
                case .info:
                    score -= 1.0
                }
            }
            
            return total + max(0.0, score)
        }
        
        return totalScore / Double(validResults.count)
    }
    
    private func addToHistory(_ result: SystemAuditResult) {
        auditHistory.append(result)
        if auditHistory.count > maxHistoryEntries {
            auditHistory.removeFirst(auditHistory.count - maxHistoryEntries)
        }
    }
    
    private func createEmptyAuditResult() -> SystemAuditResult {
        return SystemAuditResult(overallHealthScore: 0.0)
    }
    
    private func createErrorAuditResult(error: Error) -> SystemAuditResult {
        let issue = AuditIssue(
            severity: .critical,
            category: .systemHealth,
            description: "System audit failed: \(error.localizedDescription)"
        )
        
        let errorResult = BaseAuditResult(
            isValid: false,
            issues: [issue],
            recommendations: ["Investigate system audit failure", "Check system logs for details"],
            validatorName: "SystemAudit"
        )
        
        return SystemAuditResult(overallHealthScore: 0.0)
    }
    
    private func setupAuditSystem() {
        logger.logSystemHealth(
            component: "AuditCoordinator",
            isHealthy: true,
            metrics: ["initialized": true, "validators_ready": false]
        )
    }
}

// MARK: - Supporting Types

enum AuditComponent: String, CaseIterable {
    case aiScoring = "AI Scoring"
    case sparcCalculation = "SPARC Calculation"
    case customExercise = "Custom Exercise"
    case circleROM = "Circle ROM"
    case metricsCollection = "Metrics Collection"
    case dataUpload = "Data Upload"
}

enum AuditError: Error {
    case auditInProgress
    case validatorNotFound(String)
    case auditFailed(String)
    
    var localizedDescription: String {
        switch self {
        case .auditInProgress:
            return "An audit is already in progress"
        case .validatorNotFound(let validator):
            return "Validator not found: \(validator)"
        case .auditFailed(let reason):
            return "Audit failed: \(reason)"
        }
    }
}

// MARK: - Audit System Health Check

extension AuditCoordinator {
    
    /// Perform basic health check of the audit system
    func performHealthCheck() -> AuditSystemHealthResult {
        let startTime = Date()
        
        // Check logger functionality
        let loggerHealthy = logger.isLoggingEnabled
        
        // Check validation utilities
        let testData = TestDataSets.createLinearMotionData()
        let validationResult = ValidationUtilities.validateMotionData(testData.motionData)
        let validationHealthy = validationResult.dataQuality.overall > 0.8
        
        // Check test data integrity
        let testSummary = TestDataSets.runAllValidationTests()
        let testDataHealthy = testSummary.successRate > 0.9
        
        let overallHealthy = loggerHealthy && validationHealthy && testDataHealthy
        
        let healthResult = AuditSystemHealthResult(
            isHealthy: overallHealthy,
            loggerStatus: loggerHealthy,
            validationStatus: validationHealthy,
            testDataStatus: testDataHealthy,
            checkDuration: Date().timeIntervalSince(startTime)
        )
        
        logger.logSystemHealth(
            component: "AuditSystem",
            isHealthy: overallHealthy,
            metrics: [
                "logger": loggerHealthy,
                "validation": validationHealthy,
                "test_data": testDataHealthy,
                "check_duration": healthResult.checkDuration
            ]
        )
        
        return healthResult
    }
}

struct AuditSystemHealthResult {
    let isHealthy: Bool
    let loggerStatus: Bool
    let validationStatus: Bool
    let testDataStatus: Bool
    let checkDuration: TimeInterval
}