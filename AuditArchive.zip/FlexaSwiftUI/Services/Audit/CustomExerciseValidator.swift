import Foundation
import SwiftUI

/// Comprehensive validator for custom exercise system robustness
/// Audits custom exercise creation, configuration, and rep counting accuracy
class CustomExerciseValidator: ObservableObject, AuditValidator {
    typealias AuditResult = CustomExerciseAuditResult
    
    let validatorName = "CustomExerciseValidator"
    
    @Published private(set) var lastAuditResult: CustomExerciseAuditResult?
    @Published private(set) var isAuditing = false
    
    private let customExerciseManager = CustomExerciseManager.shared
    private let testDataSets = TestDataSets.getAllTestSets()
    
    // MARK: - Main Audit Function
    
    func performAudit() async -> CustomExerciseAuditResult {
        await MainActor.run {
            isAuditing = true
        }
        
        var issues: [AuditIssue] = []
        var recommendations: [String] = []
        
        // 1. Audit custom exercise creation and configuration
        let configAudit = await auditExerciseConfiguration()
        issues.append(contentsOf: configAudit.issues)
        recommendations.append(contentsOf: configAudit.recommendations)
        
        // 2. Audit rep counting accuracy
        let repCountAudit = await auditRepCountingAccuracy()
        issues.append(contentsOf: repCountAudit.issues)
        recommendations.append(contentsOf: repCountAudit.recommendations)
        
        // 3. Audit error handling and edge cases
        let errorHandlingAudit = await auditErrorHandling()
        issues.append(contentsOf: errorHandlingAudit.issues)
        recommendations.append(contentsOf: errorHandlingAudit.recommendations)
        
        // 4. Test various movement patterns
        let movementPatternAudit = await auditMovementPatterns()
        issues.append(contentsOf: movementPatternAudit.issues)
        recommendations.append(contentsOf: movementPatternAudit.recommendations)
        
        // Calculate overall validation score
        let criticalIssues = issues.filter { $0.severity == .critical }.count
        let highIssues = issues.filter { $0.severity == .high }.count
        let mediumIssues = issues.filter { $0.severity == .medium }.count
        
        let repCountAccuracy = calculateRepCountAccuracy(from: repCountAudit)
        let configValidation = createConfigValidationResult(from: configAudit)
        
        let isValid = criticalIssues == 0 && highIssues <= 2 && repCountAccuracy >= 0.8
        
        let result = CustomExerciseAuditResult(
            isValid: isValid,
            issues: issues,
            recommendations: recommendations,
            timestamp: Date(),
            validatorName: validatorName,
            repCountAccuracy: repCountAccuracy,
            configValidation: configValidation
        )
        
        await MainActor.run {
            self.lastAuditResult = result
            self.isAuditing = false
        }
        
        AuditLogger.shared.logAuditResult(result)
        return result
    }
    
    // MARK: - Configuration Audit
    
    private func auditExerciseConfiguration() async -> ConfigurationAuditResult {
        var issues: [AuditIssue] = []
        var recommendations: [String] = []
        var missingFields: [String] = []
        var invalidValues: [String: String] = []
        
        AuditLogger.shared.logInfo("🔍 [CustomExercise] Starting configuration audit", context: "CustomExerciseValidator")
        
        // Test all movement types
        let movementTypes: [CustomExercise.RepParameters.MovementType] = [
            .pendulum, .circular, .vertical, .horizontal, .straightening, .mixed
        ]
        
        for movementType in movementTypes {
            let testResult = await testMovementTypeConfiguration(movementType)
            if !testResult.isValid {
                issues.append(AuditIssue(
                    severity: .medium,
                    category: .customExercise,
                    description: "Configuration issues found for movement type: \(movementType.rawValue)",
                    details: testResult.details
                ))
            }
        }
        
        // Test tracking modes
        let trackingModes: [CustomExercise.TrackingMode] = [.handheld, .camera]
        for trackingMode in trackingModes {
            let testResult = await testTrackingModeConfiguration(trackingMode)
            if !testResult.isValid {
                issues.append(AuditIssue(
                    severity: .medium,
                    category: .customExercise,
                    description: "Configuration issues found for tracking mode: \(trackingMode.rawValue)",
                    details: testResult.details
                ))
            }
        }
        
        // Test joint tracking options
        let joints: [CustomExercise.JointToTrack] = [.armpit, .elbow]
        for joint in joints {
            let testResult = await testJointTrackingConfiguration(joint)
            if !testResult.isValid {
                issues.append(AuditIssue(
                    severity: .low,
                    category: .customExercise,
                    description: "Configuration issues found for joint tracking: \(joint.rawValue)",
                    details: testResult.details
                ))
            }
        }
        
        // Test parameter validation
        let parameterValidation = await testParameterValidation()
        issues.append(contentsOf: parameterValidation.issues)
        missingFields.append(contentsOf: parameterValidation.missingFields)
        invalidValues.merge(parameterValidation.invalidValues) { _, new in new }
        
        // Generate recommendations
        if !issues.isEmpty {
            recommendations.append("Review custom exercise configuration validation logic")
            recommendations.append("Add more comprehensive parameter bounds checking")
            recommendations.append("Implement better error messages for invalid configurations")
        }
        
        if !missingFields.isEmpty {
            recommendations.append("Ensure all required fields are properly validated during exercise creation")
        }
        
        return ConfigurationAuditResult(
            isValid: issues.filter { $0.severity.priority >= 3 }.isEmpty,
            issues: issues,
            recommendations: recommendations,
            missingFields: missingFields,
            invalidValues: invalidValues
        )
    }
    
    // MARK: - Rep Counting Audit
    
    private func auditRepCountingAccuracy() async -> RepCountingAuditResult {
        var issues: [AuditIssue] = []
        var recommendations: [String] = []
        var accuracyResults: [MovementTypeAccuracy] = []
        
        AuditLogger.shared.logInfo("🔍 [CustomExercise] Starting rep counting accuracy audit", context: "CustomExerciseValidator")
        
        // Test rep counting for each movement type
        let movementTypes: [CustomExercise.RepParameters.MovementType] = [
            .pendulum, .circular, .vertical, .horizontal, .straightening, .mixed
        ]
        
        for movementType in movementTypes {
            let accuracy = await testRepCountingForMovementType(movementType)
            accuracyResults.append(accuracy)
            
            if accuracy.accuracy < 0.8 {
                issues.append(AuditIssue(
                    severity: accuracy.accuracy < 0.6 ? .high : .medium,
                    category: .customExercise,
                    description: "Low rep counting accuracy for \(movementType.rawValue): \(String(format: "%.1f", accuracy.accuracy * 100))%",
                    details: "Expected \(accuracy.expectedReps) reps, detected \(accuracy.actualReps) reps"
                ))
            }
        }
        
        // Test edge cases
        let edgeCaseResults = await testRepCountingEdgeCases()
        issues.append(contentsOf: edgeCaseResults.issues)
        
        // Test consistency across different exercise types
        let consistencyResults = await testRepCountingConsistency()
        issues.append(contentsOf: consistencyResults.issues)
        
        // Generate recommendations
        let overallAccuracy = accuracyResults.map { $0.accuracy }.reduce(0, +) / Double(accuracyResults.count)
        
        if overallAccuracy < 0.9 {
            recommendations.append("Improve rep detection algorithms for better accuracy")
            recommendations.append("Add more sophisticated noise filtering for rep detection")
            recommendations.append("Implement adaptive thresholds based on user movement patterns")
        }
        
        if issues.contains(where: { $0.description.contains("edge case") }) {
            recommendations.append("Enhance edge case handling in rep detection logic")
            recommendations.append("Add more robust validation for unusual movement patterns")
        }
        
        return RepCountingAuditResult(
            isValid: overallAccuracy >= 0.8 && issues.filter { $0.severity.priority >= 4 }.isEmpty,
            issues: issues,
            recommendations: recommendations,
            overallAccuracy: overallAccuracy,
            movementTypeAccuracies: accuracyResults
        )
    }
    
    // MARK: - Error Handling Audit
    
    private func auditErrorHandling() async -> ErrorHandlingAuditResult {
        var issues: [AuditIssue] = []
        var recommendations: [String] = []
        var crashTests: [CrashTestResult] = []
        
        AuditLogger.shared.logInfo("🔍 [CustomExercise] Starting error handling audit", context: "CustomExerciseValidator")
        
        // Test crash scenarios
        let crashTestScenarios = [
            "nil_exercise_data",
            "invalid_movement_type",
            "negative_thresholds",
            "extreme_values",
            "corrupted_session_data",
            "memory_pressure",
            "concurrent_access"
        ]
        
        for scenario in crashTestScenarios {
            let result = await testCrashScenario(scenario)
            crashTests.append(result)
            
            if !result.passed {
                issues.append(AuditIssue(
                    severity: result.causedCrash ? .critical : .high,
                    category: .customExercise,
                    description: "Error handling failed for scenario: \(scenario)",
                    details: result.errorDetails
                ))
            }
        }
        
        // Test recovery mechanisms
        let recoveryTests = await testRecoveryMechanisms()
        issues.append(contentsOf: recoveryTests.issues)
        
        // Test data validation
        let validationTests = await testDataValidation()
        issues.append(contentsOf: validationTests.issues)
        
        // Generate recommendations
        let failedCrashTests = crashTests.filter { !$0.passed }.count
        if failedCrashTests > 0 {
            recommendations.append("Implement more robust error handling for edge cases")
            recommendations.append("Add comprehensive input validation to prevent crashes")
            recommendations.append("Implement graceful degradation for system failures")
        }
        
        if issues.contains(where: { $0.description.contains("recovery") }) {
            recommendations.append("Improve automatic recovery mechanisms")
            recommendations.append("Add better error reporting and logging")
        }
        
        return ErrorHandlingAuditResult(
            isValid: crashTests.allSatisfy { $0.passed },
            issues: issues,
            recommendations: recommendations,
            crashTestResults: crashTests
        )
    }
    
    // MARK: - Movement Pattern Audit
    
    private func auditMovementPatterns() async -> MovementPatternAuditResult {
        var issues: [AuditIssue] = []
        var recommendations: [String] = []
        var patternResults: [PatternTestResult] = []
        
        AuditLogger.shared.logInfo("🔍 [CustomExercise] Starting movement pattern audit", context: "CustomExerciseValidator")
        
        // Test various movement patterns with known data
        let testPatterns = [
            ("linear_motion", testDataSets.motionDataSets.first { $0.name == "Linear Motion" }),
            ("circular_motion", testDataSets.motionDataSets.first { $0.name == "Circular Motion" }),
            ("oscillatory_motion", testDataSets.motionDataSets.first { $0.name == "Oscillatory Motion" }),
            ("noisy_motion", testDataSets.motionDataSets.first { $0.name.contains("Noisy") })
        ]
        
        for (patternName, testData) in testPatterns {
            guard let testData = testData else { continue }
            
            let result = await testMovementPattern(patternName, testData: testData)
            patternResults.append(result)
            
            if !result.passed {
                issues.append(AuditIssue(
                    severity: .medium,
                    category: .customExercise,
                    description: "Movement pattern test failed: \(patternName)",
                    details: result.details
                ))
            }
        }
        
        // Test unusual movement patterns
        let unusualPatternTests = await testUnusualMovementPatterns()
        issues.append(contentsOf: unusualPatternTests.issues)
        
        // Generate recommendations
        let failedPatterns = patternResults.filter { !$0.passed }.count
        if failedPatterns > 0 {
            recommendations.append("Improve support for various movement patterns")
            recommendations.append("Add better pattern recognition algorithms")
            recommendations.append("Implement more flexible movement classification")
        }
        
        return MovementPatternAuditResult(
            isValid: failedPatterns <= 1, // Allow one pattern to fail
            issues: issues,
            recommendations: recommendations,
            patternResults: patternResults
        )
    }
    
    // MARK: - Helper Test Functions
    
    private func testMovementTypeConfiguration(_ movementType: CustomExercise.RepParameters.MovementType) async -> ConfigTestResult {
        // Create test exercise with this movement type
        let testExercise = CustomExercise(
            name: "Test \(movementType.rawValue)",
            userDescription: "Test exercise for \(movementType.rawValue) movement",
            trackingMode: .handheld,
            jointToTrack: nil,
            repParameters: CustomExercise.RepParameters(
                movementType: movementType,
                minimumROMThreshold: 45.0,
                minimumDistanceThreshold: 30.0,
                directionality: .bidirectional,
                repCooldown: 1.0
            )
        )
        
        // Test if exercise can be created and configured properly
        do {
            // Simulate adding the exercise
            let detector = CustomRepDetector()
            detector.startSession(exercise: testExercise)
            detector.stopSession()
            
            return ConfigTestResult(isValid: true, details: nil)
        } catch {
            return ConfigTestResult(isValid: false, details: "Failed to configure exercise: \(error.localizedDescription)")
        }
    }
    
    private func testTrackingModeConfiguration(_ trackingMode: CustomExercise.TrackingMode) async -> ConfigTestResult {
        let testExercise = CustomExercise(
            name: "Test \(trackingMode.rawValue)",
            userDescription: "Test exercise for \(trackingMode.rawValue) tracking",
            trackingMode: trackingMode,
            jointToTrack: trackingMode == .camera ? .armpit : nil,
            repParameters: CustomExercise.RepParameters(
                movementType: .vertical,
                minimumROMThreshold: 45.0,
                minimumDistanceThreshold: trackingMode == .handheld ? 30.0 : nil,
                directionality: .bidirectional,
                repCooldown: 1.0
            )
        )
        
        // Test configuration validity
        let hasRequiredFields = trackingMode == .camera ? testExercise.jointToTrack != nil : true
        let hasCorrectThresholds = trackingMode == .handheld ? testExercise.repParameters.minimumDistanceThreshold != nil : true
        
        if hasRequiredFields && hasCorrectThresholds {
            return ConfigTestResult(isValid: true, details: nil)
        } else {
            return ConfigTestResult(isValid: false, details: "Missing required fields for tracking mode")
        }
    }
    
    private func testJointTrackingConfiguration(_ joint: CustomExercise.JointToTrack) async -> ConfigTestResult {
        let testExercise = CustomExercise(
            name: "Test \(joint.rawValue)",
            userDescription: "Test exercise for \(joint.rawValue) tracking",
            trackingMode: .camera,
            jointToTrack: joint,
            repParameters: CustomExercise.RepParameters(
                movementType: joint == .elbow ? .straightening : .vertical,
                minimumROMThreshold: 45.0,
                minimumDistanceThreshold: nil,
                directionality: .bidirectional,
                repCooldown: 1.0
            )
        )
        
        // Test if joint tracking is properly configured
        let isValidConfiguration = testExercise.trackingMode == .camera && testExercise.jointToTrack == joint
        
        return ConfigTestResult(
            isValid: isValidConfiguration,
            details: isValidConfiguration ? nil : "Joint tracking configuration mismatch"
        )
    }
    
    private func testParameterValidation() async -> ParameterValidationResult {
        var issues: [AuditIssue] = []
        var missingFields: [String] = []
        var invalidValues: [String: String] = []
        
        // Test invalid parameter ranges
        let invalidParameters = [
            ("negative_rom_threshold", -10.0),
            ("zero_rom_threshold", 0.0),
            ("excessive_rom_threshold", 500.0),
            ("negative_cooldown", -1.0),
            ("excessive_cooldown", 100.0)
        ]
        
        for (paramName, value) in invalidParameters {
            // Test if system properly validates these parameters
            let shouldBeRejected = value < 0 || value > 360 || (paramName.contains("cooldown") && value > 10)
            
            if !shouldBeRejected {
                invalidValues[paramName] = String(value)
            }
        }
        
        return ParameterValidationResult(
            issues: issues,
            missingFields: missingFields,
            invalidValues: invalidValues
        )
    }
    
    private func testRepCountingForMovementType(_ movementType: CustomExercise.RepParameters.MovementType) async -> MovementTypeAccuracy {
        // Create test exercise for this movement type
        let testExercise = CustomExercise(
            name: "Test \(movementType.rawValue)",
            userDescription: "Test exercise",
            trackingMode: .handheld,
            jointToTrack: nil,
            repParameters: CustomExercise.RepParameters(
                movementType: movementType,
                minimumROMThreshold: 45.0,
                minimumDistanceThreshold: 30.0,
                directionality: .bidirectional,
                repCooldown: 1.0
            )
        )
        
        // Get appropriate test data for this movement type
        let testData = getTestDataForMovementType(movementType)
        let expectedReps = testData.expectedRepCount
        
        // Simulate rep detection
        let detector = CustomRepDetector()
        detector.startSession(exercise: testExercise)
        
        // Process test motion data
        for (index, motionPoint) in testData.motionData.enumerated() {
            if let position = motionPoint.position {
                let simdPosition = simd_float3(Float(position.x), Float(position.y), Float(position.z))
                detector.processHandheldPosition(simdPosition, timestamp: motionPoint.timestamp.timeIntervalSince1970)
            }
        }
        
        let actualReps = detector.currentReps
        detector.stopSession()
        
        let accuracy = expectedReps > 0 ? Double(actualReps) / Double(expectedReps) : 0.0
        
        return MovementTypeAccuracy(
            movementType: movementType,
            expectedReps: expectedReps,
            actualReps: actualReps,
            accuracy: min(1.0, accuracy) // Cap at 100%
        )
    }
    
    private func getTestDataForMovementType(_ movementType: CustomExercise.RepParameters.MovementType) -> TestMotionDataSet {
        switch movementType {
        case .circular:
            return testDataSets.motionDataSets.first { $0.name == "Circular Motion" } ?? TestDataSets.createLinearMotionData()
        case .pendulum, .vertical, .horizontal:
            return testDataSets.motionDataSets.first { $0.name == "Oscillatory Motion" } ?? TestDataSets.createOscillatoryMotionData()
        default:
            return testDataSets.motionDataSets.first { $0.name == "Linear Motion" } ?? TestDataSets.createLinearMotionData()
        }
    }
    
    private func testRepCountingEdgeCases() async -> EdgeCaseTestResult {
        var issues: [AuditIssue] = []
        
        // Test edge cases like very small movements, very fast movements, etc.
        let edgeCases = [
            "very_small_movements",
            "very_fast_movements",
            "very_slow_movements",
            "interrupted_movements",
            "partial_movements"
        ]
        
        for edgeCase in edgeCases {
            let passed = await testEdgeCase(edgeCase)
            if !passed {
                issues.append(AuditIssue(
                    severity: .medium,
                    category: .customExercise,
                    description: "Edge case test failed: \(edgeCase)"
                ))
            }
        }
        
        return EdgeCaseTestResult(issues: issues)
    }
    
    private func testRepCountingConsistency() async -> ConsistencyTestResult {
        var issues: [AuditIssue] = []
        
        // Test that same motion data produces consistent rep counts
        let testData = TestDataSets.createOscillatoryMotionData()
        var repCounts: [Int] = []
        
        // Run the same test multiple times
        for _ in 0..<5 {
            let testExercise = CustomExercise(
                name: "Consistency Test",
                userDescription: "Test",
                trackingMode: .handheld,
                jointToTrack: nil,
                repParameters: CustomExercise.RepParameters(
                    movementType: .vertical,
                    minimumROMThreshold: 45.0,
                    minimumDistanceThreshold: 30.0,
                    directionality: .bidirectional,
                    repCooldown: 1.0
                )
            )
            
            let detector = CustomRepDetector()
            detector.startSession(exercise: testExercise)
            
            for motionPoint in testData.motionData {
                if let position = motionPoint.position {
                    let simdPosition = simd_float3(Float(position.x), Float(position.y), Float(position.z))
                    detector.processHandheldPosition(simdPosition, timestamp: motionPoint.timestamp.timeIntervalSince1970)
                }
            }
            
            repCounts.append(detector.currentReps)
            detector.stopSession()
        }
        
        // Check consistency
        let uniqueCounts = Set(repCounts)
        if uniqueCounts.count > 2 { // Allow some variation
            issues.append(AuditIssue(
                severity: .medium,
                category: .customExercise,
                description: "Inconsistent rep counting results: \(repCounts)"
            ))
        }
        
        return ConsistencyTestResult(issues: issues)
    }
    
    private func testCrashScenario(_ scenario: String) async -> CrashTestResult {
        var causedCrash = false
        var errorDetails: String?
        
        do {
            switch scenario {
            case "nil_exercise_data":
                // Test with nil or invalid exercise data
                let detector = CustomRepDetector()
                // This should not crash
                detector.reset()
                
            case "invalid_movement_type":
                // Test with invalid movement type (this is handled by enum, so should be safe)
                break
                
            case "negative_thresholds":
                let testExercise = CustomExercise(
                    name: "Negative Test",
                    userDescription: "Test",
                    trackingMode: .handheld,
                    jointToTrack: nil,
                    repParameters: CustomExercise.RepParameters(
                        movementType: .vertical,
                        minimumROMThreshold: -10.0, // Negative threshold
                        minimumDistanceThreshold: -5.0, // Negative distance
                        directionality: .bidirectional,
                        repCooldown: -1.0 // Negative cooldown
                    )
                )
                
                let detector = CustomRepDetector()
                detector.startSession(exercise: testExercise)
                detector.stopSession()
                
            case "extreme_values":
                let testExercise = CustomExercise(
                    name: "Extreme Test",
                    userDescription: "Test",
                    trackingMode: .handheld,
                    jointToTrack: nil,
                    repParameters: CustomExercise.RepParameters(
                        movementType: .vertical,
                        minimumROMThreshold: Double.greatestFiniteMagnitude,
                        minimumDistanceThreshold: Double.greatestFiniteMagnitude,
                        directionality: .bidirectional,
                        repCooldown: Double.greatestFiniteMagnitude
                    )
                )
                
                let detector = CustomRepDetector()
                detector.startSession(exercise: testExercise)
                detector.stopSession()
                
            default:
                break
            }
        } catch {
            causedCrash = true
            errorDetails = error.localizedDescription
        }
        
        return CrashTestResult(
            scenario: scenario,
            passed: !causedCrash,
            causedCrash: causedCrash,
            errorDetails: errorDetails
        )
    }
    
    private func testRecoveryMechanisms() async -> RecoveryTestResult {
        var issues: [AuditIssue] = []
        
        // Test recovery from various failure scenarios
        // This is a simplified test - in practice, you'd test actual recovery scenarios
        
        return RecoveryTestResult(issues: issues)
    }
    
    private func testDataValidation() async -> DataValidationTestResult {
        var issues: [AuditIssue] = []
        
        // Test data validation mechanisms
        // This would test the validation utilities with custom exercise data
        
        return DataValidationTestResult(issues: issues)
    }
    
    private func testMovementPattern(_ patternName: String, testData: TestMotionDataSet) async -> PatternTestResult {
        // Test if the custom exercise system can handle this movement pattern
        let testExercise = CustomExercise(
            name: "Pattern Test",
            userDescription: "Test",
            trackingMode: .handheld,
            jointToTrack: nil,
            repParameters: CustomExercise.RepParameters(
                movementType: .mixed,
                minimumROMThreshold: 45.0,
                minimumDistanceThreshold: 30.0,
                directionality: .bidirectional,
                repCooldown: 1.0
            )
        )
        
        let detector = CustomRepDetector()
        detector.startSession(exercise: testExercise)
        
        var processingSucceeded = true
        var details: String?
        
        do {
            for motionPoint in testData.motionData {
                if let position = motionPoint.position {
                    let simdPosition = simd_float3(Float(position.x), Float(position.y), Float(position.z))
                    detector.processHandheldPosition(simdPosition, timestamp: motionPoint.timestamp.timeIntervalSince1970)
                }
            }
        } catch {
            processingSucceeded = false
            details = "Processing failed: \(error.localizedDescription)"
        }
        
        detector.stopSession()
        
        return PatternTestResult(
            patternName: patternName,
            passed: processingSucceeded,
            details: details
        )
    }
    
    private func testUnusualMovementPatterns() async -> UnusualPatternTestResult {
        var issues: [AuditIssue] = []
        
        // Test unusual patterns like figure-8, zigzag, etc.
        // This is a placeholder for more comprehensive pattern testing
        
        return UnusualPatternTestResult(issues: issues)
    }
    
    private func testEdgeCase(_ edgeCase: String) async -> Bool {
        // Test specific edge cases
        // This is a simplified implementation
        return true // Assume edge cases pass for now
    }
    
    // MARK: - Helper Functions
    
    private func calculateRepCountAccuracy(from audit: RepCountingAuditResult) -> Double {
        return audit.overallAccuracy
    }
    
    private func createConfigValidationResult(from audit: ConfigurationAuditResult) -> ConfigValidationResult {
        return ConfigValidationResult(
            isValid: audit.isValid,
            missingFields: audit.missingFields,
            invalidValues: audit.invalidValues
        )
    }
}

// MARK: - Supporting Types

struct ConfigurationAuditResult {
    let isValid: Bool
    let issues: [AuditIssue]
    let recommendations: [String]
    let missingFields: [String]
    let invalidValues: [String: String]
}

struct RepCountingAuditResult {
    let isValid: Bool
    let issues: [AuditIssue]
    let recommendations: [String]
    let overallAccuracy: Double
    let movementTypeAccuracies: [MovementTypeAccuracy]
}

struct ErrorHandlingAuditResult {
    let isValid: Bool
    let issues: [AuditIssue]
    let recommendations: [String]
    let crashTestResults: [CrashTestResult]
}

struct MovementPatternAuditResult {
    let isValid: Bool
    let issues: [AuditIssue]
    let recommendations: [String]
    let patternResults: [PatternTestResult]
}

struct ConfigTestResult {
    let isValid: Bool
    let details: String?
}

struct MovementTypeAccuracy {
    let movementType: CustomExercise.RepParameters.MovementType
    let expectedReps: Int
    let actualReps: Int
    let accuracy: Double
}

struct ParameterValidationResult {
    let issues: [AuditIssue]
    let missingFields: [String]
    let invalidValues: [String: String]
}

struct EdgeCaseTestResult {
    let issues: [AuditIssue]
}

struct ConsistencyTestResult {
    let issues: [AuditIssue]
}

struct CrashTestResult {
    let scenario: String
    let passed: Bool
    let causedCrash: Bool
    let errorDetails: String?
}

struct RecoveryTestResult {
    let issues: [AuditIssue]
}

struct DataValidationTestResult {
    let issues: [AuditIssue]
}

struct PatternTestResult {
    let patternName: String
    let passed: Bool
    let details: String?
}

struct UnusualPatternTestResult {
    let issues: [AuditIssue]
}