import Foundation
import SwiftUI

/// Comprehensive logging system for AI score calculations
/// Tracks all calculation steps for debugging and validation
/// Addresses Requirements 1.2, 1.5 for transparent score calculation
@MainActor class ScoreCalculationLogger: ObservableObject {
    static let shared = ScoreCalculationLogger()
    
    // MARK: - Published State
    @Published var calculationLogs: [CalculationLog] = []
    @Published var isLogging: Bool = true
    @Published var logLevel: LogLevel = .info
    
    // MARK: - Log Structures
    struct CalculationLog: Identifiable {
        let id = UUID()
        let timestamp: Date
        let sessionId: String
        let exerciseType: String
        let calculationSteps: [CalculationStep]
        let finalScores: FinalScores
        let validationResults: ValidationResult
        let duration: TimeInterval
    }
    
    struct CalculationStep: Identifiable {
        let id = UUID()
        let stepName: String
        let stepType: StepType
        let inputData: [String: Any]
        let algorithm: String
        let outputValue: Double
        let isValid: Bool
        let timestamp: Date
        let duration: TimeInterval
        let notes: String
    }
    
    enum StepType {
        case dataCollection
        case formCalculation
        case smoothnessCalculation
        case consistencyCalculation
        case weightedScoring
        case contextualAdjustment
        case validation
        case fallback
        
        var icon: String {
            switch self {
            case .dataCollection: return "📊"
            case .formCalculation: return "🎯"
            case .smoothnessCalculation: return "🌊"
            case .consistencyCalculation: return "📏"
            case .weightedScoring: return "⚖️"
            case .contextualAdjustment: return "🔧"
            case .validation: return "✅"
            case .fallback: return "🛡️"
            }
        }
    }
    
    struct FinalScores {
        let aiScore: Double
        let formScore: Double
        let smoothnessScore: Double
        let consistencyScore: Double
        let gameScore: Int
    }
    
    struct ValidationResult {
        let allScoresValid: Bool
        let scoresInBounds: Bool
        let correlationWithMotion: Bool
        let noPlaceholderData: Bool
        let issues: [String]
    }
    
    enum LogLevel: String, CaseIterable {
        case debug = "DEBUG"
        case info = "INFO"
        case warning = "WARNING"
        case error = "ERROR"
        
        var color: Color {
            switch self {
            case .debug: return .gray
            case .info: return .blue
            case .warning: return .orange
            case .error: return .red
            }
        }
    }
    
    private init() {
        // Keep only last 100 logs to prevent memory issues
        setupLogRotation()
    }
    
    // MARK: - Logging Methods
    
    /// Start logging a new score calculation session
    func startCalculationLogging(sessionId: String, exerciseType: String) -> CalculationLogSession {
        let session = CalculationLogSession(
            sessionId: sessionId,
            exerciseType: exerciseType,
            startTime: Date(),
            logger: self
        )
        
        logInfo("🚀 Started score calculation logging for \(exerciseType) (Session: \(sessionId))")
        return session
    }
    
    /// Log a calculation step
    func logCalculationStep(
        sessionId: String,
        stepName: String,
        stepType: StepType,
        inputData: [String: Any],
        algorithm: String,
        outputValue: Double,
        isValid: Bool,
        duration: TimeInterval,
        notes: String = ""
    ) {
        let step = CalculationStep(
            stepName: stepName,
            stepType: stepType,
            inputData: inputData,
            algorithm: algorithm,
            outputValue: outputValue,
            isValid: isValid,
            timestamp: Date(),
            duration: duration,
            notes: notes
        )
        
        // Find existing log or create new one
        if let index = calculationLogs.firstIndex(where: { $0.sessionId == sessionId }) {
            calculationLogs[index].calculationSteps.append(step)
        }
        
        let statusIcon = isValid ? "✅" : "❌"
        let durationMs = Int(duration * 1000)
        logInfo("\(stepType.icon) \(statusIcon) \(stepName): \(String(format: "%.2f", outputValue)) (\(durationMs)ms) - \(algorithm)")
        
        if !notes.isEmpty {
            logDebug("   📝 \(notes)")
        }
        
        if !isValid {
            logWarning("   ⚠️ Validation failed for \(stepName)")
        }
    }
    
    /// Complete calculation logging and store final results
    func completeCalculationLogging(
        sessionId: String,
        finalScores: FinalScores,
        validationResults: ValidationResult,
        totalDuration: TimeInterval
    ) {
        // Find the log entry
        if let index = calculationLogs.firstIndex(where: { $0.sessionId == sessionId }) {
            // Update with final results
            let updatedLog = CalculationLog(
                timestamp: calculationLogs[index].timestamp,
                sessionId: sessionId,
                exerciseType: calculationLogs[index].exerciseType,
                calculationSteps: calculationLogs[index].calculationSteps,
                finalScores: finalScores,
                validationResults: validationResults,
                duration: totalDuration
            )
            calculationLogs[index] = updatedLog
        }
        
        let validationIcon = validationResults.allScoresValid ? "✅" : "❌"
        let durationMs = Int(totalDuration * 1000)
        
        logInfo("🏁 \(validationIcon) Completed score calculation for \(sessionId) (\(durationMs)ms)")
        logInfo("   🤖 AI: \(Int(finalScores.aiScore))% | 🎯 Form: \(Int(finalScores.formScore))% | 🌊 Smoothness: \(Int(finalScores.smoothnessScore))% | 📏 Consistency: \(Int(finalScores.consistencyScore))%")
        
        if !validationResults.allScoresValid {
            logWarning("   ⚠️ Validation issues: \(validationResults.issues.joined(separator: ", "))")
        }
    }
    
    /// Log placeholder data detection
    func logPlaceholderDetection(
        sessionId: String,
        fieldName: String,
        expectedValue: String,
        actualValue: String,
        severity: PlaceholderDataFixer.Severity
    ) {
        let severityIcon = severity == .critical ? "🚨" : "⚠️"
        logWarning("\(severityIcon) Placeholder detected in \(sessionId): \(fieldName) = \(actualValue) (expected: \(expectedValue))")
    }
    
    /// Log score validation failure
    func logValidationFailure(
        sessionId: String,
        fieldName: String,
        value: Double,
        expectedRange: ClosedRange<Double>,
        reason: String
    ) {
        logError("❌ Validation failed for \(sessionId): \(fieldName) = \(value) (expected: \(expectedRange.lowerBound)-\(expectedRange.upperBound)) - \(reason)")
    }
    
    /// Log fallback scoring usage
    func logFallbackUsage(
        sessionId: String,
        reason: String,
        fallbackMethod: String,
        fallbackScores: FinalScores
    ) {
        logWarning("🛡️ Using fallback scoring for \(sessionId): \(reason)")
        logInfo("   🔄 Fallback method: \(fallbackMethod)")
        logInfo("   🔄 Fallback scores - AI: \(Int(fallbackScores.aiScore))%, Form: \(Int(fallbackScores.formScore))%, Smoothness: \(Int(fallbackScores.smoothnessScore))%, Consistency: \(Int(fallbackScores.consistencyScore))%")
    }
    
    // MARK: - Log Level Methods
    
    private func logDebug(_ message: String) {
        guard logLevel == .debug else { return }
        FlexaLog.gemini.debug("🔍 [ScoreLogger] \(message)")
    }
    
    private func logInfo(_ message: String) {
        guard [.debug, .info].contains(logLevel) else { return }
        FlexaLog.gemini.info("ℹ️ [ScoreLogger] \(message)")
    }
    
    private func logWarning(_ message: String) {
        guard [.debug, .info, .warning].contains(logLevel) else { return }
        FlexaLog.gemini.warning("⚠️ [ScoreLogger] \(message)")
    }
    
    private func logError(_ message: String) {
        FlexaLog.gemini.error("❌ [ScoreLogger] \(message)")
    }
    
    // MARK: - Log Management
    
    private func setupLogRotation() {
        // Rotate logs when we exceed 100 entries
        Timer.scheduledTimer(withTimeInterval: 60, repeats: true) { _ in
            Task { @MainActor in
                if self.calculationLogs.count > 100 {
                    self.calculationLogs = Array(self.calculationLogs.suffix(50))
                    self.logInfo("🔄 Rotated calculation logs (kept last 50 entries)")
                }
            }
        }
    }
    
    /// Clear all logs
    func clearLogs() {
        calculationLogs.removeAll()
        logInfo("🗑️ Cleared all calculation logs")
    }
    
    /// Export logs for debugging
    func exportLogs() -> String {
        var export = "# AI Score Calculation Logs\n"
        export += "Generated: \(Date())\n"
        export += "Total Sessions: \(calculationLogs.count)\n\n"
        
        for log in calculationLogs.sorted(by: { $0.timestamp > $1.timestamp }) {
            export += "## Session: \(log.sessionId)\n"
            export += "Exercise: \(log.exerciseType)\n"
            export += "Timestamp: \(log.timestamp)\n"
            export += "Duration: \(String(format: "%.3f", log.duration))s\n"
            export += "Final Scores: AI=\(Int(log.finalScores.aiScore))%, Form=\(Int(log.finalScores.formScore))%, Smoothness=\(Int(log.finalScores.smoothnessScore))%, Consistency=\(Int(log.finalScores.consistencyScore))%\n"
            export += "Validation: \(log.validationResults.allScoresValid ? "PASSED" : "FAILED")\n"
            
            if !log.validationResults.issues.isEmpty {
                export += "Issues: \(log.validationResults.issues.joined(separator: ", "))\n"
            }
            
            export += "\n### Calculation Steps:\n"
            for step in log.calculationSteps {
                export += "- \(step.stepName): \(String(format: "%.2f", step.outputValue)) (\(step.isValid ? "VALID" : "INVALID"))\n"
                export += "  Algorithm: \(step.algorithm)\n"
                if !step.notes.isEmpty {
                    export += "  Notes: \(step.notes)\n"
                }
            }
            export += "\n"
        }
        
        return export
    }
    
    // MARK: - Statistics
    
    /// Get calculation statistics
    func getCalculationStatistics() -> CalculationStatistics {
        let totalSessions = calculationLogs.count
        let validSessions = calculationLogs.filter { $0.validationResults.allScoresValid }.count
        let averageDuration = calculationLogs.isEmpty ? 0 : calculationLogs.map { $0.duration }.reduce(0, +) / Double(totalSessions)
        
        let averageScores = calculationLogs.isEmpty ? FinalScores(aiScore: 0, formScore: 0, smoothnessScore: 0, consistencyScore: 0, gameScore: 0) : FinalScores(
            aiScore: calculationLogs.map { $0.finalScores.aiScore }.reduce(0, +) / Double(totalSessions),
            formScore: calculationLogs.map { $0.finalScores.formScore }.reduce(0, +) / Double(totalSessions),
            smoothnessScore: calculationLogs.map { $0.finalScores.smoothnessScore }.reduce(0, +) / Double(totalSessions),
            consistencyScore: calculationLogs.map { $0.finalScores.consistencyScore }.reduce(0, +) / Double(totalSessions),
            gameScore: 0
        )
        
        return CalculationStatistics(
            totalSessions: totalSessions,
            validSessions: validSessions,
            validationRate: totalSessions > 0 ? Double(validSessions) / Double(totalSessions) : 0,
            averageDuration: averageDuration,
            averageScores: averageScores
        )
    }
    
    struct CalculationStatistics {
        let totalSessions: Int
        let validSessions: Int
        let validationRate: Double
        let averageDuration: TimeInterval
        let averageScores: FinalScores
        
        var validationPercentage: Int {
            return Int(validationRate * 100)
        }
    }
}

// MARK: - Calculation Log Session

/// Helper class for managing a single calculation logging session
class CalculationLogSession {
    let sessionId: String
    let exerciseType: String
    let startTime: Date
    private weak var logger: ScoreCalculationLogger?
    
    init(sessionId: String, exerciseType: String, startTime: Date, logger: ScoreCalculationLogger) {
        self.sessionId = sessionId
        self.exerciseType = exerciseType
        self.startTime = startTime
        self.logger = logger
    }
    
    /// Log a calculation step within this session
    func logStep(
        stepName: String,
        stepType: ScoreCalculationLogger.StepType,
        inputData: [String: Any],
        algorithm: String,
        outputValue: Double,
        isValid: Bool,
        notes: String = ""
    ) {
        let stepStartTime = Date()
        let duration = stepStartTime.timeIntervalSince(startTime)
        
        logger?.logCalculationStep(
            sessionId: sessionId,
            stepName: stepName,
            stepType: stepType,
            inputData: inputData,
            algorithm: algorithm,
            outputValue: outputValue,
            isValid: isValid,
            duration: duration,
            notes: notes
        )
    }
    
    /// Complete this logging session
    func complete(
        finalScores: ScoreCalculationLogger.FinalScores,
        validationResults: ScoreCalculationLogger.ValidationResult
    ) {
        let totalDuration = Date().timeIntervalSince(startTime)
        
        logger?.completeCalculationLogging(
            sessionId: sessionId,
            finalScores: finalScores,
            validationResults: validationResults,
            totalDuration: totalDuration
        )
    }
}