import Foundation
import os.log

/// Comprehensive logging system for audit activities
@MainActor
class AuditLogger: ObservableObject {
    static let shared = AuditLogger()
    
    private let logger = Logger(subsystem: "com.flexa.audit", category: "AuditSystem")
    private let fileLogger: FileLogger
    
    @Published private(set) var auditLogs: [AuditLogEntry] = []
    @Published private(set) var isLoggingEnabled: Bool = true
    
    private let maxLogEntries = 1000
    private let logQueue = DispatchQueue(label: "audit.logging", qos: .utility)
    
    private init() {
        self.fileLogger = FileLogger()
        setupLogRotation()
    }
    
    // MARK: - Public Logging Methods
    
    /// Log audit start
    func logAuditStart(_ validatorName: String, details: String? = nil) {
        log(level: .info, category: .auditLifecycle, message: "Starting audit: \(validatorName)", details: details)
    }
    
    /// Log audit completion
    func logAuditComplete(_ validatorName: String, result: AuditResultProtocol) {
        let status = result.isValid ? "PASSED" : "FAILED"
        let issueCount = result.issues.count
        log(level: .info, category: .auditLifecycle, 
            message: "Audit completed: \(validatorName) - \(status) (\(issueCount) issues)",
            details: "Issues: \(result.issues.map { $0.description }.joined(separator: ", "))")
    }
    
    /// Log audit issue discovery
    func logIssueFound(_ issue: AuditIssue, validator: String) {
        let level: AuditLogLevel = issue.severity == .critical ? .error : 
                                  issue.severity == .high ? .warning : .info
        log(level: level, category: .issueDetection,
            message: "[\(issue.severity.rawValue)] \(issue.description)",
            details: "Validator: \(validator), Category: \(issue.category.rawValue), Details: \(issue.details ?? "None")")
    }
    
    /// Log data validation
    func logDataValidation(validator: String, dataType: String, isValid: Bool, details: String? = nil) {
        let status = isValid ? "VALID" : "INVALID"
        log(level: isValid ? .info : .warning, category: .dataValidation,
            message: "Data validation: \(dataType) - \(status)",
            details: "Validator: \(validator), Details: \(details ?? "None")")
    }
    
    /// Log performance metrics
    func logPerformance(validator: String, operation: String, duration: TimeInterval, details: String? = nil) {
        log(level: .info, category: .performance,
            message: "Performance: \(operation) completed in \(String(format: "%.3f", duration))s",
            details: "Validator: \(validator), Details: \(details ?? "None")")
    }
    
    /// Log system health check
    func logSystemHealth(component: String, isHealthy: Bool, metrics: [String: Any]? = nil) {
        let status = isHealthy ? "HEALTHY" : "UNHEALTHY"
        let metricsString = metrics?.map { "\($0.key): \($0.value)" }.joined(separator: ", ") ?? "None"
        log(level: isHealthy ? .info : .error, category: .systemHealth,
            message: "System health: \(component) - \(status)",
            details: "Metrics: \(metricsString)")
    }
    
    /// Log error with context
    func logError(_ error: Error, context: String, validator: String? = nil) {
        log(level: .error, category: .error,
            message: "Error in \(context): \(error.localizedDescription)",
            details: "Validator: \(validator ?? "Unknown"), Error: \(String(describing: error))")
    }
    
    // MARK: - Private Logging Implementation
    
    private func log(level: AuditLogLevel, category: AuditLogCategory, message: String, details: String? = nil) {
        guard isLoggingEnabled else { return }
        
        let entry = AuditLogEntry(
            level: level,
            category: category,
            message: message,
            details: details,
            timestamp: Date()
        )
        
        // Log to system logger
        switch level {
        case .debug:
            logger.debug("\(message)")
        case .info:
            logger.info("\(message)")
        case .warning:
            logger.warning("\(message)")
        case .error:
            logger.error("\(message)")
        }
        
        // Add to in-memory logs
        Task { @MainActor in
            auditLogs.append(entry)
            if auditLogs.count > maxLogEntries {
                auditLogs.removeFirst(auditLogs.count - maxLogEntries)
            }
        }
        
        // Log to file asynchronously
        logQueue.async { [weak self] in
            self?.fileLogger.writeLog(entry)
        }
    }
    
    // MARK: - Log Management
    
    /// Clear all audit logs
    func clearLogs() {
        auditLogs.removeAll()
        fileLogger.clearLogs()
        log(level: .info, category: .system, message: "Audit logs cleared")
    }
    
    /// Export logs to string
    func exportLogs() -> String {
        return auditLogs.map { entry in
            let timestamp = DateFormatter.auditLogFormatter.string(from: entry.timestamp)
            let details = entry.details.map { " - \($0)" } ?? ""
            return "[\(timestamp)] [\(entry.level.rawValue.uppercased())] [\(entry.category.rawValue)] \(entry.message)\(details)"
        }.joined(separator: "\n")
    }
    
    /// Get logs filtered by category
    func getLogs(for category: AuditLogCategory) -> [AuditLogEntry] {
        return auditLogs.filter { $0.category == category }
    }
    
    /// Get logs filtered by level
    func getLogs(for level: AuditLogLevel) -> [AuditLogEntry] {
        return auditLogs.filter { $0.level == level }
    }
    
    /// Enable/disable logging
    func setLoggingEnabled(_ enabled: Bool) {
        isLoggingEnabled = enabled
        log(level: .info, category: .system, message: "Audit logging \(enabled ? "enabled" : "disabled")")
    }
    
    // MARK: - Log Rotation
    
    private func setupLogRotation() {
        // Rotate logs daily
        Timer.scheduledTimer(withTimeInterval: 24 * 60 * 60, repeats: true) { [weak self] _ in
            self?.fileLogger.rotateLogs()
        }
    }
}

// MARK: - Log Entry Model

struct AuditLogEntry: Identifiable, Codable {
    let id = UUID()
    let level: AuditLogLevel
    let category: AuditLogCategory
    let message: String
    let details: String?
    let timestamp: Date
}

// MARK: - Log Levels

enum AuditLogLevel: String, CaseIterable, Codable {
    case debug = "debug"
    case info = "info"
    case warning = "warning"
    case error = "error"
}

// MARK: - Log Categories

enum AuditLogCategory: String, CaseIterable, Codable {
    case auditLifecycle = "Audit Lifecycle"
    case issueDetection = "Issue Detection"
    case dataValidation = "Data Validation"
    case performance = "Performance"
    case systemHealth = "System Health"
    case error = "Error"
    case system = "System"
}

// MARK: - File Logger

private class FileLogger {
    private let logDirectory: URL
    private let currentLogFile: URL
    private let maxLogFileSize: Int = 10 * 1024 * 1024 // 10MB
    private let maxLogFiles: Int = 5
    
    init() {
        let documentsPath = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
        logDirectory = documentsPath.appendingPathComponent("AuditLogs")
        currentLogFile = logDirectory.appendingPathComponent("audit_\(DateFormatter.fileNameFormatter.string(from: Date())).log")
        
        createLogDirectoryIfNeeded()
    }
    
    private func createLogDirectoryIfNeeded() {
        if !FileManager.default.fileExists(atPath: logDirectory.path) {
            try? FileManager.default.createDirectory(at: logDirectory, withIntermediateDirectories: true)
        }
    }
    
    func writeLog(_ entry: AuditLogEntry) {
        let timestamp = DateFormatter.auditLogFormatter.string(from: entry.timestamp)
        let details = entry.details.map { " - \($0)" } ?? ""
        let logLine = "[\(timestamp)] [\(entry.level.rawValue.uppercased())] [\(entry.category.rawValue)] \(entry.message)\(details)\n"
        
        guard let data = logLine.data(using: .utf8) else { return }
        
        if FileManager.default.fileExists(atPath: currentLogFile.path) {
            if let fileHandle = try? FileHandle(forWritingTo: currentLogFile) {
                fileHandle.seekToEndOfFile()
                fileHandle.write(data)
                fileHandle.closeFile()
            }
        } else {
            try? data.write(to: currentLogFile)
        }
        
        // Check if log rotation is needed
        if let attributes = try? FileManager.default.attributesOfItem(atPath: currentLogFile.path),
           let fileSize = attributes[.size] as? Int,
           fileSize > maxLogFileSize {
            rotateLogs()
        }
    }
    
    func rotateLogs() {
        let fileManager = FileManager.default
        
        do {
            let logFiles = try fileManager.contentsOfDirectory(at: logDirectory, includingPropertiesForKeys: [.creationDateKey])
                .filter { $0.pathExtension == "log" }
                .sorted { file1, file2 in
                    let date1 = (try? file1.resourceValues(forKeys: [.creationDateKey]).creationDate) ?? Date.distantPast
                    let date2 = (try? file2.resourceValues(forKeys: [.creationDateKey]).creationDate) ?? Date.distantPast
                    return date1 > date2
                }
            
            // Remove old log files if we exceed the limit
            if logFiles.count >= maxLogFiles {
                for file in logFiles.dropFirst(maxLogFiles - 1) {
                    try? fileManager.removeItem(at: file)
                }
            }
        } catch {
            print("Error rotating audit logs: \(error)")
        }
    }
    
    func clearLogs() {
        let fileManager = FileManager.default
        do {
            let logFiles = try fileManager.contentsOfDirectory(at: logDirectory, includingPropertiesForKeys: nil)
            for file in logFiles {
                try? fileManager.removeItem(at: file)
            }
        } catch {
            print("Error clearing audit logs: \(error)")
        }
    }
}

// MARK: - Date Formatters

private extension DateFormatter {
    static let auditLogFormatter: DateFormatter = {
        let formatter = DateFormatter()
        formatter.dateFormat = "yyyy-MM-dd HH:mm:ss.SSS"
        return formatter
    }()
    
    static let fileNameFormatter: DateFormatter = {
        let formatter = DateFormatter()
        formatter.dateFormat = "yyyy-MM-dd"
        return formatter
    }()
}