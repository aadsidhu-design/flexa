//
//  CircularProjectionFixes.swift
//  FlexaSwiftUI
//
//  Created by Kiro on 10/13/25.
//
//  🎯 3D TO 2D PROJECTION FIXES FOR CIRCULAR MOVEMENTS
//  Fixes coordinate transformation and projection issues for circular ROM calculations
//

import Foundation
import simd
import ARKit

// MARK: - Projection Types

enum ProjectionPlane {
    case horizontal // XZ plane (looking down from above)
    case sagittal   // XY plane (side view)
    case frontal    // YZ plane (front view)
    case optimal    // Automatically determine best plane
    
    var description: String {
        switch self {
        case .horizontal: return "Horizontal (XZ)"
        case .sagittal: return "Sagittal (XY)"
        case .frontal: return "Frontal (YZ)"
        case .optimal: return "Optimal (Auto)"
        }
    }
}

// MARK: - Projection Result

struct ProjectionResult {
    let projectedPoints: [SIMD2<Double>]
    let plane: ProjectionPlane
    let confidence: Double
    let center2D: SIMD2<Double>
    let radius: Double
    let rotationMatrix: simd_double3x3?
    let isValid: Bool
    
    var circularityScore: Double {
        guard projectedPoints.count >= 3 else { return 0.0 }
        
        // Calculate how circular the projected points are
        var deviationSum = 0.0
        for point in projectedPoints {
            let distance = simd_length(point - center2D)
            let deviation = abs(distance - radius) / max(radius, 0.001)
            deviationSum += deviation
        }
        
        let averageDeviation = deviationSum / Double(projectedPoints.count)
        return max(0.0, 1.0 - averageDeviation)
    }
}

// MARK: - Circular Motion Detector

struct CircularMotionDetector {
    
    /// Detect if 3D points represent circular motion and determine best projection plane
    static func detectCircularMotion(points: [SIMD3<Double>]) -> (isCircular: Bool, bestPlane: ProjectionPlane, confidence: Double) {
        guard points.count >= 10 else { return (false, .horizontal, 0.0) }
        
        // Test each projection plane
        let horizontalScore = evaluateCircularityInPlane(points: points, plane: .horizontal)
        let sagittalScore = evaluateCircularityInPlane(points: points, plane: .sagittal)
        let frontalScore = evaluateCircularityInPlane(points: points, plane: .frontal)
        
        let maxScore = max(horizontalScore, sagittalScore, frontalScore)
        let isCircular = maxScore >= 0.6
        
        let bestPlane: ProjectionPlane
        if horizontalScore == maxScore {
            bestPlane = .horizontal
        } else if sagittalScore == maxScore {
            bestPlane = .sagittal
        } else {
            bestPlane = .frontal
        }
        
        return (isCircular, bestPlane, maxScore)
    }
    
    private static func evaluateCircularityInPlane(points: [SIMD3<Double>], plane: ProjectionPlane) -> Double {
        let projectedPoints = projectToPlane(points: points, plane: plane)
        
        // Calculate center and radius
        guard let (center, radius) = fitCircle(points: projectedPoints) else { return 0.0 }
        
        // Calculate circularity score
        var deviationSum = 0.0
        for point in projectedPoints {
            let distance = simd_length(point - center)
            let deviation = abs(distance - radius) / max(radius, 0.001)
            deviationSum += deviation
        }
        
        let averageDeviation = deviationSum / Double(projectedPoints.count)
        return max(0.0, 1.0 - averageDeviation)
    }
    
    private static func projectToPlane(points: [SIMD3<Double>], plane: ProjectionPlane) -> [SIMD2<Double>] {
        switch plane {
        case .horizontal:
            return points.map { SIMD2<Double>($0.x, $0.z) }
        case .sagittal:
            return points.map { SIMD2<Double>($0.x, $0.y) }
        case .frontal:
            return points.map { SIMD2<Double>($0.y, $0.z) }
        case .optimal:
            // This shouldn't be called directly
            return points.map { SIMD2<Double>($0.x, $0.z) }
        }
    }
    
    private static func fitCircle(points: [SIMD2<Double>]) -> (center: SIMD2<Double>, radius: Double)? {
        guard points.count >= 3 else { return nil }
        
        // Simple centroid-based circle fitting
        var centroid = SIMD2<Double>(0, 0)
        for point in points {
            centroid += point
        }
        centroid /= Double(points.count)
        
        // Calculate average radius
        var radiusSum = 0.0
        for point in points {
            radiusSum += simd_length(point - centroid)
        }
        let radius = radiusSum / Double(points.count)
        
        return (centroid, radius)
    }
}

// MARK: - 3D to 2D Projection Engine

final class CircularProjectionEngine {
    
    // MARK: - Configuration
    
    private let minimumPoints = 5
    private let circularityThreshold = 0.6
    private let maxProjectionError = 0.1
    
    // MARK: - Public API
    
    /// Project 3D circular motion to optimal 2D plane
    func projectCircularMotion(points: [SIMD3<Double>], preferredPlane: ProjectionPlane = .optimal) -> ProjectionResult {
        guard points.count >= minimumPoints else {
            return ProjectionResult(
                projectedPoints: [],
                plane: .horizontal,
                confidence: 0.0,
                center2D: SIMD2<Double>(0, 0),
                radius: 0.0,
                rotationMatrix: nil,
                isValid: false
            )
        }
        
        // Determine best projection plane
        let plane: ProjectionPlane
        let confidence: Double
        
        if preferredPlane == .optimal {
            let detection = CircularMotionDetector.detectCircularMotion(points: points)
            plane = detection.bestPlane
            confidence = detection.confidence
        } else {
            plane = preferredPlane
            confidence = CircularMotionDetector.evaluateCircularityInPlane(points: points, plane: plane)
        }
        
        // Perform projection
        let projectedPoints = performProjection(points: points, plane: plane)
        
        // Calculate 2D circle properties
        guard let (center2D, radius) = fitOptimalCircle(points: projectedPoints) else {
            return ProjectionResult(
                projectedPoints: projectedPoints,
                plane: plane,
                confidence: 0.0,
                center2D: SIMD2<Double>(0, 0),
                radius: 0.0,
                rotationMatrix: nil,
                isValid: false
            )
        }
        
        // Calculate rotation matrix for inverse projection if needed
        let rotationMatrix = calculateRotationMatrix(for: plane, points: points)
        
        let isValid = confidence >= circularityThreshold && radius > 0.01
        
        return ProjectionResult(
            projectedPoints: projectedPoints,
            plane: plane,
            confidence: confidence,
            center2D: center2D,
            radius: radius,
            rotationMatrix: rotationMatrix,
            isValid: isValid
        )
    }
    
    /// Project 3D points to specific 2D plane with coordinate transformation
    func projectToPlane(points: [SIMD3<Double>], plane: ProjectionPlane) -> [SIMD2<Double>] {
        return performProjection(points: points, plane: plane)
    }
    
    /// Calculate circular ROM from projected 2D points
    func calculateCircularROM(from projectionResult: ProjectionResult) -> Double {
        guard projectionResult.isValid else { return 0.0 }
        
        let points = projectionResult.projectedPoints
        let center = projectionResult.center2D
        
        // Calculate total angle traversed
        var totalAngle = 0.0
        var lastAngle: Double?
        
        for point in points {
            let vector = point - center
            let angle = atan2(vector.y, vector.x)
            
            if let prevAngle = lastAngle {
                var deltaAngle = angle - prevAngle
                
                // Handle wraparound at ±π
                if deltaAngle > .pi {
                    deltaAngle -= 2 * .pi
                } else if deltaAngle < -.pi {
                    deltaAngle += 2 * .pi
                }
                
                totalAngle += abs(deltaAngle)
            }
            
            lastAngle = angle
        }
        
        // Convert to degrees and scale based on radius
        let angleDegrees = totalAngle * 180.0 / .pi
        let radiusScale = min(1.0, projectionResult.radius * 2.0) // Scale factor based on radius
        
        return min(180.0, angleDegrees * radiusScale)
    }
    
    /// Detect linear vs circular motion from 3D points
    func detectMotionType(points: [SIMD3<Double>]) -> CircularMotionType {
        let detection = CircularMotionDetector.detectCircularMotion(points: points)
        
        if !detection.isCircular {
            return .linear
        }
        
        let projection = projectCircularMotion(points: points)
        let rom = calculateCircularROM(from: projection)
        
        if rom >= 270.0 {
            return .fullCircle
        } else if rom >= 90.0 {
            return .partialCircle
        } else {
            return .irregular
        }
    }
    
    // MARK: - Private Methods
    
    private func performProjection(points: [SIMD3<Double>], plane: ProjectionPlane) -> [SIMD2<Double>] {
        switch plane {
        case .horizontal:
            // Project to XZ plane (horizontal, looking down)
            return points.map { SIMD2<Double>($0.x, $0.z) }
            
        case .sagittal:
            // Project to XY plane (sagittal, side view)
            return points.map { SIMD2<Double>($0.x, $0.y) }
            
        case .frontal:
            // Project to YZ plane (frontal, front view)
            return points.map { SIMD2<Double>($0.y, $0.z) }
            
        case .optimal:
            // This should not be called directly
            return performProjection(points: points, plane: .horizontal)
        }
    }
    
    private func fitOptimalCircle(points: [SIMD2<Double>]) -> (center: SIMD2<Double>, radius: Double)? {
        guard points.count >= 3 else { return nil }
        
        // Use least squares circle fitting for better accuracy
        return fitCircleLeastSquares(points: points)
    }
    
    private func fitCircleLeastSquares(points: [SIMD2<Double>]) -> (center: SIMD2<Double>, radius: Double)? {
        guard points.count >= 3 else { return nil }
        
        // Initial estimate using centroid
        var centroid = SIMD2<Double>(0, 0)
        for point in points {
            centroid += point
        }
        centroid /= Double(points.count)
        
        // Iterative refinement
        var center = centroid
        for _ in 0..<10 { // Maximum 10 iterations
            var weightedSum = SIMD2<Double>(0, 0)
            var totalWeight = 0.0
            
            for point in points {
                let distance = simd_length(point - center)
                let weight = 1.0 / max(distance, 0.001)
                
                weightedSum += point * weight
                totalWeight += weight
            }
            
            let newCenter = weightedSum / totalWeight
            
            // Check convergence
            if simd_length(newCenter - center) < 0.001 {
                break
            }
            
            center = newCenter
        }
        
        // Calculate radius as median distance to avoid outliers
        var distances: [Double] = []
        for point in points {
            distances.append(simd_length(point - center))
        }
        distances.sort()
        
        let radius: Double
        if distances.count % 2 == 0 {
            let mid = distances.count / 2
            radius = (distances[mid - 1] + distances[mid]) / 2.0
        } else {
            radius = distances[distances.count / 2]
        }
        
        return (center, radius)
    }
    
    private func calculateRotationMatrix(for plane: ProjectionPlane, points: [SIMD3<Double>]) -> simd_double3x3? {
        // Calculate rotation matrix for inverse projection if needed
        // This is useful for transforming 2D results back to 3D space
        
        switch plane {
        case .horizontal:
            // No rotation needed for XZ projection
            return simd_double3x3(
                SIMD3<Double>(1, 0, 0),
                SIMD3<Double>(0, 0, 1),
                SIMD3<Double>(0, 1, 0)
            )
            
        case .sagittal:
            // Rotation for XY projection
            return simd_double3x3(
                SIMD3<Double>(1, 0, 0),
                SIMD3<Double>(0, 1, 0),
                SIMD3<Double>(0, 0, 1)
            )
            
        case .frontal:
            // Rotation for YZ projection
            return simd_double3x3(
                SIMD3<Double>(0, 1, 0),
                SIMD3<Double>(0, 0, 1),
                SIMD3<Double>(1, 0, 0)
            )
            
        case .optimal:
            return nil
        }
    }
}

// MARK: - Coordinate System Fixes

final class CoordinateSystemFixer {
    
    /// Fix coordinate system issues in ARKit data for circular motion
    static func fixARKitCoordinates(transform: simd_float4x4) -> SIMD3<Double> {
        // ARKit uses right-handed coordinate system:
        // X: right
        // Y: up
        // Z: toward user (negative forward)
        
        let position = SIMD3<Float>(
            transform.columns.3.x,
            transform.columns.3.y,
            transform.columns.3.z
        )
        
        // Convert to double precision and apply coordinate fixes
        return SIMD3<Double>(
            Double(position.x),   // X: right (correct)
            Double(position.y),   // Y: up (correct)
            Double(-position.z)   // Z: forward (flip for intuitive forward direction)
        )
    }
    
    /// Fix coordinate system for Vision pose data
    static func fixVisionCoordinates(point: CGPoint, imageSize: CGSize) -> SIMD2<Double> {
        // Vision coordinates are normalized (0-1) with origin at top-left
        // Convert to centered coordinates with origin at center
        
        let centerX = Double(point.x - imageSize.width / 2) / Double(imageSize.width)
        let centerY = Double(imageSize.height / 2 - point.y) / Double(imageSize.height) // Flip Y
        
        return SIMD2<Double>(centerX, centerY)
    }
    
    /// Convert screen coordinates to world coordinates for circular motion
    static func screenToWorld(screenPoint: CGPoint, screenSize: CGSize, scale: Double = 1.0) -> SIMD2<Double> {
        // Convert screen coordinates to normalized world coordinates
        let normalizedX = (Double(screenPoint.x) / Double(screenSize.width) - 0.5) * 2.0
        let normalizedY = (0.5 - Double(screenPoint.y) / Double(screenSize.height)) * 2.0 // Flip Y
        
        return SIMD2<Double>(normalizedX * scale, normalizedY * scale)
    }
    
    /// Apply calibration offset to fix coordinate drift
    static func applyCalibrationOffset(position: SIMD3<Double>, baseline: SIMD3<Double>) -> SIMD3<Double> {
        return position - baseline
    }
}

// MARK: - Projection Validation

struct ProjectionValidator {
    
    /// Validate that 3D to 2D projection preserves circular motion properties
    static func validateProjection(original3D: [SIMD3<Double>], projected2D: [SIMD2<Double>], plane: ProjectionPlane) -> (isValid: Bool, error: Double) {
        guard original3D.count == projected2D.count, original3D.count >= 3 else {
            return (false, 1.0)
        }
        
        // Calculate expected 2D points from 3D
        let expectedProjection = CircularProjectionEngine().projectToPlane(points: original3D, plane: plane)
        
        // Calculate projection error
        var totalError = 0.0
        for i in 0..<projected2D.count {
            let error = simd_length(projected2D[i] - expectedProjection[i])
            totalError += error
        }
        
        let averageError = totalError / Double(projected2D.count)
        let isValid = averageError < 0.1 // 10cm tolerance
        
        return (isValid, averageError)
    }
    
    /// Validate circular properties are preserved in projection
    static func validateCircularProperties(original3D: [SIMD3<Double>], projectionResult: ProjectionResult) -> Bool {
        // Check if circular motion is preserved
        let originalCircularity = calculateCircularity3D(points: original3D)
        let projectedCircularity = projectionResult.circularityScore
        
        // Circularity should be preserved or improved in good projection
        return projectedCircularity >= originalCircularity * 0.8
    }
    
    private static func calculateCircularity3D(points: [SIMD3<Double>]) -> Double {
        // Simple 3D circularity calculation
        guard points.count >= 3 else { return 0.0 }
        
        // Calculate centroid
        var centroid = SIMD3<Double>(0, 0, 0)
        for point in points {
            centroid += point
        }
        centroid /= Double(points.count)
        
        // Calculate average radius and deviation
        var radiusSum = 0.0
        for point in points {
            radiusSum += simd_length(point - centroid)
        }
        let averageRadius = radiusSum / Double(points.count)
        
        var deviationSum = 0.0
        for point in points {
            let radius = simd_length(point - centroid)
            let deviation = abs(radius - averageRadius) / max(averageRadius, 0.001)
            deviationSum += deviation
        }
        
        let averageDeviation = deviationSum / Double(points.count)
        return max(0.0, 1.0 - averageDeviation)
    }
}