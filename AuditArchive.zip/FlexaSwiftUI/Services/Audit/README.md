# Audit Infrastructure and Validation Framework

This directory contains the comprehensive audit infrastructure and validation framework for the FlexaSwiftUI app. The system is designed to ensure data integrity, system reliability, and production-level quality across all critical components.

## Overview

The audit system provides:
- **Comprehensive validation** of motion data, session data, and system metrics
- **Detailed logging** of all audit activities with file persistence
- **Test data sets** with known correct results for validation
- **Modular architecture** supporting individual component audits
- **Real-time monitoring** and health checks

## Architecture

### Core Components

1. **AuditFramework.swift** - Base protocols and data structures
2. **AuditLogger.swift** - Comprehensive logging system
3. **ValidationUtilities.swift** - Data validation utilities
4. **TestDataSets.swift** - Test data with known correct results
5. **AuditCoordinator.swift** - Main coordinator managing all audits
6. **AuditIntegration.swift** - Integration layer with the main app
7. **AuditSystemDemoView.swift** - Demo view for testing and showcasing

### Key Protocols

- `AuditValidator` - Base protocol for all audit validators
- `AuditResultProtocol` - Protocol for all audit results
- `AuditResultProtocol` implementations for specific systems

### Data Models

- `SystemAuditResult` - Comprehensive system audit result
- `AuditIssue` - Represents issues found during audits
- `DataQualityScore` - Quantifies data quality across multiple dimensions
- `TestDataCollection` - Collection of all test data sets

## Usage

### Basic Integration

```swift
// Add audit system to your app
ContentView()
    .withAuditSystem()
```

### Environment Access

```swift
struct MyView: View {
    @EnvironmentObject private var auditCoordinator: AuditCoordinator
    @EnvironmentObject private var auditLogger: AuditLogger
    
    var body: some View {
        // Your view content
    }
}
```

### Running Audits

```swift
// Run comprehensive system audit
let result = await auditCoordinator.runSystemAudit()

// Run specific component audit
let aiResult = await auditCoordinator.runComponentAudit(.aiScoring)

// Quick health check
let healthResult = auditCoordinator.performHealthCheck()
```

### Data Validation

```swift
// Validate motion data
let motionValidation = ValidationUtilities.validateMotionData(motionData)

// Validate session data
let sessionValidation = ValidationUtilities.validateSessionData(sessionData)

// Quick validation with summary
let (isValid, summary) = auditCoordinator.validateMotionData(motionData)
```

### Logging

```swift
// Log audit events
auditLogger.logAuditStart("MyValidator", details: "Starting validation")
auditLogger.logIssueFound(issue, validator: "MyValidator")
auditLogger.logAuditComplete("MyValidator", result: result)

// Log custom events
auditLogger.logDataValidation(validator: "MyValidator", dataType: "Motion", isValid: true)
auditLogger.logPerformance(validator: "MyValidator", operation: "Calculation", duration: 0.5)
```

## Test Data Sets

The system includes comprehensive test data sets with known correct results:

### Motion Data Sets
- **Linear Motion** - Perfect linear movement for ROM testing
- **Circular Motion** - Perfect circular movement for circle ROM testing
- **Oscillatory Motion** - Sinusoidal motion for rep counting testing
- **Noisy Motion** - Motion with added noise for robustness testing

### Session Data Sets
- **Perfect Session** - Ideal session data with all valid metrics
- **Incomplete Session** - Session with missing/invalid fields
- **Corrupted Session** - Session with corrupted numeric data

### SPARC Test Cases
- **Smooth Linear Velocity** - Expected SPARC: -1.5
- **Jerky Motion** - Expected SPARC: -5.0
- **Bell Curve Velocity** - Expected SPARC: -1.2

### AI Scoring Test Cases
- **Perfect Form** - Expected score: 95.0
- **Poor Form** - Expected score: 60.0
- **Incomplete Motion** - Expected score: 40.0

## Validation Utilities

### Motion Data Validation
- Timestamp chronological order
- Position data validity
- Data continuity checks
- Statistical outlier detection

### Session Data Validation
- Field completeness
- Numeric range validation
- Data consistency checks
- Timestamp array alignment

### Data Quality Scoring
- **Accuracy** - Correctness of data values
- **Completeness** - Presence of required data
- **Consistency** - Internal data consistency
- **Timeliness** - Temporal data validity

## Logging System

### Log Levels
- `debug` - Detailed debugging information
- `info` - General information
- `warning` - Warning conditions
- `error` - Error conditions

### Log Categories
- `auditLifecycle` - Audit start/completion events
- `issueDetection` - Issue discovery events
- `dataValidation` - Data validation events
- `performance` - Performance metrics
- `systemHealth` - System health events
- `error` - Error events
- `system` - General system events

### Log Persistence
- In-memory logs (last 1000 entries)
- File-based logging with rotation
- Export capabilities for debugging

## Health Monitoring

### System Health Checks
- Logger functionality
- Validation utilities
- Test data integrity
- Overall system status

### Performance Monitoring
- Audit execution times
- Memory usage tracking
- Resource cleanup monitoring

## Development Tools

### Demo View
The `AuditSystemDemoView` provides:
- System status display
- Quick action buttons
- Test data validation
- Real-time log viewing

### Debug Helpers
```swift
#if DEBUG
// Run quick test of all components
let testResult = await AuditSystemTestHelper.runQuickTest()

// Generate sample data for UI testing
let sampleResult = AuditSystemTestHelper.generateSampleAuditResult()
#endif
```

## Future Extensions

The audit framework is designed to be extensible. Future audit validators can be added by:

1. Implementing the `AuditValidator` protocol
2. Creating specific audit result types
3. Registering with the `AuditCoordinator`
4. Adding corresponding test data sets

## Best Practices

1. **Always validate data** before processing
2. **Log audit activities** for debugging and monitoring
3. **Use test data sets** for validation testing
4. **Monitor system health** regularly
5. **Handle audit failures** gracefully
6. **Keep audit logs** for troubleshooting

## Performance Considerations

- Audits run asynchronously to avoid blocking UI
- Parallel execution where possible
- Memory-efficient logging with rotation
- Configurable audit frequency
- Graceful degradation on failures

## Security

- No sensitive data in logs
- Secure file storage for audit logs
- Access control for audit operations
- Data sanitization in audit results