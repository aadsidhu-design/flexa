import Foundation
import SwiftUI

/// Integration layer for the audit system with the main app
extension View {
    /// Add audit system to the environment
    func withAuditSystem() -> some View {
        self.environmentObject(AuditCoordinator.shared)
            .environmentObject(AuditLogger.shared)
    }
}

/// Environment key for audit coordinator
struct AuditCoordinatorKey: EnvironmentKey {
    static let defaultValue = AuditCoordinator.shared
}

/// Environment key for audit logger
struct AuditLoggerKey: EnvironmentKey {
    static let defaultValue = AuditLogger.shared
}

extension EnvironmentValues {
    var auditCoordinator: AuditCoordinator {
        get { self[AuditCoordinatorKey.self] }
        set { self[AuditCoordinatorKey.self] = newValue }
    }
    
    var auditLogger: AuditLogger {
        get { self[AuditLoggerKey.self] }
        set { self[AuditLoggerKey.self] = newValue }
    }
}

/// Convenience methods for common audit operations
extension AuditCoordinator {
    
    /// Quick health check for development/debugging
    func quickHealthCheck() async -> String {
        let healthResult = performHealthCheck()
        
        if healthResult.isHealthy {
            return "✅ Audit system is healthy (check completed in \(String(format: "%.3f", healthResult.checkDuration))s)"
        } else {
            var issues: [String] = []
            if !healthResult.loggerStatus { issues.append("Logger") }
            if !healthResult.validationStatus { issues.append("Validation") }
            if !healthResult.testDataStatus { issues.append("Test Data") }
            
            return "❌ Audit system issues detected: \(issues.joined(separator: ", "))"
        }
    }
    
    /// Log a custom audit event for debugging
    func logCustomEvent(_ message: String, category: AuditLogCategory = .system, level: AuditLogLevel = .info) {
        logger.log(level: level, category: category, message: message)
    }
    
    /// Validate any motion data quickly
    func validateMotionData(_ motionData: [MotionDataPoint]) -> (isValid: Bool, summary: String) {
        let result = ValidationUtilities.validateMotionData(motionData)
        let qualityPercent = Int(result.dataQuality.overall * 100)
        
        if result.isValid {
            return (true, "✅ Motion data valid (quality: \(qualityPercent)%)")
        } else {
            let issueCount = result.issues.count
            return (false, "❌ Motion data invalid (\(issueCount) issues, quality: \(qualityPercent)%)")
        }
    }
    
    /// Validate any session data quickly
    func validateSessionData(_ sessionData: ExerciseSessionData) -> (isValid: Bool, summary: String) {
        let result = ValidationUtilities.validateSessionData(sessionData)
        let qualityPercent = Int(result.dataQuality.overall * 100)
        
        if result.isValid {
            return (true, "✅ Session data valid (quality: \(qualityPercent)%)")
        } else {
            let issueCount = result.issues.count
            return (false, "❌ Session data invalid (\(issueCount) issues, quality: \(qualityPercent)%)")
        }
    }
}

/// Audit system status for UI display
struct AuditSystemStatus {
    let isHealthy: Bool
    let lastAuditTime: Date?
    let overallHealthScore: Double
    let criticalIssues: Int
    let totalIssues: Int
    
    var statusText: String {
        if isHealthy {
            return "System Healthy"
        } else if criticalIssues > 0 {
            return "Critical Issues (\(criticalIssues))"
        } else {
            return "Issues Detected (\(totalIssues))"
        }
    }
    
    var statusColor: Color {
        if isHealthy {
            return .green
        } else if criticalIssues > 0 {
            return .red
        } else {
            return .orange
        }
    }
}

extension AuditCoordinator {
    /// Get current system status for UI
    var systemStatus: AuditSystemStatus {
        let criticalIssues = lastAuditResult?.issues.filter { $0.severity == .critical }.count ?? 0
        let totalIssues = lastAuditResult?.issues.count ?? 0
        
        return AuditSystemStatus(
            isHealthy: lastAuditResult?.isValid ?? false,
            lastAuditTime: lastAuditResult?.timestamp,
            overallHealthScore: lastAuditResult?.overallHealthScore ?? 0.0,
            criticalIssues: criticalIssues,
            totalIssues: totalIssues
        )
    }
}

/// Development helper for testing audit system
#if DEBUG
struct AuditSystemTestHelper {
    
    /// Run a quick test of all audit components
    static func runQuickTest() async -> String {
        let coordinator = AuditCoordinator.shared
        let logger = AuditLogger.shared
        
        var results: [String] = []
        
        // Test health check
        let healthResult = coordinator.performHealthCheck()
        results.append("Health Check: \(healthResult.isHealthy ? "✅" : "❌")")
        
        // Test validation utilities
        let testData = TestDataSets.createLinearMotionData()
        let validationResult = ValidationUtilities.validateMotionData(testData.motionData)
        results.append("Validation: \(validationResult.isValid ? "✅" : "❌")")
        
        // Test logging
        logger.logAuditStart("TestAudit", details: "Testing audit system")
        results.append("Logging: ✅")
        
        // Test data sets
        let testSummary = TestDataSets.runAllValidationTests()
        results.append("Test Data: \(testSummary.successRate > 0.8 ? "✅" : "❌") (\(Int(testSummary.successRate * 100))%)")
        
        return "Audit System Test Results:\n" + results.joined(separator: "\n")
    }
    
    /// Generate sample audit data for UI testing
    static func generateSampleAuditResult() -> SystemAuditResult {
        let sampleIssues = [
            AuditIssue(severity: .medium, category: .aiScoring, description: "Sample AI scoring issue"),
            AuditIssue(severity: .low, category: .performance, description: "Sample performance issue")
        ]
        
        let aiResult = AIScoreAuditResult(
            isValid: true,
            issues: [sampleIssues[0]],
            recommendations: ["Improve AI scoring accuracy"],
            timestamp: Date(),
            validatorName: "SampleAIValidator",
            calculatedScore: 85.0,
            scoreRange: 0...100,
            algorithmValidation: nil
        )
        
        return SystemAuditResult(
            aiScoringAudit: aiResult,
            overallHealthScore: 85.0
        )
    }
}
#endif