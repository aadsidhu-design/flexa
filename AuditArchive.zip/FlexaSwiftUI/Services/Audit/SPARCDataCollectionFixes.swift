import Foundation
import simd

/// Fixes for SPARC data collection and storage integrity issues
class SPARCDataCollectionFixes {
    
    // MARK: - Data Collection State Management
    
    private var lastValidTimestamp: Date?
    private var sessionStartTime: Date
    private var dataIntegrityValidator: SPARCDataIntegrityValidator
    private var timestampValidator: TimestampValidator
    
    init(sessionStartTime: Date = Date()) {
        self.sessionStartTime = sessionStartTime
        self.dataIntegrityValidator = SPARCDataIntegrityValidator()
        self.timestampValidator = TimestampValidator()
    }
    
    // MARK: - Fixed Data Collection Methods
    
    /// Fixed SPARC data point creation with proper validation and timestamp handling
    func createValidatedSPARCDataPoint(
        sparcValue: Double,
        timestamp: Date,
        movementPhase: String,
        jointAngles: [String: Double] = [:],
        confidence: Double,
        dataSource: SPARCDataSource
    ) -> SPARCDataPoint? {
        
        // Validate timestamp
        guard let validatedTimestamp = timestampValidator.validateTimestamp(timestamp, previous: lastValidTimestamp) else {
            FlexaLog.motion.warning("📊 [SPARCDataFix] Invalid timestamp rejected")
            return nil
        }
        
        // Validate SPARC value
        guard dataIntegrityValidator.validateSPARCValue(sparcValue) else {
            FlexaLog.motion.warning("📊 [SPARCDataFix] Invalid SPARC value rejected: \(sparcValue)")
            return nil
        }
        
        // Validate confidence
        guard dataIntegrityValidator.validateConfidence(confidence) else {
            FlexaLog.motion.warning("📊 [SPARCDataFix] Invalid confidence rejected: \(confidence)")
            return nil
        }
        
        // Validate joint angles
        guard dataIntegrityValidator.validateJointAngles(jointAngles) else {
            FlexaLog.motion.warning("📊 [SPARCDataFix] Invalid joint angles rejected")
            return nil
        }
        
        // Create validated data point
        let dataPoint = SPARCDataPoint(
            timestamp: validatedTimestamp,
            sparcValue: sparcValue,
            movementPhase: movementPhase,
            jointAngles: jointAngles,
            confidence: confidence,
            dataSource: dataSource
        )
        
        // Update last valid timestamp
        lastValidTimestamp = validatedTimestamp
        
        FlexaLog.motion.debug("📊 [SPARCDataFix] Valid data point created: t=\(String(format: "%.2f", validatedTimestamp.timeIntervalSince(sessionStartTime)))s, value=\(String(format: "%.1f", sparcValue))")
        
        return dataPoint
    }
    
    /// Fixed bounded array append with data loss prevention
    func safeAppendToSPARCHistory(
        _ dataPoint: SPARCDataPoint,
        to boundedArray: BoundedArray<SPARCDataPoint>
    ) -> Bool {
        
        // Final validation before storage
        guard SPARCCalculationFixes.validateSPARCDataPoint(dataPoint) else {
            FlexaLog.motion.error("📊 [SPARCDataFix] Data point failed final validation")
            return false
        }
        
        // Check for potential data loss
        if boundedArray.isFull {
            FlexaLog.motion.warning("📊 [SPARCDataFix] SPARC history buffer is full - oldest data will be lost")
            
            // Log the data point being lost
            if let oldestPoint = boundedArray.first {
                FlexaLog.motion.info("📊 [SPARCDataFix] Losing oldest data point: t=\(String(format: "%.2f", oldestPoint.timestamp.timeIntervalSince(sessionStartTime)))s")
            }
        }
        
        // Append with thread safety
        boundedArray.append(dataPoint)
        
        FlexaLog.motion.debug("📊 [SPARCDataFix] Data point safely appended. Buffer size: \(boundedArray.count)")
        
        return true
    }
    
    /// Fixed timestamp handling with gap detection and correction
    func handleTimestampGaps(
        in sparcHistory: [SPARCDataPoint],
        maxAllowableGap: TimeInterval = 1.0
    ) -> [SPARCDataPoint] {
        
        guard sparcHistory.count > 1 else { return sparcHistory }
        
        let sortedHistory = sparcHistory.sorted { $0.timestamp < $1.timestamp }
        var correctedHistory: [SPARCDataPoint] = []
        
        for i in 0..<sortedHistory.count {
            let currentPoint = sortedHistory[i]
            correctedHistory.append(currentPoint)
            
            // Check for gaps to next point
            if i < sortedHistory.count - 1 {
                let nextPoint = sortedHistory[i + 1]
                let gap = nextPoint.timestamp.timeIntervalSince(currentPoint.timestamp)
                
                if gap > maxAllowableGap {
                    FlexaLog.motion.warning("📊 [SPARCDataFix] Large gap detected: \(String(format: "%.2f", gap))s")
                    
                    // Insert interpolated points to fill gap
                    let interpolatedPoints = interpolateDataPointsForGap(
                        from: currentPoint,
                        to: nextPoint,
                        maxGapSize: maxAllowableGap
                    )
                    
                    correctedHistory.append(contentsOf: interpolatedPoints)
                }
            }
        }
        
        return correctedHistory
    }
    
    /// Interpolate data points to fill gaps in SPARC history
    private func interpolateDataPointsForGap(
        from startPoint: SPARCDataPoint,
        to endPoint: SPARCDataPoint,
        maxGapSize: TimeInterval
    ) -> [SPARCDataPoint] {
        
        let totalGap = endPoint.timestamp.timeIntervalSince(startPoint.timestamp)
        let numberOfInterpolations = Int(ceil(totalGap / maxGapSize)) - 1
        
        guard numberOfInterpolations > 0 else { return [] }
        
        var interpolatedPoints: [SPARCDataPoint] = []
        
        for i in 1...numberOfInterpolations {
            let t = Double(i) / Double(numberOfInterpolations + 1)
            
            // Linear interpolation of timestamp
            let interpolatedTimestamp = Date(
                timeIntervalSince1970: startPoint.timestamp.timeIntervalSince1970 + 
                (endPoint.timestamp.timeIntervalSince1970 - startPoint.timestamp.timeIntervalSince1970) * t
            )
            
            // Linear interpolation of SPARC value
            let interpolatedSPARC = startPoint.sparcValue + (endPoint.sparcValue - startPoint.sparcValue) * t
            
            // Linear interpolation of confidence
            let interpolatedConfidence = startPoint.confidence + (endPoint.confidence - startPoint.confidence) * t
            
            // Create interpolated data point
            let interpolatedPoint = SPARCDataPoint(
                timestamp: interpolatedTimestamp,
                sparcValue: interpolatedSPARC,
                movementPhase: "interpolated",
                jointAngles: [:], // Don't interpolate joint angles
                confidence: interpolatedConfidence,
                dataSource: startPoint.dataSource
            )
            
            interpolatedPoints.append(interpolatedPoint)
        }
        
        FlexaLog.motion.info("📊 [SPARCDataFix] Interpolated \(interpolatedPoints.count) points for gap of \(String(format: "%.2f", totalGap))s")
        
        return interpolatedPoints
    }
    
    /// Fixed bounds checking for SPARC arrays with automatic correction
    func validateAndCorrectSPARCArray(_ sparcHistory: [SPARCDataPoint]) -> [SPARCDataPoint] {
        var correctedHistory: [SPARCDataPoint] = []
        var correctionCount = 0
        
        for dataPoint in sparcHistory {
            var correctedPoint = dataPoint
            var needsCorrection = false
            
            // Correct SPARC value bounds
            if dataPoint.sparcValue < 0 {
                correctedPoint = SPARCDataPoint(
                    timestamp: dataPoint.timestamp,
                    sparcValue: 0.0,
                    movementPhase: dataPoint.movementPhase,
                    jointAngles: dataPoint.jointAngles,
                    confidence: dataPoint.confidence,
                    dataSource: dataPoint.dataSource
                )
                needsCorrection = true
            } else if dataPoint.sparcValue > 100 {
                correctedPoint = SPARCDataPoint(
                    timestamp: dataPoint.timestamp,
                    sparcValue: 100.0,
                    movementPhase: dataPoint.movementPhase,
                    jointAngles: dataPoint.jointAngles,
                    confidence: dataPoint.confidence,
                    dataSource: dataPoint.dataSource
                )
                needsCorrection = true
            }
            
            // Correct confidence bounds
            if correctedPoint.confidence < 0 {
                correctedPoint = SPARCDataPoint(
                    timestamp: correctedPoint.timestamp,
                    sparcValue: correctedPoint.sparcValue,
                    movementPhase: correctedPoint.movementPhase,
                    jointAngles: correctedPoint.jointAngles,
                    confidence: 0.0,
                    dataSource: correctedPoint.dataSource
                )
                needsCorrection = true
            } else if correctedPoint.confidence > 1 {
                correctedPoint = SPARCDataPoint(
                    timestamp: correctedPoint.timestamp,
                    sparcValue: correctedPoint.sparcValue,
                    movementPhase: correctedPoint.movementPhase,
                    jointAngles: correctedPoint.jointAngles,
                    confidence: 1.0,
                    dataSource: correctedPoint.dataSource
                )
                needsCorrection = true
            }
            
            // Check for NaN or infinite values
            if correctedPoint.sparcValue.isNaN || correctedPoint.sparcValue.isInfinite ||
               correctedPoint.confidence.isNaN || correctedPoint.confidence.isInfinite {
                // Skip this data point entirely
                FlexaLog.motion.warning("📊 [SPARCDataFix] Skipping data point with NaN/infinite values")
                correctionCount += 1
                continue
            }
            
            if needsCorrection {
                correctionCount += 1
            }
            
            correctedHistory.append(correctedPoint)
        }
        
        if correctionCount > 0 {
            FlexaLog.motion.info("📊 [SPARCDataFix] Corrected \(correctionCount) data points in SPARC array")
        }
        
        return correctedHistory
    }
    
    /// Reset session state for new data collection session
    func resetSessionState(newSessionStartTime: Date = Date()) {
        self.sessionStartTime = newSessionStartTime
        self.lastValidTimestamp = nil
        self.timestampValidator.reset()
        self.dataIntegrityValidator.reset()
        
        FlexaLog.motion.info("📊 [SPARCDataFix] Session state reset for new data collection")
    }
}

// MARK: - Data Integrity Validator

class SPARCDataIntegrityValidator {
    
    private var sparcValueHistory: [Double] = []
    private let maxHistorySize = 100
    
    func validateSPARCValue(_ value: Double) -> Bool {
        // Check for NaN or infinite
        guard !value.isNaN && !value.isInfinite else { return false }
        
        // Check bounds
        guard value >= 0 && value <= 100 else { return false }
        
        // Check for reasonable variation (not too many extreme jumps)
        if !sparcValueHistory.isEmpty {
            let lastValue = sparcValueHistory.last!
            let change = abs(value - lastValue)
            
            // Allow maximum 50 point change per data point (prevents extreme jumps)
            if change > 50.0 {
                FlexaLog.motion.warning("📊 [SPARCDataFix] Large SPARC value change detected: \(change)")
                // Still allow it but log the warning
            }
        }
        
        // Add to history
        sparcValueHistory.append(value)
        if sparcValueHistory.count > maxHistorySize {
            sparcValueHistory.removeFirst()
        }
        
        return true
    }
    
    func validateConfidence(_ confidence: Double) -> Bool {
        // Check for NaN or infinite
        guard !confidence.isNaN && !confidence.isInfinite else { return false }
        
        // Check bounds
        return confidence >= 0 && confidence <= 1
    }
    
    func validateJointAngles(_ jointAngles: [String: Double]) -> Bool {
        for (_, angle) in jointAngles {
            // Check for NaN or infinite
            guard !angle.isNaN && !angle.isInfinite else { return false }
            
            // Check reasonable angle bounds (0-360 degrees)
            guard angle >= 0 && angle <= 360 else { return false }
        }
        
        return true
    }
    
    func reset() {
        sparcValueHistory.removeAll()
    }
}

// MARK: - Timestamp Validator

class TimestampValidator {
    
    private var lastTimestamp: Date?
    private let maxAllowableGap: TimeInterval = 2.0 // seconds
    private let minAllowableInterval: TimeInterval = 0.001 // 1ms minimum
    
    func validateTimestamp(_ timestamp: Date, previous: Date?) -> Date? {
        let now = Date()
        
        // Check if timestamp is reasonable (within last hour to 1 minute in future)
        let oneHourAgo = now.addingTimeInterval(-3600)
        let oneMinuteFromNow = now.addingTimeInterval(60)
        
        guard timestamp >= oneHourAgo && timestamp <= oneMinuteFromNow else {
            FlexaLog.motion.warning("📊 [SPARCDataFix] Timestamp outside reasonable range: \(timestamp)")
            return nil
        }
        
        // Check monotonic increase
        if let prevTime = previous {
            let timeDiff = timestamp.timeIntervalSince(prevTime)
            
            // Reject backwards or duplicate timestamps
            if timeDiff < minAllowableInterval {
                FlexaLog.motion.warning("📊 [SPARCDataFix] Non-monotonic or duplicate timestamp")
                return nil
            }
            
            // Warn about large gaps but still allow
            if timeDiff > maxAllowableGap {
                FlexaLog.motion.warning("📊 [SPARCDataFix] Large timestamp gap: \(String(format: "%.2f", timeDiff))s")
            }
        }
        
        lastTimestamp = timestamp
        return timestamp
    }
    
    func reset() {
        lastTimestamp = nil
    }
}

// MARK: - Memory-Safe SPARC Data Storage

class MemorySafeSPARCStorage {
    
    private let maxDataPoints: Int
    private var dataPoints: [SPARCDataPoint] = []
    private let queue = DispatchQueue(label: "com.flexa.sparc.storage", attributes: .concurrent)
    
    init(maxDataPoints: Int = 1000) {
        self.maxDataPoints = maxDataPoints
    }
    
    func addDataPoint(_ dataPoint: SPARCDataPoint) {
        queue.async(flags: .barrier) { [weak self] in
            guard let self = self else { return }
            
            // Remove oldest if at capacity
            if self.dataPoints.count >= self.maxDataPoints {
                self.dataPoints.removeFirst()
            }
            
            self.dataPoints.append(dataPoint)
        }
    }
    
    func getAllDataPoints() -> [SPARCDataPoint] {
        return queue.sync {
            return Array(dataPoints)
        }
    }
    
    func getDataPointsInRange(from startTime: Date, to endTime: Date) -> [SPARCDataPoint] {
        return queue.sync {
            return dataPoints.filter { dataPoint in
                dataPoint.timestamp >= startTime && dataPoint.timestamp <= endTime
            }
        }
    }
    
    func clearAllData() {
        queue.async(flags: .barrier) { [weak self] in
            self?.dataPoints.removeAll()
        }
    }
    
    func getDataPointCount() -> Int {
        return queue.sync {
            return dataPoints.count
        }
    }
}