import Foundation
import simd

/// Integration layer that applies SPARC calculation and data collection fixes to the existing service
class SPARCServiceIntegration {
    
    private let sparcService: SPARCCalculationService
    private let dataCollectionFixes: SPARCDataCollectionFixes
    private let memorySafeStorage: MemorySafeSPARCStorage
    
    // Enhanced data validation
    private var lastValidDataPoint: SPARCDataPoint?
    private var sessionQualityMetrics: SessionQualityMetrics
    
    init(sparcService: SPARCCalculationService) {
        self.sparcService = sparcService
        self.dataCollectionFixes = SPARCDataCollectionFixes()
        self.memorySafeStorage = MemorySafeSPARCStorage()
        self.sessionQualityMetrics = SessionQualityMetrics()
    }
    
    // MARK: - Enhanced Data Input Methods
    
    /// Enhanced IMU data input with validation and error correction
    func addValidatedIMUData(timestamp: TimeInterval, acceleration: [Double], velocity: [Double]?) {
        // Convert timestamp to Date
        let timestampDate = Date(timeIntervalSince1970: timestamp)
        
        // Validate input data
        guard acceleration.count >= 3 else {
            FlexaLog.motion.error("📊 [SPARCIntegration] Invalid acceleration data: insufficient components")
            sessionQualityMetrics.recordDataError(.invalidAcceleration)
            return
        }
        
        // Convert and validate acceleration
        let accel = SIMD3<Float>(Float(acceleration[0]), Float(acceleration[1]), Float(acceleration[2]))
        guard let validatedAccel = SPARCCalculationFixes.validateAndPreprocessVelocityData(accel) else {
            FlexaLog.motion.warning("📊 [SPARCIntegration] Invalid acceleration data rejected")
            sessionQualityMetrics.recordDataError(.invalidAcceleration)
            return
        }
        
        // Convert and validate velocity if provided
        var validatedVel: SIMD3<Float>?
        if let vel = velocity, vel.count >= 3 {
            let velVector = SIMD3<Float>(Float(vel[0]), Float(vel[1]), Float(vel[2]))
            validatedVel = SPARCCalculationFixes.validateAndPreprocessVelocityData(velVector)
        }
        
        // Pass validated data to original service
        sparcService.addIMUData(
            timestamp: timestamp,
            acceleration: [Double(validatedAccel.x), Double(validatedAccel.y), Double(validatedAccel.z)],
            velocity: validatedVel != nil ? [Double(validatedVel!.x), Double(validatedVel!.y), Double(validatedVel!.z)] : nil
        )
        
        sessionQualityMetrics.recordValidDataPoint()
    }
    
    /// Enhanced vision data input with validation
    func addValidatedVisionData(timestamp: TimeInterval, handPosition: CGPoint, velocity: SIMD3<Float>) {
        let timestampDate = Date(timeIntervalSince1970: timestamp)
        
        // Validate timestamp
        guard let validatedTimestamp = SPARCCalculationFixes.validateAndFixTimestamp(timestampDate, previousTimestamp: lastValidDataPoint?.timestamp) else {
            FlexaLog.motion.warning("📊 [SPARCIntegration] Invalid timestamp rejected for vision data")
            sessionQualityMetrics.recordDataError(.invalidTimestamp)
            return
        }
        
        // Validate position
        guard handPosition.x.isFinite && handPosition.y.isFinite else {
            FlexaLog.motion.warning("📊 [SPARCIntegration] Invalid hand position rejected")
            sessionQualityMetrics.recordDataError(.invalidPosition)
            return
        }
        
        // Validate and preprocess velocity
        guard let validatedVelocity = SPARCCalculationFixes.validateAndPreprocessVelocityData(velocity) else {
            FlexaLog.motion.warning("📊 [SPARCIntegration] Invalid velocity data rejected")
            sessionQualityMetrics.recordDataError(.invalidVelocity)
            return
        }
        
        // Pass validated data to original service
        sparcService.addVisionData(timestamp: timestamp, handPosition: handPosition, velocity: validatedVelocity)
        
        sessionQualityMetrics.recordValidDataPoint()
    }
    
    /// Enhanced ARKit position data input with validation
    func addValidatedARKitPositionData(timestamp: TimeInterval, position: SIMD3<Float>) {
        let timestampDate = Date(timeIntervalSince1970: timestamp)
        
        // Validate timestamp
        guard let validatedTimestamp = SPARCCalculationFixes.validateAndFixTimestamp(timestampDate, previousTimestamp: lastValidDataPoint?.timestamp) else {
            FlexaLog.motion.warning("📊 [SPARCIntegration] Invalid timestamp rejected for ARKit data")
            sessionQualityMetrics.recordDataError(.invalidTimestamp)
            return
        }
        
        // Validate position
        guard !position.x.isNaN && !position.y.isNaN && !position.z.isNaN &&
              position.x.isFinite && position.y.isFinite && position.z.isFinite else {
            FlexaLog.motion.warning("📊 [SPARCIntegration] Invalid ARKit position rejected")
            sessionQualityMetrics.recordDataError(.invalidPosition)
            return
        }
        
        // Check for reasonable position bounds (within 10 meters)
        let magnitude = simd_length(position)
        guard magnitude < 10.0 else {
            FlexaLog.motion.warning("📊 [SPARCIntegration] ARKit position magnitude too large: \(magnitude)")
            sessionQualityMetrics.recordDataError(.invalidPosition)
            return
        }
        
        // Pass validated data to original service
        sparcService.addARKitPositionData(timestamp: timestamp, position: position)
        
        sessionQualityMetrics.recordValidDataPoint()
    }
    
    // MARK: - Enhanced Data Retrieval Methods
    
    /// Get validated and corrected SPARC data points
    func getValidatedSPARCDataPoints() -> [SPARCDataPoint] {
        let rawDataPoints = sparcService.getSPARCDataPoints()
        
        // Apply data collection fixes
        let correctedDataPoints = dataCollectionFixes.validateAndCorrectSPARCArray(rawDataPoints)
        
        // Handle timestamp gaps
        let gapCorrectedDataPoints = dataCollectionFixes.handleTimestampGaps(in: correctedDataPoints)
        
        // Store in memory-safe storage
        for dataPoint in gapCorrectedDataPoints {
            memorySafeStorage.addDataPoint(dataPoint)
        }
        
        return gapCorrectedDataPoints
    }
    
    /// Get SPARC data points for a specific time range
    func getSPARCDataPointsInRange(from startTime: Date, to endTime: Date) -> [SPARCDataPoint] {
        return memorySafeStorage.getDataPointsInRange(from: startTime, to: endTime)
    }
    
    /// Get enhanced session summary with quality metrics
    func getEnhancedSessionSummary() -> EnhancedSessionSummary {
        let originalSummary = sparcService.getSessionSummary()
        let validatedDataPoints = getValidatedSPARCDataPoints()
        
        return EnhancedSessionSummary(
            averageSPARC: originalSummary.averageSPARC,
            peakSPARC: originalSummary.peakSPARC,
            sampleCount: originalSummary.sampleCount,
            validatedDataPointCount: validatedDataPoints.count,
            dataQualityScore: sessionQualityMetrics.getQualityScore(),
            errorCounts: sessionQualityMetrics.getErrorCounts(),
            sessionDuration: Date().timeIntervalSince(sparcService.getSessionStartTime())
        )
    }
    
    // MARK: - Enhanced Calculation Methods
    
    /// Compute SPARC with enhanced mathematical correctness
    func computeEnhancedCameraWristSPARC(wristPositions: [CGPoint], timestamps: [TimeInterval]) -> Double? {
        guard wristPositions.count == timestamps.count, wristPositions.count >= 20 else {
            FlexaLog.motion.warning("📊 [SPARCIntegration] Insufficient wrist trajectory data: \(wristPositions.count) samples")
            return nil
        }
        
        // Calculate velocity magnitudes with validation
        var velocityMagnitudes: [Float] = []
        for i in 1..<wristPositions.count {
            let dx = Float(wristPositions[i].x - wristPositions[i-1].x)
            let dy = Float(wristPositions[i].y - wristPositions[i-1].y)
            let dt = Float(timestamps[i] - timestamps[i-1])
            
            guard dt > 0 && dt < 1.0 else { continue } // Filter out invalid time deltas
            
            let velocity = sqrt(dx*dx + dy*dy) / dt
            
            // Validate velocity magnitude
            guard velocity.isFinite && velocity >= 0 && velocity < 1000 else { continue }
            
            velocityMagnitudes.append(velocity)
        }
        
        guard velocityMagnitudes.count >= 15 else {
            FlexaLog.motion.warning("📊 [SPARCIntegration] Insufficient valid velocity samples: \(velocityMagnitudes.count)")
            return nil
        }
        
        // Estimate sampling rate
        let validTimestamps = Array(timestamps.prefix(velocityMagnitudes.count + 1))
        var deltaSum: Double = 0
        var deltaCount = 0
        
        for i in 1..<validTimestamps.count {
            let delta = validTimestamps[i] - validTimestamps[i-1]
            if delta > 0 && delta < 1.0 {
                deltaSum += delta
                deltaCount += 1
            }
        }
        
        guard deltaCount > 0 else { return nil }
        let avgDelta = deltaSum / Double(deltaCount)
        let samplingRate = 1.0 / avgDelta
        
        // Use enhanced SPARC calculation
        do {
            let result = try SPARCCalculationFixes.calculateCorrectSPARC(
                velocityMagnitudes: velocityMagnitudes,
                samplingRate: samplingRate
            )
            
            let normalizedScore = max(0.0, min(100.0, result.sparc))
            
            FlexaLog.motion.info("📊 [SPARCIntegration] Enhanced camera SPARC: \(String(format: "%.1f", normalizedScore)) (confidence: \(String(format: "%.2f", result.confidence)))")
            
            return normalizedScore
        } catch {
            FlexaLog.motion.error("📊 [SPARCIntegration] Enhanced SPARC calculation failed: \(error.localizedDescription)")
            return nil
        }
    }
    
    /// Compute enhanced handheld ARKit SPARC
    func computeEnhancedHandheldARKitSPARC(positions: [SIMD3<Float>], timestamps: [TimeInterval]) -> Double? {
        guard positions.count == timestamps.count, positions.count >= 10 else {
            FlexaLog.motion.warning("📊 [SPARCIntegration] Insufficient ARKit trajectory data: \(positions.count) samples")
            return nil
        }
        
        // Validate all positions
        let validPositions = positions.filter { position in
            !position.x.isNaN && !position.y.isNaN && !position.z.isNaN &&
            position.x.isFinite && position.y.isFinite && position.z.isFinite &&
            simd_length(position) < 10.0 // Reasonable bounds
        }
        
        guard validPositions.count >= 8 else {
            FlexaLog.motion.warning("📊 [SPARCIntegration] Insufficient valid positions: \(validPositions.count)")
            return nil
        }
        
        // Calculate 3D velocities with validation
        var velocityMagnitudes: [Float] = []
        
        for i in 1..<validPositions.count {
            let delta = validPositions[i] - validPositions[i-1]
            let dt = Float(timestamps[min(i, timestamps.count-1)] - timestamps[max(0, i-1)])
            
            guard dt > 0 && dt < 0.5 else { continue }
            
            let velocity = delta / dt
            let magnitude = simd_length(velocity)
            
            guard magnitude.isFinite && magnitude >= 0 && magnitude < 50.0 else { continue }
            
            velocityMagnitudes.append(magnitude)
        }
        
        guard velocityMagnitudes.count >= 6 else {
            FlexaLog.motion.warning("📊 [SPARCIntegration] Insufficient valid velocity samples: \(velocityMagnitudes.count)")
            return nil
        }
        
        // Estimate sampling rate
        let avgDelta = timestamps.count > 1 ? 
            (timestamps.last! - timestamps.first!) / Double(timestamps.count - 1) : 0.033
        let samplingRate = avgDelta > 0 ? 1.0 / avgDelta : 30.0
        
        // Use enhanced SPARC calculation
        do {
            let result = try SPARCCalculationFixes.calculateCorrectSPARC(
                velocityMagnitudes: velocityMagnitudes,
                samplingRate: samplingRate
            )
            
            let normalizedScore = max(0.0, min(100.0, result.sparc))
            
            FlexaLog.motion.info("📊 [SPARCIntegration] Enhanced handheld SPARC: \(String(format: "%.1f", normalizedScore)) (confidence: \(String(format: "%.2f", result.confidence)))")
            
            return normalizedScore
        } catch {
            FlexaLog.motion.error("📊 [SPARCIntegration] Enhanced handheld SPARC calculation failed: \(error.localizedDescription)")
            return nil
        }
    }
    
    // MARK: - Session Management
    
    func resetSession() {
        sparcService.reset()
        dataCollectionFixes.resetSessionState()
        memorySafeStorage.clearAllData()
        sessionQualityMetrics.reset()
        lastValidDataPoint = nil
        
        FlexaLog.motion.info("📊 [SPARCIntegration] Enhanced session reset complete")
    }
}

// MARK: - Supporting Types

struct EnhancedSessionSummary {
    let averageSPARC: Double
    let peakSPARC: Double
    let sampleCount: Int
    let validatedDataPointCount: Int
    let dataQualityScore: Double
    let errorCounts: [DataErrorType: Int]
    let sessionDuration: TimeInterval
}

class SessionQualityMetrics {
    private var validDataPointCount = 0
    private var errorCounts: [DataErrorType: Int] = [:]
    
    func recordValidDataPoint() {
        validDataPointCount += 1
    }
    
    func recordDataError(_ errorType: DataErrorType) {
        errorCounts[errorType, default: 0] += 1
    }
    
    func getQualityScore() -> Double {
        let totalDataPoints = validDataPointCount + errorCounts.values.reduce(0, +)
        guard totalDataPoints > 0 else { return 1.0 }
        
        return Double(validDataPointCount) / Double(totalDataPoints)
    }
    
    func getErrorCounts() -> [DataErrorType: Int] {
        return errorCounts
    }
    
    func reset() {
        validDataPointCount = 0
        errorCounts.removeAll()
    }
}

enum DataErrorType: String, CaseIterable {
    case invalidTimestamp
    case invalidAcceleration
    case invalidVelocity
    case invalidPosition
    case invalidSPARCValue
    case invalidConfidence
}