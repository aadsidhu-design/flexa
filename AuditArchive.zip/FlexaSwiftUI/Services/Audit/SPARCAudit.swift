import Foundation
import Accelerate
import simd

/// Comprehensive audit system for SPARC calculation accuracy and data integrity
class SPARCAudit: ObservableObject {
    
    private let validator = SPARCValidator()
    private let sparcService: SPARCCalculationService
    
    // MARK: - Audit Results
    
    struct ComprehensiveSPARCAuditResult {
        let calculationAudit: SPARCValidator.SPARCAuditResult
        let dataIntegrityAudit: DataIntegrityAuditResult
        let graphVisualizationAudit: GraphVisualizationAuditResult
        let performanceAudit: PerformanceAuditResult
        let overallHealthScore: Double
        let criticalIssues: [CriticalIssue]
        let recommendations: [String]
    }
    
    struct DataIntegrityAuditResult {
        let isValid: Bool
        let timestampConsistency: Bool
        let dataLossDetected: Bool
        let samplingRateVariance: Double
        let missingDataPoints: Int
        let corruptedDataPoints: Int
    }
    
    struct GraphVisualizationAuditResult {
        let isValid: Bool
        let chartDataAccuracy: Bool
        let axisScalingCorrect: Bool
        let dataPointsRendered: Int
        let expectedDataPoints: Int
        let visualizationIssues: [VisualizationIssue]
    }
    
    struct PerformanceAuditResult {
        let isValid: Bool
        let averageCalculationTime: TimeInterval
        let memoryUsage: Double
        let cpuUsage: Double
        let threadingIssues: [ThreadingIssue]
    }
    
    enum CriticalIssue {
        case incorrectMathematicalImplementation
        case dataCorruption
        case memoryLeak
        case threadSafety
        case performanceDegradation
    }
    
    enum VisualizationIssue {
        case missingDataPoints
        case incorrectTimeAxis
        case scalingProblems
        case dataGaps
    }
    
    enum ThreadingIssue {
        case raceCondition
        case deadlock
        case improperQueueUsage
    }
    
    init(sparcService: SPARCCalculationService) {
        self.sparcService = sparcService
    }
    
    // MARK: - Comprehensive Audit Methods
    
    /// Perform complete audit of SPARC calculation system
    func performComprehensiveAudit() async -> ComprehensiveSPARCAuditResult {
        FlexaLog.motion.info("🔍 [SPARCAudit] Starting comprehensive SPARC system audit")
        
        // Generate test data for validation
        let testData = generateTestVelocityData()
        
        // Audit 1: Mathematical correctness
        let calculationAudit = validator.validateSPARCCalculation(
            velocityData: testData.velocityMagnitudes,
            samplingRate: testData.samplingRate
        )
        
        // Audit 2: Data integrity
        let dataIntegrityAudit = await auditDataIntegrity()
        
        // Audit 3: Graph visualization
        let graphAudit = auditGraphVisualization()
        
        // Audit 4: Performance
        let performanceAudit = await auditPerformance()
        
        // Calculate overall health score
        let healthScore = calculateOverallHealthScore(
            calculation: calculationAudit,
            dataIntegrity: dataIntegrityAudit,
            graph: graphAudit,
            performance: performanceAudit
        )
        
        // Identify critical issues
        let criticalIssues = identifyCriticalIssues(
            calculation: calculationAudit,
            dataIntegrity: dataIntegrityAudit,
            performance: performanceAudit
        )
        
        // Generate comprehensive recommendations
        let recommendations = generateComprehensiveRecommendations(
            calculation: calculationAudit,
            dataIntegrity: dataIntegrityAudit,
            graph: graphAudit,
            performance: performanceAudit
        )
        
        FlexaLog.motion.info("🔍 [SPARCAudit] Audit complete - Health Score: \(String(format: "%.1f", healthScore))%")
        
        return ComprehensiveSPARCAuditResult(
            calculationAudit: calculationAudit,
            dataIntegrityAudit: dataIntegrityAudit,
            graphVisualizationAudit: graphAudit,
            performanceAudit: performanceAudit,
            overallHealthScore: healthScore,
            criticalIssues: criticalIssues,
            recommendations: recommendations
        )
    }
    
    // MARK: - Data Integrity Audit
    
    private func auditDataIntegrity() async -> DataIntegrityAuditResult {
        FlexaLog.motion.debug("🔍 [SPARCAudit] Auditing data integrity")
        
        let sparcDataPoints = sparcService.getSPARCDataPoints()
        
        // Check timestamp consistency
        let timestampConsistency = auditTimestampConsistency(sparcDataPoints)
        
        // Check for data loss
        let dataLossDetected = detectDataLoss(sparcDataPoints)
        
        // Calculate sampling rate variance
        let samplingRateVariance = calculateSamplingRateVariance(sparcDataPoints)
        
        // Count missing and corrupted data points
        let (missingCount, corruptedCount) = countDataIssues(sparcDataPoints)
        
        let isValid = timestampConsistency && !dataLossDetected && samplingRateVariance < 0.1
        
        return DataIntegrityAuditResult(
            isValid: isValid,
            timestampConsistency: timestampConsistency,
            dataLossDetected: dataLossDetected,
            samplingRateVariance: samplingRateVariance,
            missingDataPoints: missingCount,
            corruptedDataPoints: corruptedCount
        )
    }
    
    private func auditTimestampConsistency(_ dataPoints: [SPARCDataPoint]) -> Bool {
        guard dataPoints.count > 1 else { return true }
        
        let sortedPoints = dataPoints.sorted { $0.timestamp < $1.timestamp }
        
        for i in 1..<sortedPoints.count {
            let timeDiff = sortedPoints[i].timestamp.timeIntervalSince(sortedPoints[i-1].timestamp)
            
            // Check for negative or zero time differences
            if timeDiff <= 0 {
                FlexaLog.motion.warning("🔍 [SPARCAudit] Timestamp inconsistency detected: negative or zero time diff")
                return false
            }
            
            // Check for excessive gaps (more than 2 seconds)
            if timeDiff > 2.0 {
                FlexaLog.motion.warning("🔍 [SPARCAudit] Large timestamp gap detected: \(timeDiff)s")
                return false
            }
        }
        
        return true
    }
    
    private func detectDataLoss(_ dataPoints: [SPARCDataPoint]) -> Bool {
        guard !dataPoints.isEmpty else { return true }
        
        let sessionStart = sparcService.getSessionStartTime()
        let sessionDuration = Date().timeIntervalSince(sessionStart)
        
        // Expect approximately 4 data points per second (0.25s interval)
        let expectedDataPoints = Int(sessionDuration * 4.0)
        let actualDataPoints = dataPoints.count
        
        // Consider data loss if we have less than 70% of expected points
        let dataLossThreshold = Double(expectedDataPoints) * 0.7
        
        if Double(actualDataPoints) < dataLossThreshold {
            FlexaLog.motion.warning("🔍 [SPARCAudit] Data loss detected: \(actualDataPoints)/\(expectedDataPoints) points")
            return true
        }
        
        return false
    }
    
    private func calculateSamplingRateVariance(_ dataPoints: [SPARCDataPoint]) -> Double {
        guard dataPoints.count > 2 else { return 0.0 }
        
        let sortedPoints = dataPoints.sorted { $0.timestamp < $1.timestamp }
        var intervals: [TimeInterval] = []
        
        for i in 1..<sortedPoints.count {
            let interval = sortedPoints[i].timestamp.timeIntervalSince(sortedPoints[i-1].timestamp)
            if interval > 0 && interval < 2.0 { // Filter out outliers
                intervals.append(interval)
            }
        }
        
        guard !intervals.isEmpty else { return 1.0 }
        
        let mean = intervals.reduce(0, +) / Double(intervals.count)
        let variance = intervals.map { pow($0 - mean, 2) }.reduce(0, +) / Double(intervals.count)
        
        return variance
    }
    
    private func countDataIssues(_ dataPoints: [SPARCDataPoint]) -> (missing: Int, corrupted: Int) {
        var missingCount = 0
        var corruptedCount = 0
        
        for dataPoint in dataPoints {
            // Check for corrupted SPARC values
            if dataPoint.sparcValue.isNaN || dataPoint.sparcValue.isInfinite {
                corruptedCount += 1
            }
            
            // Check for impossible SPARC values
            if dataPoint.sparcValue < 0 || dataPoint.sparcValue > 100 {
                corruptedCount += 1
            }
            
            // Check for confidence values
            if dataPoint.confidence < 0 || dataPoint.confidence > 1 {
                corruptedCount += 1
            }
        }
        
        return (missingCount, corruptedCount)
    }
    
    // MARK: - Graph Visualization Audit
    
    private func auditGraphVisualization() -> GraphVisualizationAuditResult {
        FlexaLog.motion.debug("🔍 [SPARCAudit] Auditing graph visualization")
        
        let sparcDataPoints = sparcService.getSPARCDataPoints()
        let graphAuditResult = validator.auditGraphData(smoothnessHistory: sparcDataPoints)
        
        var visualizationIssues: [VisualizationIssue] = []
        
        // Check for missing data points in visualization
        if sparcDataPoints.isEmpty {
            visualizationIssues.append(.missingDataPoints)
        }
        
        // Check time axis accuracy
        if !graphAuditResult.timestampIssues.isEmpty {
            visualizationIssues.append(.incorrectTimeAxis)
        }
        
        // Check for data gaps
        if !graphAuditResult.dataGaps.isEmpty {
            visualizationIssues.append(.dataGaps)
        }
        
        // Check scaling
        let sparcValues = sparcDataPoints.map { $0.sparcValue }
        if let maxValue = sparcValues.max(), maxValue > 100 {
            visualizationIssues.append(.scalingProblems)
        }
        
        let expectedDataPoints = max(1, sparcDataPoints.count)
        
        return GraphVisualizationAuditResult(
            isValid: visualizationIssues.isEmpty,
            chartDataAccuracy: graphAuditResult.isValid,
            axisScalingCorrect: !visualizationIssues.contains(.scalingProblems),
            dataPointsRendered: sparcDataPoints.count,
            expectedDataPoints: expectedDataPoints,
            visualizationIssues: visualizationIssues
        )
    }
    
    // MARK: - Performance Audit
    
    private func auditPerformance() async -> PerformanceAuditResult {
        FlexaLog.motion.debug("🔍 [SPARCAudit] Auditing performance")
        
        // Measure calculation time
        let startTime = CFAbsoluteTimeGetCurrent()
        
        // Simulate SPARC calculation with test data
        let testData = generateTestVelocityData()
        for velocity in testData.velocityMagnitudes {
            sparcService.addIMUData(
                timestamp: Date().timeIntervalSince1970,
                acceleration: [0, 0, 0],
                velocity: [velocity, 0, 0]
            )
        }
        
        let calculationTime = CFAbsoluteTimeGetCurrent() - startTime
        
        // Check for threading issues (simplified check)
        var threadingIssues: [ThreadingIssue] = []
        
        // Memory usage estimation (simplified)
        let memoryUsage = estimateMemoryUsage()
        
        let isValid = calculationTime < 0.1 && memoryUsage < 50.0 // 100ms max, 50MB max
        
        return PerformanceAuditResult(
            isValid: isValid,
            averageCalculationTime: calculationTime,
            memoryUsage: memoryUsage,
            cpuUsage: 0.0, // Simplified - would need more complex measurement
            threadingIssues: threadingIssues
        )
    }
    
    private func estimateMemoryUsage() -> Double {
        // Simplified memory usage estimation
        // In a real implementation, this would use more sophisticated memory profiling
        return 10.0 // MB
    }
    
    // MARK: - Health Score Calculation
    
    private func calculateOverallHealthScore(
        calculation: SPARCValidator.SPARCAuditResult,
        dataIntegrity: DataIntegrityAuditResult,
        graph: GraphVisualizationAuditResult,
        performance: PerformanceAuditResult
    ) -> Double {
        var score = 0.0
        
        // Mathematical correctness (40% weight)
        score += calculation.isValid ? 40.0 : 0.0
        
        // Data integrity (30% weight)
        score += dataIntegrity.isValid ? 30.0 : 0.0
        
        // Visualization accuracy (20% weight)
        score += graph.isValid ? 20.0 : 0.0
        
        // Performance (10% weight)
        score += performance.isValid ? 10.0 : 0.0
        
        return score
    }
    
    private func identifyCriticalIssues(
        calculation: SPARCValidator.SPARCAuditResult,
        dataIntegrity: DataIntegrityAuditResult,
        performance: PerformanceAuditResult
    ) -> [CriticalIssue] {
        var issues: [CriticalIssue] = []
        
        if !calculation.isValid {
            issues.append(.incorrectMathematicalImplementation)
        }
        
        if dataIntegrity.corruptedDataPoints > 0 {
            issues.append(.dataCorruption)
        }
        
        if performance.memoryUsage > 100.0 {
            issues.append(.memoryLeak)
        }
        
        if performance.averageCalculationTime > 0.5 {
            issues.append(.performanceDegradation)
        }
        
        return issues
    }
    
    private func generateComprehensiveRecommendations(
        calculation: SPARCValidator.SPARCAuditResult,
        dataIntegrity: DataIntegrityAuditResult,
        graph: GraphVisualizationAuditResult,
        performance: PerformanceAuditResult
    ) -> [String] {
        var recommendations: [String] = []
        
        recommendations.append(contentsOf: calculation.recommendations)
        
        if !dataIntegrity.isValid {
            recommendations.append("Implement robust timestamp handling and data validation")
            recommendations.append("Add data integrity checks before SPARC calculations")
        }
        
        if !graph.isValid {
            recommendations.append("Fix graph rendering to handle missing data points gracefully")
            recommendations.append("Implement proper time axis scaling for SPARC charts")
        }
        
        if !performance.isValid {
            recommendations.append("Optimize SPARC calculation performance")
            recommendations.append("Implement memory management for long sessions")
        }
        
        return recommendations
    }
    
    // MARK: - Test Data Generation
    
    private struct TestVelocityData {
        let velocityMagnitudes: [Double]
        let samplingRate: Double
        let expectedSPARC: Double
    }
    
    private func generateTestVelocityData() -> TestVelocityData {
        let samplingRate = 30.0 // Hz
        let duration = 2.0 // seconds
        let sampleCount = Int(samplingRate * duration)
        
        // Generate smooth sinusoidal movement (should have high SPARC)
        var velocityMagnitudes: [Double] = []
        
        for i in 0..<sampleCount {
            let t = Double(i) / samplingRate
            let frequency = 1.0 // Hz
            let velocity = sin(2.0 * .pi * frequency * t)
            velocityMagnitudes.append(abs(velocity))
        }
        
        return TestVelocityData(
            velocityMagnitudes: velocityMagnitudes,
            samplingRate: samplingRate,
            expectedSPARC: 85.0 // Expected high smoothness for sinusoidal motion
        )
    }
}